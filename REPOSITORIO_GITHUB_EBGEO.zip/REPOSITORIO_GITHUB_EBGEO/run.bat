@echo off
chcp 65001 >nul
color 0F
title SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA - DSG / EB

cls
echo ========================================================================
echo             SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA (SGC) - DSG
echo                 DIRETORIA DE SERVIÇO GEOGRÁFICO / EXÉRCITO BRASILEIRO
echo ========================================================================
echo  [+] Inicializando ambiente operacional GIS...
echo  [+] Carregando módulos de processamento vetorial e topológico...
echo  [+] Repositório Multi-Modelagem EDGV (DSG): ATIVADO
echo ========================================================================
echo.

:: Garante execução no diretório do script
cd /d "%~dp0"

:: Configura o PYTHONPATH para enxergar as pastas src e raiz
set PYTHONPATH=%CD%;%CD%\src;%CD%\src\repositorio_modelagens;%PYTHONPATH%

:: Procura pelo executável do conda activate
set ACTIVATE_CMD=""
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat" set ACTIVATE_CMD="%USERPROFILE%\miniconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\minicondaa3\Scripts\activate.bat" set ACTIVATE_CMD="%USERPROFILE%\minicondaa3\Scripts\activate.bat"
if exist "C:\ProgramData\miniconda3\Scripts\activate.bat" set ACTIVATE_CMD="C:\ProgramData\miniconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat" set ACTIVATE_CMD="%USERPROFILE%\miniconda3\Scripts\activate.bat"

if not %ACTIVATE_CMD%=="" (
    :: Tenta ativar o ambiente sgc-cartografia; se não existir, usa o base
    call %ACTIVATE_CMD% sgc-cartografia 2>nul
    if %ERRORLEVEL% NEQ 0 (
        call %ACTIVATE_CMD% base
        echo  [OK] Ambiente Conda 'base' ativado.
    ) else (
        echo  [OK] Ambiente Conda 'sgc-cartografia' ativado com sucesso.
    )
) else (
    echo  [!] Aviso: Conda não encontrado nas pastas padrão. Tentando executar com o Python do sistema.
)

:: Reafirma cor do terminal
color 0F

echo.
echo  [^>] Executando rotina principal de generalização...
echo.

if exist "src\generalizador.py" (
    python src\generalizador.py
) else if exist "generalizador.py" (
    python generalizador.py
) else (
    echo [ERRO] O script 'generalizador.py' não foi localizado!
)

echo.
echo ========================================================================
echo Processamento finalizado. Pressione qualquer tecla para fechar.
pause >nul
