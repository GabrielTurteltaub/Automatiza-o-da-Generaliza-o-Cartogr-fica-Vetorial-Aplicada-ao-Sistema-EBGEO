#!/usr/bin/env bash
# ==============================================================================
# LAUNCHER - SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA (LINUX / MACOS)
# ==============================================================================
set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

export PYTHONPATH="$DIR:$DIR/src:$DIR/src/repositorio_modelagens:$PYTHONPATH"

# Tenta ativar o ambiente Conda se nao estiver ativo
if [[ "$CONDA_DEFAULT_ENV" != "sgc-cartografia" ]]; then
    if command -v conda &> /dev/null; then
        eval "$(conda shell.bash hook)"
        conda activate sgc-cartografia 2>/dev/null || conda activate base
    fi
fi

echo "========================================================================"
echo "    SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA (SGC) - DSG / EB"
echo "========================================================================"
echo ""

if [ -f "src/generalizador.py" ]; then
    python3 src/generalizador.py
elif [ -f "generalizador.py" ]; then
    python3 generalizador.py
else
    echo "[ERRO] 'generalizador.py' não foi localizado!"
    exit 1
fi
