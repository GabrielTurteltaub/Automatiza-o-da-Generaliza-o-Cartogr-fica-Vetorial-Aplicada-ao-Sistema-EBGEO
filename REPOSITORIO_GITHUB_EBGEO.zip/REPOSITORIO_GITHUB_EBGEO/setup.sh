#!/usr/bin/env bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO AUTOMATIZADA - SGC CARTOGRAFIA (LINUX / MACOS)
# ==============================================================================
set -e

echo "========================================================================"
echo "    SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA (SGC) - DSG / EXÉRCITO BRASILEIRO"
echo "              SCRIPT DE INSTALAÇÃO E CONFIGURAÇÃO DE AMBIENTE"
echo "========================================================================"
echo ""

# 1. Verificar se o Conda está disponível
if ! command -v conda &> /dev/null; then
    echo "[ERRO CRÍTICO] O comando 'conda' não foi encontrado no PATH!"
    echo "Por favor, instale o Miniconda antes de prosseguir:"
    echo "https://docs.anaconda.com/miniconda/"
    exit 1
fi

echo "[+] Conda detectado: $(which conda)"
echo ""

# 2. Criar ou atualizar ambiente virtual a partir de environment.yml
echo "[*] Criando/atualizando ambiente Conda 'sgc-cartografia'..."
if conda info --envs | grep -q "sgc-cartografia"; then
    echo "[!] Ambiente 'sgc-cartografia' já existe. Atualizando dependências..."
    conda env update -f environment.yml --prune
else
    conda env create -f environment.yml
fi

echo ""
echo "[+] Ambiente 'sgc-cartografia' configurado com sucesso!"
echo ""

# 3. Criar arquivo de configuração .env a partir de .env.example
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        echo "[*] Criando arquivo de configuração local '.env'..."
        cp .env.example .env
        echo "[+] Arquivo '.env' criado a partir do modelo."
    fi
else
    echo "[+] Arquivo '.env' já existente. Mantido."
fi

# 4. Garantir pastas de dados
mkdir -p data/input data/output

echo ""
echo "========================================================================"
echo "                 INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "========================================================================"
echo ""
echo "Para executar a ferramenta:"
echo "  1. conda activate sgc-cartografia"
echo "  2. ./run.sh (ou python generalizador.py)"
echo ""
