# Arquitetura Técnica do Sistema de Generalização Cartográfica (SGC)
### Diretoria de Serviço Geográfico (DSG) — Exército Brasileiro

Este documento descreve a arquitetura de software, o fluxo de dados, a modelagem conceitual e as decisões de engenharia adotadas na construção do **Sistema de Generalização Cartográfica Multiescalar (SGC)**.

---

## 1. Visão Geral da Arquitetura

O sistema foi concebido sob o paradigma de **Pipeline de Processamento Espacial Autônomo**, operando de forma desacoplada entre a camada de persistência geográfica (PostGIS) e o motor de inteligência geométrica em memória (Python / GeoPandas / Shapely / NetworkX).

```mermaid
flowchart TD
    subgraph SGBD ["PostgreSQL / PostGIS (Camada de Persistência)"]
        BD_IN[("Banco EDGV 3.0 (1:25.000)")]
        GIST_IN["Índices Espaciais GIST (R-Tree)"]
        BD_OUT[("Tabelas Generalizadas (_50k, _100k, _250k)")]
        FLAGS[("Tabela aux_flags_revisao_operador")]
        BD_IN --- GIST_IN
    end

    subgraph CORE ["Motor Geoespacial SGC (Python Engine)"]
        CFG["src/config.py (.env / Parâmetros)"]
        REPO["src/repositorio_modelagens (Mapeamento EDGV)"]
        GEN["src/generalizador.py (Pipeline de Generalização)"]
        VAL["src/validador_dsg.py (Auditor e Auto-Reparo)"]
        
        CFG --> GEN
        REPO --> GEN
        GEN --> VAL
    end

    subgraph CLIENT ["Ambiente de Homologação e Produção"]
        QGIS["QGIS 3.28 LTR"]
        DSGTOOLS["Plugin DsgTools (Auditoria Oficial)"]
        ESTILOS["Estilos QML Oficiais (Estilo30PRO)"]
        QGIS --- DSGTOOLS
        QGIS --- ESTILOS
    end

    BD_IN -->|Queries Filtradas e Indexadas| GEN
    GEN -->|Geometrias Processadas| BD_OUT
    VAL -->|Auto-Reparo e Relatórios| BD_OUT
    VAL -->|Dispersões Cartográficas| FLAGS
    BD_OUT -->|Visualização de Produtos| QGIS
    FLAGS -->|Inspeção de Revisão Humana| QGIS
```

---

## 2. Diagrama de Fluxo de Processamento de uma Camada

Cada feição vetorial submetida ao SGC percorre um encadeamento de transformações estritamente ordenadas para prevenir corrupções topológicas e garantir conformidade com a ET-ADGV 3.0:

```mermaid
flowchart LR
    A["1. Leitura Inteligente PostGIS (Filtragem por Modelo EDGV)"] --> B["2. Seleção e Poda Estrutural (Limiar Métrico e Semântico)"]
    B --> C["3. Análise de Redes via Grafos (NetworkX / Conectividade)"]
    C --> D["4. Simplificação Cartográfica (Douglas-Peucker)"]
    D --> E["5. Suavização Meândrica (Chaikin Smoothing)"]
    E --> F["6. Travamento de Moldura (Preservação de Saídas de Folha)"]
    F --> G["7. Resolução de Conflitos Espaciais (Matriz de Precedência)"]
    G --> H["8. Validação e Persistência (Geração de Índices GIST)"]
```

---

## 3. Módulos do Sistema

### 3.1 `src/config.py` — Centralizador de Configurações
- **Função:** Carrega variáveis de ambiente a partir do arquivo `.env` (ou do sistema operacional) de forma robusta e transparente.
- **Isolamento de Credenciais:** Assegura que senhas de banco de dados e parâmetros de rede não sejam versionados no código-fonte.
- **Resolução de Caminhos:** Normaliza referências relativas para diretórios de entrada (`data/input/`), saída (`data/output/`) e documentação (`docs/`).

### 3.2 `src/repositorio_modelagens` — Camada de Interoperabilidade DSG
- **Função:** Fornece compatibilidade reversa e direta entre diferentes versões da modelagem da DSG:
  - `EDGV 3.0 Topo` (Estrutura canônica padrão)
  - `EDGV 3.0 Orto` (Estrutura ortofotocartográfica)
  - `EDGV 2.1.3` (Estrutura de dados legada)
- **Mapeamento Semântico:** Traduz nomes históricos de tabelas e atributos para que a ferramenta opere de forma agnóstica em qualquer banco de dados de centros de geoinformação (CGEO / DL).

### 3.3 `src/generalizador.py` — Motor Central de Generalização
Executa os operadores cartográficos fundamentais segundo as regras matemáticas da cartografia militar:

1. **Seleção Estruturada:**
   - Filtra feições insignificantes na escala alvo (comprimentos mínimos de drenagem, áreas mínimas de manchas de vegetação e edificações).
2. **Poda e Conectividade via Grafos (`NetworkX`):**
   - Transforma redes de hidrografia e transporte em grafos espaciais direcionados ou não direcionados.
   - Detecta e poda ramos mortos (*dangles*) sem romper eixos estruturantes e preservando nós incidentes na moldura de corte (*bounding box*).
3. **Simplificação e Suavização Geométrica:**
   - *Douglas-Peucker:* Redução controlada de nós e vértices intermediários.
   - *Chaikin Smoothing:* Recomposição orgânica de curvaturas naturais (curvas de nível e meandros de rios), eliminando o aspecto artificial serrilhado.
4. **Colapso Dimensional:**
   - *Polígono para Ponto:* Pequenas manchas edificadas e massas d'água residuais colapsam em seus centróides rotulados.
   - *Polígono para Linha:* Corpos d'água e trechos de vias canalizadas com largura inferior à tolerância gráfica colapsam em eixos médios esqueletizados via Voronoi Medial Axis.
5. **Agregação e Amalgamação:**
   - Edificações e manchas florestais fragmentadas com distância inferior ao limiar visual (0,7 mm no mapa) são unificadas via operação de buffer positivo seguido de buffer negativo (`Closing Morphologique`).
6. **Eliminação de Sobreposições de Cobertura da Terra:**
   - Aplica a **Matriz de Precedência Cartográfica da DSG**:
     $$\text{Massa d'Água} \succ \text{Área Edificada} \succ \text{Vegetação}$$
   - Executa recortes booleanos (`ST_Difference`) para garantir que áreas de transição possuam exatamente $0,00\text{ m}^2$ de superposição mútua.

### 3.4 `src/validador_dsg.py` — Auditoria Topológica e Auto-Reparo
- **Função:** Implementa as verificações formais exigidas pela **ET-CQDG**:
  - Detecção e eliminação de geometrias nulas ou degeneradas (`EMPTY`).
  - Auto-reparo de vértices com autointerseção via `ST_MakeValid`.
  - Verificação de equidistância de curvas de nível (20 m em 50k, 50 m em 100k, 100 m em 250k).
  - Vínculo espacial obrigatório entre pontos cotados e curvas de cumeada (`ST_Contains`).
  - Geração da camada de auditoria `aux_flags_revisao_operador` para destaque no QGIS.

---

## 4. Estratégias de Indexação e Otimização Espacial

O processamento massivo de dezenas de milhares de vetores em nível municipal ou regional exige estratégias de contenção de custo computacional $\mathcal{O}(N^2)$:

1. **Indexação Espacial R-Tree (`GIST`):**
   - Todas as tabelas de entrada e saída recebem índices `GIST(geom)`. As operações relacionais espaciais utilizam bounding-box pré-filtrada com o operador `&&` do PostGIS antes do cálculo vetorial exato.
2. **Janelamento por Vizinhança Espacial (*Spatial Index Queries*):**
   - Ao executar a fusão de polígonos vizinhos ou a verificação de sobreposição, o sistema não cruza a base inteira contra si mesma; ele utiliza a estrutura `sindex` do GeoPandas (baseada no GEOS STRtree) para consultar exclusivamente candidatos dentro do raio de tolerância.
3. **Controle de Precisão Numérica:**
   - Utilização de `shapely.set_precision(geom, grid_size=0.001)` para prevenir erros de ponto flutuante (*robustness issues*) nas operações booleanas de união e diferença.

---

## 5. Garantia de Preservação de Conexões de Borda (Moldura)

Um dos maiores desafios da automação cartográfica é evitar a "quebra de borda", onde trechos de rodovias ou cursos d'água são desconectados das folhas vizinhas. O SGC adota a seguinte rotina de blindagem:

1. A moldura geográfica da folha é computada como uma geometria canônica fechada (`box`).
2. Identificam-se todos os nós de rede que intersectam a borda ($\text{Distância} \le 0,5\text{ m}$).
3. Esses nós são marcados como **Terminais de Borda Intocáveis**.
4. A etapa de poda de dangles e o travamento de topologia ignoram explicitamente esses nós, garantindo que a continuidade contínua de malha entre cartas adjacentes seja preservada em 100% dos casos.

---

## 6. Governança e Extensibilidade

- **Parâmetros Parametrizáveis:** Todas as tolerâncias métricas por escala estão desacopladas do código em `config/parametros_normativos.json`.
- **Compatibilidade Multiplataforma:** O código foi projetado para operar identicamente em ambientes Windows (Command Prompt, PowerShell) e Linux (Bash, Servidores de Integração Contínua).
- **Sem Dependência de Software Proprietário:** Construído 100% sobre a stack FOSS (Free and Open Source Software) recomendada pelo Exército Brasileiro.
