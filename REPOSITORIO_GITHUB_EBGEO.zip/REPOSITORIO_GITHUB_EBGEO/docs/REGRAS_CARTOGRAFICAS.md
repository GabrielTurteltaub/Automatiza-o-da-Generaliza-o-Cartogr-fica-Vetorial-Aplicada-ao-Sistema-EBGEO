# Regras e Parâmetros Normativos de Generalização Cartográfica
### Diretoria de Serviço Geográfico (DSG) — Exército Brasileiro

Este documento detalha as regras cartográficas, limiares dimensionais, algoritmos matemáticos e critérios de conformidade da **ET-ADGV 3.0** (Especificação Técnica para Aquisição de Dados Geoespaciais Vetoriais) e da **ET-CQDG** (Especificação Técnica para Controle de Qualidade de Dados Geoespaciais) implementados no **SGC**.

---

## 1. Fundamentos da Generalização Derivativa

A generalização cartográfica digital derivativa consiste na transformação matemática de um banco de dados geoespaciais de escala de detalhe (no projeto, **1:25.000**) em representações consistentes para escalas menores (**1:50.000**, **1:100.000** e **1:250.000**).

O objetivo é garantir a **legibilidade visual**, a **continuidade funcional das redes**, a **verdade geográfica** e o **rigor topológico**, evitando o congestionamento gráfico causado pela redução proporcional do espaço físico na carta.

---

## 2. Matriz Geral de Tolerâncias e Parâmetros por Escala

Todos os parâmetros implementados no código e espelhados em `config/parametros_normativos.json` estão fundamentados no limiar visual humano padronizado pela DSG ($0,2\text{ mm}$ no papel para acuidade visual mínima e $0,7\text{ mm}$ no papel para distância mínima de separação gráfica):

$$\text{Tolerância no Terreno (m)} = \text{Tolerância Gráfica (mm)} \times \frac{\text{Denominador da Escala}}{1000}$$

| Categoria / Camada | Parâmetro Normativo | Escala 1:50.000 | Escala 1:100.000 | Escala 1:250.000 |
| :--- | :--- | :--- | :--- | :--- |
| **Geral** | Tolerância Gráfica Mínima ($0,2\text{ mm}$) | $10\text{ m}$ | $20\text{ m}$ | $50\text{ m}$ |
| **Geral** | Distância de Separação ($0,7\text{ mm}$) | $35\text{ m}$ | $70\text{ m}$ | $175\text{ m}$ |
| **Hidrografia** | Comprimento mínimo de drenagem | $100\text{ m}$ | $300\text{ m}$ | $800\text{ m}$ |
| **Hidrografia** | Tolerância Douglas-Peucker | $5\text{ m}$ | $15\text{ m}$ | $30\text{ m}$ |
| **Hidrografia** | Suavização Chaikin | 1 iteração | 2 iterações | 2 iterações |
| **Massa d'Água** | Área mínima de polígono | $2.500\text{ m}^2$ | $10.000\text{ m}^2$ | $50.000\text{ m}^2$ |
| **Massa d'Água** | Limiar de colapso para ponto | $< 2.500\text{ m}^2$ | $< 10.000\text{ m}^2$ | $< 50.000\text{ m}^2$ |
| **Vias de Transporte** | Comprimento mínimo de via | $150\text{ m}$ | $400\text{ m}$ | $1.000\text{ m}$ |
| **Vias de Transporte** | Tolerância Douglas-Peucker | $5\text{ m}$ | $12\text{ m}$ | $25\text{ m}$ |
| **Vias de Transporte** | Filtro funcional de vias | Vias principais e secundárias | Rodovias e troncos principais | Apenas rodovias e estradas mestras |
| **Curvas de Nível** | Equidistância vertical padrão | **$20\text{ m}$** | **$50\text{ m}$** | **$100\text{ m}$** |
| **Curvas de Nível** | Suavização Chaikin | 1 iteração (0.25) | 2 iterações (0.25) | 2 iterações (0.25) |
| **Pontos Cotados** | Raio de afinamento radial | $250\text{ m}$ | $600\text{ m}$ | $1.500\text{ m}$ |
| **Vegetação** | Área mínima de polígono | $10.000\text{ m}^2$ | $40.000\text{ m}^2$ | $250.000\text{ m}^2$ |
| **Vegetação** | Raio de agregação (buffer closing) | $15\text{ m}$ | $30\text{ m}$ | $75\text{ m}$ |
| **Área Edificada** | Área mínima de mancha | $2.500\text{ m}^2$ | $10.000\text{ m}^2$ | Colapso total em ponto |
| **Área Edificada** | Raio de fusão de quarteirões | $10\text{ m}$ | $25\text{ m}$ | N/A (ponto) |

---

## 3. Regras Específicas por Categoria Temática

### 3.1 Hidrografia (`elemnat_trecho_drenagem_l` e `cobter_massa_dagua_a`)
1. **Poda e Conectividade Estrutural:**
   - Drenagens que deságuam no oceano, em rios de maior ordem ou que cruzam a moldura nunca são podadas, mesmo que o trecho seja curto.
   - Ramos mortos (*dangles*) com comprimento inferior ao limiar da escala são removidos via análise de grafos (`NetworkX`), impedindo a formação de "pontas soltas" no relevo.
2. **Suavização e Simplificação:**
   - A simplificação via Douglas-Peucker é aplicada primeiro para remover vértices redundantes.
   - Em seguida, aplica-se a suavização de Chaikin com fator de interpolação 0,25 para restituir o aspecto sinuoso natural dos cursos meândricos.
3. **Colapso de Corpos d'Água:**
   - Pequenas lagoas, açudes ou reservatórios com área abaixo da nota mínima colapsam em geometria pontual (`Point`) na camada `cobter_massa_dagua_p`, preservando a informação hídrica em regiões áridas.

### 3.2 Vias de Deslocamento (`infra_via_deslocamento_l`)
1. **Hierarquização Viária:**
   - Na escala 1:50.000, preservam-se rodovias pavimentadas, não pavimentadas e os principais acessos vicinais.
   - Na escala 1:100.000, vias vicinais secundárias e becos sem saída internos são descartados.
   - Na escala 1:250.000, preservam-se exclusivamente as rodovias federais, estaduais e eixos de conexão intermunicipal.
2. **Travamento de Moldura:**
   - Todas as vias que tocam a moldura da carta permanecem travadas nas bordas para garantir compatibilidade com cartas vizinhas contíguas.

### 3.3 Altimetria e Curvas de Nível (`elemnat_curva_nivel_l` e `elemnat_ponto_cotado_p`)
1. **Filtro de Equidistância Rigoroso:**
   - Na escala 1:50.000: Mantêm-se curvas cuja cota é múltipla de $20\text{ m}$ ($cota \pmod{20} == 0$).
   - Na escala 1:100.000: Mantêm-se curvas cuja cota é múltipla de $50\text{ m}$ ($cota \pmod{50} == 0$).
   - Na escala 1:250.000: Mantêm-se curvas cuja cota é múltipla de $100\text{ m}$ ($cota \pmod{100} == 0$).
2. **Vínculo Topológico Curva-Cota:**
   - Pontos cotados de cumeada selecionados mantêm obrigatoriamente a curva de nível fechada envolvente (`ST_Contains`), impedindo pontos de topo isolados no espaço sem representação altimétrica.
   - Curvas de nível anelares de topo que não contenham ponto cotado de cumeada associado são eliminadas para evitar poluição visual.
3. **Afinamento Radial de Pontos Cotados:**
   - Aplica-se algoritmo guloso de supressão radial para evitar sobreposição de rótulos de texto de altitude no produto cartográfico impresso.

### 3.4 Cobertura Terrestre e Resolução de Conflitos Poligonais
1. **Agregação de Manchas:**
   - Polígonos de vegetação ou quarteirões urbanos próximos são fundidos através da operação morfológica de fechamento:
     $$\text{Geometria}_{\text{Agregada}} = \text{Buffer}\Big(\text{Buffer}(\text{Geometria}, +R), -R\Big)$$
2. **Matriz de Precedência Espacial (Zero Sobreposições):**
   - Na ET-CQDG, polígonos de cobertura da terra não podem apresentar sobreposições de área.
   - O SGC aplica a ordem de corte:
     1. **Massa d'Água** (Precedência 1 - Intocável)
     2. **Área Edificada** (Precedência 2 - Cortada pela água)
     3. **Vegetação** (Precedência 3 - Cortada pela água e pela área edificada)
   - Procedimento matemático no PostGIS:
     $$\text{Área Edificada Final} = \text{Área Edificada} \setminus \bigcup \text{Massas d'Água}$$
     $$\text{Vegetação Final} = \text{Vegetação} \setminus \Big(\bigcup \text{Massas d'Água} \cup \bigcup \text{Áreas Edificadas}\Big)$$

---

## 4. Controle de Qualidade (ET-CQDG)

O módulo `src/validador_dsg.py` audita o banco de dados e assegura os seguintes critérios de aceitação:

| Teste Topológico | Regra ET-CQDG | Ação Corretiva do SGC |
| :--- | :--- | :--- |
| **Geometrias Inválidas** | Tolerância = 0 feições | Aplicação de `ST_MakeValid` e remoção de autointerseções |
| **Geometrias Nulas** | Tolerância = 0 feições | Descarte imediato (`DELETE WHERE geom IS NULL OR ST_IsEmpty(geom)`) |
| **Sobreposições de Cobertura** | Tolerância = $0,00\text{ m}^2$ | Aplicação da Matriz de Precedência via `ST_Difference` |
| **Continuidade de Rede** | Sem nós pendentes espúrios | Travamento na moldura e preservação de nós de confluência |
| **Equidistância Altimétrica** | Erro de cota = 0 | Eliminação de curvas fora da classe de equidistância |

---

## 5. Tabela Auxiliar de Revisão do Operador (`aux_flags_revisao_operador`)

Quando uma feição sofre deslocamento superior a $0,3\text{ mm}$ na escala da carta para acomodar a simbologia ou evitar conflito gráfico, o sistema registra um ponto na tabela `aux_flags_revisao_operador` contendo:
- `classe_origem`: Nome da camada afetada.
- `id_origem`: Identificador da feição no banco de dados.
- `tipo_evento`: Motivo da flag (`DESLOCAMENTO_EXCESSIVO`, `REVISAO_MANUAL_CONFLITO`, `AMALGAMACAO_COMPLEXA`).
- `escala_alvo`: Escala em que ocorreu a ocorrência.
- `geom`: Ponto de localização para direcionar o zoom do operador no QGIS.
