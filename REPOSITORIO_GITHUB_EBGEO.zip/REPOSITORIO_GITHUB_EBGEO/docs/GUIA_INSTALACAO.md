# 📖 Manual Rápido do Operador: Generalização Cartográfica
### Diretoria de Serviço Geográfico (DSG) — Exército Brasileiro

> 💡 **Resumo em 1 Minuto (Direto ao Ponto):**
> 1. Baixe 3 programas gratuitos: **Miniconda**, **PostgreSQL + PostGIS** e **Git**.
> 2. Baixe a pasta do projeto do GitHub.
> 3. Dê **2 cliques no arquivo `setup.bat`** (ele instala e prepara tudo sozinho).
> 4. Tenha ou crie o seu banco de dados no PostgreSQL (com o nome que você quiser).
> 5. Dê **2 cliques no arquivo `Generalizar_Mapas.bat`** e gere as cartas!
>
> 📄 *Prefere ler no Word? Acesse a versão diagramada:* [**`docs/MANUAL_DO_USUARIO_PASSO_A_PASSO.docx`**](MANUAL_DO_USUARIO_PASSO_A_PASSO.docx).

---

## ✅ Checklist Rápido do Operador

Vá marcando mentalmente cada etapa:
* [ ] **1.** Instalar o Miniconda (lembrando de marcar a caixinha *"Add to PATH"*).
* [ ] **2.** Instalar o PostgreSQL + PostGIS (marcar PostGIS no Stack Builder, senha de sua escolha).
* [ ] **3.** Baixar a pasta do projeto do GitHub (botão verde *Code ➔ Download ZIP*).
* [ ] **4.** Dar 2 cliques em `setup.bat` e aguardar a mensagem verde de sucesso.
* [ ] **5.** Ter ou criar o seu banco de dados no PostgreSQL (com o nome de sua preferência).
* [ ] **6.** Dar 2 cliques em `Generalizar_Mapas.bat` e apertar Enter para gerar as cartas!

---

## 🗺️ Mapa de Bordo do Operador

```mermaid
flowchart LR
    A["1️⃣ Baixar 3 Programas\n(Miniconda + PostGIS + Git)"] --> B["2️⃣ Baixar o Projeto\n(GitHub ZIP ou Clone)"]
    B --> C["3️⃣ Duplo Clique em\n'setup.bat' (Instala Tudo)"]
    C --> D["4️⃣ Seu Banco no PostGIS\n(Nome de sua escolha)"]
    D --> E["5️⃣ Duplo Clique em\n'Generalizar_Mapas.bat'"]
    E --> F["🎉 Mapas 50k, 100k e 250k\nProntos no PostGIS!"]
```

---

## 🟢 FASE 1: Preparando o Computador (Apenas 3 Downloads)

Se o seu computador acabou de ser formatado, baixe e instale apenas estes 3 programas gratuitos:

| Programa | Para que serve? | Onde baixar? | ⚠️ O que marcar na instalação? |
| :--- | :--- | :--- | :--- |
| **1. Miniconda** | Prepara o Python com as ferramentas de mapas (GDAL, GeoPandas). | [Download Miniconda](https://docs.anaconda.com/miniconda/) | **Muito Importante:** Marque a caixinha *"Add to PATH"*. |
| **2. PostgreSQL + PostGIS** | O banco de dados geográfico onde ficam salvos os mapas. | [Download PostgreSQL](https://www.postgresql.org/download/windows/) | Na última tela, abra o **Stack Builder** e marque o **PostGIS Bundle**. Defina sua senha. |
| **3. Git** | Usado para baixar o código do GitHub com um clique. | [Download Git](https://git-scm.com/download/win) | Apenas avance clicando em *"Next"* até o final. |

*(Opcional: [QGIS 3.28 LTR](https://qgis.org/download/) para abrir e visualizar as cartas com as cores militares).*

---

## 💡 Como Criar o seu Banco de Dados no pgAdmin (Caso ainda não tenha)

1. Abra o programa **pgAdmin 4** (ele instala junto com o PostgreSQL).
2. Digite sua senha de administrador definida na instalação.
3. No menu da esquerda, clique com botão direito em **Databases ➔ Create ➔ Database...**
4. No campo *Database*, digite o nome que você quiser (ex: `cartografia`, `geobase`, `dados_25k`, etc.) e clique no botão azul **Save**.
5. *Pronto!* A nossa ferramenta ativa a extensão PostGIS e cria os esquemas automaticamente na hora da conexão.

---

## 🟢 FASE 2: Baixando o Projeto do GitHub

O código oficial está hospedado no link:
👉 **`https://github.com/GabrielTurteltaub/Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO`**

Escolha a forma que achar mais fácil:

* **Opção A (Mais Fácil - Sem Terminal):**
  1. Acesse o link acima no seu navegador.
  2. Clique no botão verde **`< > Code`** e depois em **`Download ZIP`**.
  3. Vá na sua pasta de Downloads, clique com botão direito no arquivo baixado e selecione **`Extrair Tudo`**.
* **Opção B (Via Terminal):**
  ```bash
  git clone https://github.com/GabrielTurteltaub/Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO.git
  cd Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO
  ```

---

## 🟢 FASE 3: Instalação Automática com 1 Clique (`setup.bat`)

Dentro da pasta do projeto, dê **2 cliques** no arquivo executável:
👉 **`setup.bat`**

* **O que vai acontecer:** Uma janela preta vai abrir e começará a baixar e configurar tudo automaticamente.
* **O que o script faz sozinho:**
  - Acha o seu Miniconda.
  - Baixa o Python certo (3.11) e todas as ferramentas de mapas sem conflitos de DLLs.
  - Cria o arquivo de configuração `.env`.
* **Mensagem esperada:** Quando terminar, aparecerá o texto verde: **`INSTALAÇÃO CONCLUÍDA COM SUCESSO!`**. Pressione qualquer tecla para fechar.

---

## 🟢 FASE 4: Configurar seu Banco e Senha no Arquivo `.env`

O instalador criou automaticamente um arquivo chamado **`.env`** na raiz da pasta. 
Abra esse arquivo no Bloco de Notas para conferir os dados de conexão com seu PostgreSQL:

```ini
DB_HOST=localhost
DB_PORT=5432
DB_NAME=nome_do_seu_banco
DB_USER=postgres
DB_PASSWORD=sua_senha_do_postgres
DB_SCHEMA=edgv
DEFAULT_EPSG=31983
```

* **`DB_NAME`**: Coloque o nome do banco de dados que você utiliza ou criou.
* **`DB_PASSWORD`**: Coloque a senha que você definiu ao instalar o PostgreSQL.
* **`DB_SCHEMA`**: O schema onde estão seus dados (o padrão da DSG é `edgv`, mas a ferramenta também detecta o schema `public` automaticamente).

---

## 🟢 FASE 5: Gerar os Mapas (Execução com Duplo Clique)

Agora é só rodar!

1. Dê **2 cliques** no arquivo **`Generalizar_Mapas.bat`** *(ou no `run.bat`)*.
2. A tela do Exército vai abrir perguntando Host, Banco, Usuário e Senha. 
   - Se você já preencheu o `.env`, **basta apertar ENTER em cada linha!**
   - Se preferir digitar na hora, informe o nome do seu banco e sua senha.
3. Escolha qual escala você quer produzir:
   - Digite **`1`** e tecle Enter ➔ Para gerar a escala **1:50.000**
   - Digite **`2`** e tecle Enter ➔ Para gerar a escala **1:100.000**
   - Digite **`3`** e tecle Enter ➔ Para gerar a escala **1:250.000**
4. O programa vai processar sozinho. Em cerca de **4 minutos**, todas as tabelas derivadas (com sufixo `_50k`, `_100k` ou `_250k`) estarão salvas e indexadas no seu PostGIS!

---

## 🟢 FASE 6: Como Visualizar no QGIS

1. Abra o **QGIS**.
2. Conecte-se ao seu banco PostGIS (`localhost:5432`, seu banco, schema `edgv` ou `public`).
3. Arraste as novas tabelas (com sufixo `_50k`, `_100k` ou `_250k`) para a tela.
4. Para colocar as cores oficiais militares da DSG: abra o plugin **DsgTools** ➔ *Atribuir Estilos QML* ➔ aponte para a pasta `Estilo30PRO`.

---

## ❓ Resolução de Dúvidas Rápidas (FAQ)

| O que aconteceu? | O que significa? | O que você deve fazer? |
| :--- | :--- | :--- |
| **"Erro de senha ou banco não encontrado"** | O nome do banco ou a senha no `.env` estão diferentes do PostgreSQL. | Abra o `.env` no Bloco de Notas e coloque o nome do seu banco e sua senha real. |
| **`setup.bat` diz que Conda não foi encontrado** | Miniconda instalado sem marcar a opção de PATH. | Reinstale o Miniconda marcando a caixa *"Add Miniconda to my PATH variable"*. |
| **As tabelas geradas ficaram vazias** | O seu banco ainda não tem as camadas originais 1:25.000. | Importe os dados da folha 1:25k de entrada no schema `edgv` (ou `public`) do seu banco antes de rodar. |

---

### 🏛️ Diretoria de Serviço Geográfico (DSG)
*Dúvidas técnicas ou relatórios de melhoria podem ser abertos diretamente na aba **Issues** do repositório no GitHub.*
