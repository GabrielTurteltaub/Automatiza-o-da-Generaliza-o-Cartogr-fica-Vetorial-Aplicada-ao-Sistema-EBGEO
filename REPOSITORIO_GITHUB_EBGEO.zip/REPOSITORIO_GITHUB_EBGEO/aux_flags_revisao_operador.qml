<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="AllStyleCategories" version="3.28.11" hasScaleBasedVisibilityFlag="0" minScale="1e+08" maxScale="0">
  <renderer-v2 attr="gravidade" forceraster="0" type="categorizedSymbol" enableorderby="0">
    <categories>
      <category label="Crítico (Impede Homologação)" render="true" symbol="0" value="CRITICO"/>
      <category label="Alerta (Inconformidade Geométrica)" render="true" symbol="1" value="ALERTA"/>
      <category label="Revisão (Toponímia / Semântica)" render="true" symbol="2" value="REVISAO"/>
    </categories>
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" name="0" type="marker">
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <prop k="color" v="217,4,41,255"/>
          <prop k="name" v="triangle"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.6"/>
          <prop k="size" v="4.5"/>
          <prop k="size_unit" v="MM"/>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" name="1" type="marker">
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <prop k="color" v="247,127,0,255"/>
          <prop k="name" v="diamond"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.5"/>
          <prop k="size" v="4.0"/>
          <prop k="size_unit" v="MM"/>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" name="2" type="marker">
        <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
          <prop k="color" v="252,191,73,255"/>
          <prop k="name" v="circle"/>
          <prop k="outline_color" v="0,0,0,255"/>
          <prop k="outline_style" v="solid"/>
          <prop k="outline_width" v="0.4"/>
          <prop k="size" v="3.5"/>
          <prop k="size_unit" v="MM"/>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
</qgis>
