# Sistema de Generalização Cartográfica Multiescalar (SGC)
### Diretoria de Serviço Geográfico (DSG) — Exército Brasileiro

[![Python 3.11](https://img.shields.io/badge/Python-3.11-3776AB?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![Conda Forge](https://img.shields.io/badge/Conda--Forge-GIS-43B02A?style=flat&logo=anaconda&logoColor=white)](https://conda-forge.org/)
[![PostGIS 3.x](https://img.shields.io/badge/PostGIS-3.x-336791?style=flat&logo=postgresql&logoColor=white)](https://postgis.net/)
[![GDAL 3.8+](https://img.shields.io/badge/GDAL-3.8+-green?style=flat)](https://gdal.org/)
[![Padrão EDGV 3.0](https://img.shields.io/badge/Padr%C3%A3o-ET--EDGV%203.0%20Topo-blue?style=flat)](http://www.geoportal.eb.mil.br/)
[![Licença DSG](https://img.shields.io/badge/Licen%C3%A7a-DSG%20%2F%20EB-darkred?style=flat)]()

Pipeline automatizado em Python e PostGIS para generalização cartográfica derivativa multiescalar (1:25.000 para 1:50.000, 1:100.000 e 1:250.000) em estrita conformidade com as normas técnicas da **Infraestrutura Nacional de Dados Espaciais (INDE)** e da **Diretoria de Serviço Geográfico (DSG)**: **ET-ADGV 3.0** (Especificação Técnica para Aquisição de Dados Geoespaciais Vetoriais) e **ET-CQDG** (Especificação Técnica para Controle de Qualidade de Dados Geoespaciais).

---

## 📑 Sumário

- [Visão Geral](#-visão-geral)
- [Estrutura do Repositório](#-estrutura-do-repositório)
- [Mapeamento de Dependências](#-mapeamento-de-dependências)
- [Pré-Requisitos do Sistema](#-pré-requisitos-do-sistema)
- [Guia Rápido de Instalação (1-Clique)](#-guia-rápido-de-instalação-1-clique)
- [Instalação Manual Passo a Passo](#-instalação-manual-passo-a-passo)
- [Configuração de Variáveis de Ambiente (.env)](#-configuração-de-variáveis-de-ambiente-env)
- [Como Executar a Aplicação](#-como-executar-a-aplicação)
- [Controle de Qualidade e Validação Topológica](#-controle-de-qualidade-e-validação-topológica)
- [Troubleshooting & Solução de Problemas](#-troubleshooting--solução-de-problemas)
- [Documentação Detalhada](#-documentação-detalhada)

---

## 🎯 Visão Geral

O processamento cartográfico tradicional entre escalas exige semanas de trabalho manual dos operadores em estações SIG, sujeitando as cartas a inconsistências geométricas e descompassos de representação. 

O **SGC** resolve esse gargalo através de um motor geoespacial autônomo que executa:
1. **Seleção e Poda Estruturada**: Seleção semântica baseada em grafos (`NetworkX`) para redes de hidrografia e transporte, preservando conectividade com molduras de corte e eliminando trechos mortos (*dangles*).
2. **Simplificação e Suavização Contínua**: Algoritmos de Douglas-Peucker e suavização meândrica de Chaikin com travas topológicas contra inversões e autocurvaturas.
3. **Colapso e Agregação Poligonal**: Transformação dimensional de polígonos em eixos (`LineString`) ou centróides (`Point`) via *buffer* negativo/positivo e esqueletização (*Voronoi medians*).
4. **Resolução de Conflitos Espaciais**: Eliminação determinística de sobreposições entre polígonos de Cobertura Terrestre (Massa d'Água prevalece sobre Área Edificada, que prevalece sobre Vegetação) via cálculo de diferença geométrica (`ST_Difference`).
5. **Rastreamento de Deslocamentos Críticos**: Tabela auxiliar `aux_flags_revisao_operador` gerada no banco para sinalizar feições pontuais e lineares que sofreram dispersão espacial, agilizando a homologação final no QGIS com o plugin **DsgTools**.

---

## 📂 Estrutura do Repositório

```text
Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO/
├── .vscode/                               # Configurações do VS Code / Cursor
│   ├── extensions.json                    # Extensões recomendadas (Python, PostGIS, QGIS)
│   └── settings.json                      # Definições automáticas de interpretador e terminal
├── config/                                # Configurações e metadados do projeto
│   ├── .env.example                       # Modelo de variáveis de ambiente
│   └── parametros_normativos.json         # Limiares e tolerâncias oficiais por escala
├── data/                                  # Diretório de dados (ignorado pelo Git)
│   ├── input/                             # Vetores e rasters de entrada (.gpkg, .shp)
│   └── output/                            # Relatórios e exportações derivadas
├── docs/                                  # Manuais e documentação técnica completa
│   ├── GUIA_INSTALACAO.md                 # Guia detalhado de instalação em máquina limpa
│   ├── ARQUITETURA_TECNICA.md             # Engenharia de software, módulos e diagramas
│   └── REGRAS_CARTOGRAFICAS.md            # Critérios normativos ET-ADGV e ET-CQDG
├── src/                                   # Código-fonte principal da aplicação
│   ├── __init__.py                        # Inicializador do pacote Python
│   ├── config.py                          # Módulo central de carregamento de variáveis .env
│   ├── generalizador.py                   # Motor autônomo de generalização cartográfica
│   ├── validador_dsg.py                   # Auditor e auto-reparador topológico ET-CQDG
│   └── repositorio_modelagens/            # Catálogo multiplataforma de modelagens DSG
├── .env.example                           # Modelo raiz de variáveis de ambiente
├── .gitignore                             # Filtro de arquivos temporários, caches e dados pesados
├── environment.yml                        # Definição do ambiente Conda com binários C/GIS
├── requirements.txt                       # Dependências Python complementares gerenciadas via pip
├── setup.bat                              # Instalador de 1 clique para Windows
├── setup.sh                               # Instalador de 1 clique para Linux / macOS
├── run.bat                                # Launcher rápido para Windows (ativa Conda e executa)
├── run.sh                                 # Launcher rápido para Linux / macOS
├── Generalizar_Mapas.bat                  # Launcher legado para compatibilidade operacional
└── README.md                              # Documento principal de introdução e guia rápido
```

---

## 🔬 Mapeamento de Dependências

A manipulação de dados geográficos no Windows requer compiladores nativos C/C++ para bibliotecas de baixo nível. Por este motivo, o projeto adota uma arquitetura híbrida de gerenciamento:

| Componente | Tipo de Dependência | Canal de Instalação | Finalidade Principal |
| :--- | :--- | :--- | :--- |
| **Python 3.11** | Interpretador | `conda-forge` | Runtime estável compatível com GDAL 3.8+ |
| **GDAL / OGR** | Binário C/C++ | `conda-forge` | Drivers geoespaciais e transformação de projeções |
| **GEOS** | Binário C++ | `conda-forge` | Operações topológicas (`overlay`, `buffer`, `contains`) |
| **PROJ** | Binário C | `conda-forge` | Biblioteca cartográfica de transformações geodésicas |
| **Shapely 2.0+** | Extensão C (GEOS) | `conda-forge` | Operações geométricas vetorizadas de alta performance |
| **GeoPandas** | Python / C | `conda-forge` | Estrutura de dados geoespaciais em memória |
| **Fiona / PyOgrio** | Extensão C (GDAL) | `conda-forge` | Leitura e gravação ultrarrápida de GeoPackages e Shapefiles |
| **PostGIS / Psycopg2** | Driver C (libpq) | `conda-forge` | Comunicação e execução de queries espaciais no PostgreSQL |
| **NetworkX** | Python puro | `conda` / `pip` | Algoritmos de grafos para redes de hidrografia e transporte |
| **SQLAlchemy** | Python puro | `conda` / `pip` | Pool de conexões ORM e abstração de banco |
| **python-dotenv** | Python puro | `conda` / `pip` | Gerenciamento dinâmico de variáveis de ambiente |

---

## 🛠️ Pré-Requisitos do Sistema

Antes de executar os scripts, certifique-se de que os programas abaixo estão instalados no computador:

1. **Miniconda 64-bit** (ou Anaconda): [Download Oficial](https://docs.anaconda.com/miniconda/)
   * *Atenção:* Durante a instalação, marque a opção de registrar o Conda no PATH do sistema.
2. **PostgreSQL (v14+) + Extensão PostGIS (v3.x)**: [Download Oficial PostgreSQL](https://www.postgresql.org/download/windows/)
   * Após a instalação do PostgreSQL, use o **Stack Builder** para instalar o **PostGIS Bundle**.
3. **Git para Windows**: [Download Oficial Git](https://git-scm.com/download/win)
4. **QGIS 3.28 LTR ou superior** (Opcional, para visualização): [Download QGIS](https://qgis.org/download/)
   * Recomendado instalar o plugin oficial **DsgTools** pelo gerenciador de complementos do QGIS.

---

## ⚡ Guia Rápido de Instalação (1-Clique)

### Windows
1. Abra a pasta do projeto clonado.
2. Dê um duplo clique no arquivo **`setup.bat`**.
   * O script verificará a presença do Conda, criará o ambiente isolado `sgc-cartografia`, instalará todos os pacotes compilados e gerará o arquivo `.env`.
3. Abra o arquivo `.env` gerado e ajuste a senha do PostgreSQL (se diferente de `postgres`).
4. Para executar a generalização, dê um duplo clique em **`run.bat`** (ou `Generalizar_Mapas.bat`).

### Linux / macOS
Abra o terminal na raiz do projeto e execute:
```bash
chmod +x setup.sh run.sh
./setup.sh
```

---

## 🔧 Instalação Manual Passo a Passo

Caso prefira configurar o ambiente manualmente linha a linha pelo terminal:

### 1. Clonar o repositório
```bash
git clone https://github.com/GabrielTurteltaub/Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO.git
cd Automatiza-o-da-Generaliza-o-Cartogr-fica-Vetorial-Aplicada-ao-Sistema-EBGEO
```
*(Ou baixe o arquivo ZIP diretamente pelo GitHub e extraia os arquivos).*

### 2. Criar e ativar o ambiente Conda
```bash
conda env create -f environment.yml
conda activate sgc-cartografia
```

### 3. Criar o arquivo de variáveis de ambiente
No Windows (PowerShell):
```powershell
Copy-Item .env.example .env
```
No Linux / macOS:
```bash
cp .env.example .env
```

---

## ⚙️ Configuração de Variáveis de Ambiente (`.env`)

Abra o arquivo `.env` na raiz do projeto e confira as credenciais do seu banco de dados local:

```ini
# Configurações do Banco de Dados PostgreSQL / PostGIS
DB_HOST=localhost
DB_PORT=5432
DB_NAME=AMAN
DB_USER=postgres
DB_PASSWORD=postgres
DB_SCHEMA=edgv

# Projeção Cartográfica Padrão (SIRGAS 2000 UTM)
# 31982 = Fuso 22S (Centro-Oeste) | 31983 = Fuso 23S (SP / RJ) | 31984 = Fuso 24S (MG / Nordeste)
DEFAULT_EPSG=31983

# Modo de Execução do Generalizador
SGC_LOG_LEVEL=INFO
AUTO_CREATE_SCHEMA=True
```

---

## 🚀 Como Executar a Aplicação

Com o ambiente ativado (`conda activate sgc-cartografia`), você pode iniciar os módulos individualmente ou via script automatizado:

### 1. Executar o Generalizador Cartográfico
```bash
python src/generalizador.py
```
* O script solicitará interativamente a escala alvo desejada:
  * Digite `1` para **1:50.000**
  * Digite `2` para **1:100.000**
  * Digite `3` para **1:250.000**
* As camadas generalizadas serão gravadas diretamente no banco PostGIS com o sufixo da escala (ex: `cobter_massa_dagua_a_50k`, `elemnat_trecho_drenagem_l_100k`, `infra_via_deslocamento_l_250k`).

### 2. Executar o Validador Topológico e Auto-Reparo
```bash
python src/validador_dsg.py
```
* O validador varre todas as 9 classes temáticas, testa conformidade de regras topológicas (interseções espúrias, geometrias nulas, regras de cota, sobreposições de cobertura da terra) e aplica correções automáticas de auto-reparo (`ST_MakeValid`, `ST_Difference` e travamento na moldura).

---

## 🛡️ Controle de Qualidade e Validação Topológica

O sistema gera relatórios completos de auditoria e grava uma camada auxiliar de apoio ao operador humano:

* **Tabela de Flags de Revisão (`aux_flags_revisao_operador`)**:
  Identifica feições que sofreram deslocamento superior ao limiar de tolerância cartográfica ou que necessitam de intervenção estética humana no QGIS.
* **Estilo QGIS Oficial (`aux_flags_revisao_operador.qml`)**:
  Aplique este estilo à tabela no QGIS para visualizar círculos de advertência coloridos sobre os pontos de atenção.

---

## ❓ Troubleshooting & Solução de Problemas

### 1. Erro: `CRSError: no database context specified` ou `PROJ_DATA not found`
* **Causa:** O Windows não localizou a pasta de dados geodésicos do PROJ instalada pelo Conda.
* **Solução:** O script já detecta e injeta o caminho automaticamente. Caso persista, execute no terminal antes de rodar:
  ```powershell
  $env:PROJ_DATA = "$env:CONDA_PREFIX\Library\share\proj"
  ```

### 2. Erro de Execução de Scripts no PowerShell (`PSSecurityException`)
* **Causa:** Política de segurança padrão do Windows que restringe scripts `.ps1`.
* **Solução:** Abra o PowerShell como Administrador e execute:
  ```powershell
  Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
  ```

### 3. Erro: `psycopg2.OperationalError: could not connect to server`
* **Causa:** O serviço do PostgreSQL está parado ou a porta 5432 está bloqueada.
* **Solução:** Pressione `Win + R`, digite `services.msc`, localize o serviço **postgresql-x64-XX** e clique em **Iniciar**.

### 4. Erro de Permissão ao Criar Ambientes no Conda
* **Solução:** Certifique-se de executar o Command Prompt ou PowerShell com privilégios normais de usuário no seu diretório pessoal (`C:\Users\<SeuUsuario>`), evitando instalar o Miniconda em pastas protegidas como `C:\Program Files`.

---

## 📚 Documentação Detalhada

Para aprofundamento técnico e operacional, consulte os guias dedicados na pasta `docs/`:

* 📄 [**Manual do Usuário em Word (.docx)**](docs/MANUAL_DO_USUARIO_PASSO_A_PASSO.docx): Guia visual completo diagramado para leitura rápida no Microsoft Word.
* 📖 [**Guia de Instalação e Execução**](docs/GUIA_INSTALACAO.md): Passo a passo minucioso, amigável e à prova de falhas com links oficiais e troubleshooting.
* 🏗️ [**Arquitetura Técnica do Sistema**](docs/ARQUITETURA_TECNICA.md): Detalhamento do motor de generalização, diagramas de fluxo de dados, indexação espacial e integração com repositórios de modelagem DSG.
* 📐 [**Regras e Parâmetros Cartográficos**](docs/REGRAS_CARTOGRAFICAS.md): Dicionário completo de limiares métricos da ET-ADGV 3.0 e regras de consistência da ET-CQDG aplicadas por escala.

---

### 🏛️ Diretoria de Serviço Geográfico (DSG)
*Braço Científico e Tecnológico da Cartografia Militar Brasileira.*
