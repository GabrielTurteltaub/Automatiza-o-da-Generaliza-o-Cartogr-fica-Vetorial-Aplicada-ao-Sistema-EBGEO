@echo off
chcp 65001 >nul
color 0F
title INSTALAÇÃO AUTOMATIZADA - SGC CARTOGRAFIA (DSG / EB)

echo ========================================================================
echo     SISTEMA DE GENERALIZAÇÃO CARTOGRÁFICA (SGC) - DSG / EXÉRCITO BRASILEIRO
echo               SCRIPT DE INSTALAÇÃO E CONFIGURAÇÃO DE AMBIENTE
echo ========================================================================
echo.

:: 1. Verificar se o Conda está disponível
echo [*] Verificando instalação do Conda (Miniconda / Anaconda)...
set CONDA_CMD=""

where conda >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set CONDA_CMD=conda
    goto CONDA_FOUND
)

if exist "%USERPROFILE%\miniconda3\Scripts\conda.exe" (
    set CONDA_CMD="%USERPROFILE%\miniconda3\Scripts\conda.exe"
    goto CONDA_FOUND
)
if exist "%USERPROFILE%\minicondaa3\Scripts\conda.exe" (
    set CONDA_CMD="%USERPROFILE%\minicondaa3\Scripts\conda.exe"
    goto CONDA_FOUND
)
if exist "C:\ProgramData\miniconda3\Scripts\conda.exe" (
    set CONDA_CMD="C:\ProgramData\miniconda3\Scripts\conda.exe"
    goto CONDA_FOUND
)
if exist "%USERPROFILE%\miniconda3\Scripts\conda.exe" (
    set CONDA_CMD="%USERPROFILE%\miniconda3\Scripts\conda.exe"
    goto CONDA_FOUND
)

echo.
echo [ERRO CRÍTICO] O Conda (Miniconda) não foi localizado no seu computador!
echo.
echo Para executar a ferramenta com todas as bibliotecas GIS (GDAL, GEOS, PROJ):
echo 1. Baixe o instalador oficial do Miniconda para Windows:
echo    https://docs.anaconda.com/miniconda/
echo 2. Execute o instalador e marque a opção para adicionar ao PATH ou instale na pasta padrão.
echo 3. Após concluir a instalação, execute este script 'setup.bat' novamente.
echo.
pause
exit /b 1

:CONDA_FOUND
echo [+] Conda detectado: %CONDA_CMD%
echo.

:: 2. Criar ou atualizar ambiente virtual a partir de environment.yml
echo [*] Configurando ambiente virtual 'sgc-cartografia' via Conda-Forge...
echo     (Esse processo baixa os binários do GDAL, GEOS, GeoPandas e Shapely)
echo     Por favor, aguarde alguns minutos...
echo.

%CONDA_CMD% env create -f environment.yml
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [!] O ambiente já pode existir. Tentando atualizar as dependências...
    %CONDA_CMD% env update -f environment.yml --prune
)

echo.
echo [+] Ambiente 'sgc-cartografia' instalado e validado com sucesso!
echo.

:: 3. Criar arquivo de configuração .env a partir de .env.example
if not exist ".env" (
    if exist ".env.example" (
        echo [*] Criando arquivo de configuração local '.env'...
        copy ".env.example" ".env" >nul
        echo [+] Arquivo '.env' criado com sucesso com as credenciais padrão do PostGIS.
    )
) else (
    echo [+] Arquivo de configuração '.env' já existente. Mantido sem alterações.
)

:: 4. Garantir pastas data/input e data/output
if not exist "data\input" mkdir "data\input"
if not exist "data\output" mkdir "data\output"

echo.
echo ========================================================================
echo                  INSTALAÇÃO CONCLUÍDA COM SUCESSO!
echo ========================================================================
echo.
echo  Próximos passos para utilizar o Sistema:
echo  1. Certifique-se de que o PostgreSQL/PostGIS está em execução na porta 5432.
echo  2. Ajuste o arquivo '.env' se sua senha ou nome do banco forem diferentes de 'postgres' / 'AMAN'.
echo  3. Execute o script 'Generalizar_Mapas.bat' ou 'run.bat' com um duplo clique!
echo.
pause
