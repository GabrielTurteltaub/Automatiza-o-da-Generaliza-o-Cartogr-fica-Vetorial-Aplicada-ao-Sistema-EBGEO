# -*- coding: utf-8 -*-
"""
Pacote Central do Sistema de Generalização Cartográfica (SGC) - DSG / EB
"""
__version__ = "1.0.0"
__author__ = "Cap Vinicius Conceição / Equipe DSG"
