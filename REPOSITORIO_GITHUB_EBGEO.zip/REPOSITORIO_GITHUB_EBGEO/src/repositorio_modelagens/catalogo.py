# -*- coding: utf-8 -*-
"""
Catalogo de correspondencia entre Conceitos Cartograficos e os nomes reais
das tabelas nas diferentes versoes da EDGV (Diretoria de Servico Geografico - DSG).
Suporta tanto conceitos amigaveis ('drenagem', 'curva_nivel') quanto as chaves
padronizadas utilizadas no generalizador ('elemnat_trecho_drenagem_l', etc.).
"""

CATALOGO_MODELAGENS = {
    # -------------------------------------------------------------------------
    # EDGV 3.0 Topo 1.4 (Cartas Topograficas DSG)
    # -------------------------------------------------------------------------
    "edgv_300_topo_14": {
        "descricao": "EDGV Versao 3.0 Topo 1.4 (Cartas Topograficas)",
        "tabelas": {
            # Conceitos amigaveis
            "drenagem": "elemnat_trecho_drenagem_l",
            "massa_dagua": "cobter_massa_dagua_a",
            "vegetacao": "cobter_vegetacao_a",
            "via_deslocamento": "infra_via_deslocamento_l",
            "rodovia": "infra_via_deslocamento_l",
            "ferrovia": "infra_ferrovia_l",
            "area_edificada": "cobter_area_edificada_a",
            "edificacao_a": "constr_edificacao_a",
            "edificacao_p": "constr_edificacao_p",
            "curva_nivel": "elemnat_curva_nivel_l",
            "ponto_cotado": "elemnat_ponto_cotado_p",
            "moldura": "aux_moldura_a",
            "limite_especial": "llp_limite_especial_a",
            "localidade": "llp_localidade_p",

            # Chaves padrao do generalizador.py
            "elemnat_trecho_drenagem_l": "elemnat_trecho_drenagem_l",
            "elemnat_sumidouro_vertedouro_p": "elemnat_sumidouro_vertedouro_p",
            "cobter_corpo_dagua_a": "cobter_massa_dagua_a",
            "cobter_massa_dagua_a": "cobter_massa_dagua_a",
            "cobter_vegetacao_a": "cobter_vegetacao_a",
            "infra_via_deslocamento_l": "infra_via_deslocamento_l",
            "cobter_area_edificada_a": "cobter_area_edificada_a",
            "constr_edificacao_a": "constr_edificacao_a",
            "constr_edificacao_p": "constr_edificacao_p",
            "elemnat_curva_nivel_l": "elemnat_curva_nivel_l",
            "elemnat_ponto_cotado_p": "elemnat_ponto_cotado_p",
            "aux_moldura_a": "aux_moldura_a"
        }
    },

    # -------------------------------------------------------------------------
    # EDGV 3.0 Topo 2.0 (Revisao recente para cartas topograficas)
    # -------------------------------------------------------------------------
    "edgv_300_topo_20": {
        "descricao": "EDGV Versao 3.0 Topo 2.0 (Cartas Topograficas)",
        "tabelas": {
            "drenagem": "elemnat_trecho_drenagem_l",
            "massa_dagua": "cobter_massa_dagua_a",
            "vegetacao": "cobter_vegetacao_a",
            "via_deslocamento": "infra_via_deslocamento_l",
            "rodovia": "infra_via_deslocamento_l",
            "ferrovia": "infra_ferrovia_l",
            "area_edificada": "cobter_area_edificada_a",
            "edificacao_a": "constr_edificacao_a",
            "edificacao_p": "constr_edificacao_p",
            "curva_nivel": "elemnat_curva_nivel_l",
            "ponto_cotado": "elemnat_ponto_cotado_p",
            "moldura": "aux_moldura_a",
            "limite_especial": "llp_limite_especial_a",
            "localidade": "llp_localidade_p",

            # Chaves padrao do generalizador.py
            "elemnat_trecho_drenagem_l": "elemnat_trecho_drenagem_l",
            "elemnat_sumidouro_vertedouro_p": "elemnat_sumidouro_vertedouro_p",
            "cobter_corpo_dagua_a": "cobter_massa_dagua_a",
            "cobter_massa_dagua_a": "cobter_massa_dagua_a",
            "cobter_vegetacao_a": "cobter_vegetacao_a",
            "infra_via_deslocamento_l": "infra_via_deslocamento_l",
            "cobter_area_edificada_a": "cobter_area_edificada_a",
            "constr_edificacao_a": "constr_edificacao_a",
            "constr_edificacao_p": "constr_edificacao_p",
            "elemnat_curva_nivel_l": "elemnat_curva_nivel_l",
            "elemnat_ponto_cotado_p": "elemnat_ponto_cotado_p",
            "aux_moldura_a": "aux_moldura_a"
        }
    },

    # -------------------------------------------------------------------------
    # EDGV 3.0 Orto 2.5 (Cartas Ortoimagem)
    # -------------------------------------------------------------------------
    "edgv_300_orto_25": {
        "descricao": "EDGV Versao 3.0 Orto 2.5 (Cartas Ortoimagem)",
        "tabelas": {
            "drenagem": "elemnat_trecho_drenagem_l",
            "massa_dagua": "cobter_massa_dagua_a",
            "delimitador_massa_dagua": "delimitador_massa_dagua_l",
            "centroide_massa_dagua": "centroide_massa_dagua_p",
            "vegetacao": "cobter_vegetacao_a",
            "via_deslocamento": "infra_via_deslocamento_l",
            "rodovia": "infra_via_deslocamento_l",
            "ferrovia": "infra_ferrovia_l",
            "area_edificada": "cobter_area_edificada_a",
            "edificacao_a": "constr_edificacao_a",
            "edificacao_p": "constr_edificacao_p",
            "moldura": "aux_moldura_a",
            "curva_nivel": "elemnat_curva_nivel_l",
            "ponto_cotado": "elemnat_ponto_cotado_p",

            # Chaves padrao do generalizador.py
            "elemnat_trecho_drenagem_l": "elemnat_trecho_drenagem_l",
            "elemnat_sumidouro_vertedouro_p": "elemnat_sumidouro_vertedouro_p",
            "cobter_corpo_dagua_a": "cobter_massa_dagua_a",
            "cobter_massa_dagua_a": "cobter_massa_dagua_a",
            "cobter_vegetacao_a": "cobter_vegetacao_a",
            "infra_via_deslocamento_l": "infra_via_deslocamento_l",
            "cobter_area_edificada_a": "cobter_area_edificada_a",
            "constr_edificacao_a": "constr_edificacao_a",
            "constr_edificacao_p": "constr_edificacao_p",
            "elemnat_curva_nivel_l": "elemnat_curva_nivel_l",
            "elemnat_ponto_cotado_p": "elemnat_ponto_cotado_p",
            "aux_moldura_a": "aux_moldura_a"
        }
    },

    # -------------------------------------------------------------------------
    # EDGV 2.1.3 (Modelagem classica legada da DSG / SCN)
    # -------------------------------------------------------------------------
    "edgv_213": {
        "descricao": "EDGV Versao 2.1.3 Legada",
        "tabelas": {
            "drenagem": "hid_trecho_drenagem_l",
            "massa_dagua": "hid_massa_dagua_a",
            "vegetacao": "veg_floresta_a",
            "via_deslocamento": "tra_via_deslocamento_l",
            "rodovia": "tra_via_deslocamento_l",
            "ferrovia": "tra_ferrovia_l",
            "area_edificada": "edif_area_edificada_a",
            "edificacao_a": "edif_construcao_edificada_a",
            "edificacao_p": "edif_construcao_edificada_p",
            "curva_nivel": "rel_curva_nivel_l",
            "ponto_cotado": "rel_ponto_cotado_p",
            "moldura": "aux_moldura_a",
            "limite_especial": "loc_limite_especial_a",
            "localidade": "loc_localidade_p",

            # Chaves padrao do generalizador.py mapeadas para o equivalente 2.1.3
            "elemnat_trecho_drenagem_l": "hid_trecho_drenagem_l",
            "elemnat_sumidouro_vertedouro_p": "hid_sumidouro_vertedouro_p",
            "cobter_corpo_dagua_a": "hid_massa_dagua_a",
            "cobter_massa_dagua_a": "hid_massa_dagua_a",
            "cobter_vegetacao_a": "veg_floresta_a",
            "infra_via_deslocamento_l": "tra_via_deslocamento_l",
            "cobter_area_edificada_a": "edif_area_edificada_a",
            "constr_edificacao_a": "edif_construcao_edificada_a",
            "constr_edificacao_p": "edif_construcao_edificada_p",
            "elemnat_curva_nivel_l": "rel_curva_nivel_l",
            "aux_moldura_a": "aux_moldura_a"
        }
    }
}

# Palavras-chave de fallback caso a modelagem nao seja estritamente padrao DSG
KEYWORDS_FALLBACK = {
    "elemnat_trecho_drenagem_l": ["drenagem", "dren", "rio", "córrego", "correg"],
    "elemnat_sumidouro_vertedouro_p": ["sumidouro", "vertedouro", "sumid"],
    "cobter_corpo_dagua_a": ["massa", "dagua", "d_agua", "agua", "lago", "lagoa", "corpo_dagua", "represa"],
    "cobter_massa_dagua_a": ["massa", "dagua", "d_agua", "agua", "lago", "lagoa", "corpo_dagua", "represa"],
    "cobter_vegetacao_a": ["vegetacao", "veg", "floresta", "mata"],
    "infra_via_deslocamento_l": ["via_deslocamento", "rodovia", "trecho_rodov", "estrada", "arruamento", "rua"],
    "cobter_area_edificada_a": ["edificada", "mancha", "urbana", "aglomerado"],
    "constr_edificacao_a": ["edificacao", "edif", "construcao", "predio"],
    "constr_edificacao_p": ["edificacao", "edif", "construcao", "predio"],
    "elemnat_curva_nivel_l": ["curva", "nivel", "altimetria", "relevo", "isoipsa"],
    "aux_moldura_a": ["moldura", "limite_folha", "articulacao"]
}

# Candidatos para resolver atributos essenciais
ATRIBUTOS_CANONICOS = {
    "cota": ["cota", "altitude", "elevacao", "valor_cota"],
    "indice": ["indice", "tipo_curva"],
    "tipo": ["tipo", "classe", "funcao"],
    "nome": ["nome", "nm_edif", "denominacao", "toponimo", "sigla"]
}
