# -*- coding: utf-8 -*-
"""
Classe RepositorioModelagens e funcao de compatibilidade carregar_tabela_inteligente.
Garante total compatibilidade e adaptacao ao codigo do generalizador.py,
com saidas em texto limpo (sem emojis) compativeis com qualquer terminal Windows.
"""
from typing import Optional, List, Dict, Set
try:
    from .catalogo import CATALOGO_MODELAGENS, ATRIBUTOS_CANONICOS, KEYWORDS_FALLBACK
except ImportError:
    from catalogo import CATALOGO_MODELAGENS, ATRIBUTOS_CANONICOS, KEYWORDS_FALLBACK


class RepositorioModelagens:
    """
    Repositorio central para desacoplar seu codigo de generalizacao
    dos nomes fisicos de tabelas no banco de dados.
    """

    def __init__(self, engine=None, schema: str = "edgv", versao_forcada: Optional[str] = None):
        """
        :param engine: Engine SQLAlchemy ou conexao conectada ao banco (opcional).
        :param schema: Schema do banco (geralmente 'edgv' ou 'public').
        :param versao_forcada: Se informado, forca uma versao ('edgv_300_topo_14', 'edgv_213', etc.).
        """
        self.engine = engine
        self.schema = schema
        self.tabelas_no_banco: Set[str] = set()
        self.versao_detectada: Optional[str] = versao_forcada
        self._diagnostico_exibido = False

        if self.engine is not None:
            self._inspecionar_banco()
            if not self.versao_detectada:
                self.versao_detectada = self._detectar_versao_automatica()
        elif not self.versao_detectada:
            self.versao_detectada = "edgv_300_topo_14"

        self.mapa_atual: Dict[str, str] = CATALOGO_MODELAGENS.get(
            self.versao_detectada, {}
        ).get("tabelas", {})

    @property
    def descricao_versao(self) -> str:
        return CATALOGO_MODELAGENS.get(self.versao_detectada, {}).get("descricao", self.versao_detectada)

    def _inspecionar_banco(self):
        """Lista todas as tabelas fisicas presentes no schema informado."""
        try:
            from sqlalchemy import inspect
            insp = inspect(self.engine)
            tabelas = insp.get_table_names(schema=self.schema)
            if not tabelas and self.schema != "public":
                tabelas = insp.get_table_names(schema="public")
            self.tabelas_no_banco = {t.lower() for t in tabelas}
        except ImportError:
            pass
        except Exception as e:
            print(f"[-] Nao foi possivel inspecionar tabelas do banco: {e}")

    def _detectar_versao_automatica(self) -> str:
        """
        Descobre com precisao se o banco e Topo (1.4 / 2.0), Orto ou 2.1.3.
        Prioriza a tabela oficial da DSG 'public.db_metadata', seguida pela presenca
        de camadas de altimetria (curvas de nivel) exclusivas de Cartas Topograficas.
        """
        # 1. Consulta oficial a tabela de metadados da DSG (DSG Tools / SGC)
        if self.engine is not None:
            try:
                import pandas as pd
                df_meta = pd.read_sql("SELECT edgvversion, dbimplversion FROM public.db_metadata LIMIT 1", self.engine)
                if not df_meta.empty:
                    meta_row = df_meta.iloc[0]
                    v_edgv = str(meta_row.get('edgvversion', '')).lower()
                    v_impl = str(meta_row.get('dbimplversion', '')).lower()
                    
                    if "2.1.3" in v_edgv or "2.13" in v_edgv:
                        return "edgv_213"
                    if "orto" in v_edgv:
                        return "edgv_300_orto_25"
                    if "topo" in v_edgv:
                        if "2.0" in v_impl or "2.0" in v_edgv:
                            return "edgv_300_topo_20"
                        return "edgv_300_topo_14"
            except Exception:
                pass

        # 2. Analise de prefixos legados da EDGV 2.1.3
        if any(t.startswith("hid_") or t.startswith("tra_") or t.startswith("rel_") for t in self.tabelas_no_banco):
            return "edgv_213"

        # 3. Cartas Topograficas possuem obrigatoriamente altimetria (curvas de nivel / pontos cotados)
        if any("curva_nivel" in t or "ponto_cotado" in t for t in self.tabelas_no_banco):
            return "edgv_300_topo_14"

        # 4. Caso tenha delimitadores/centroides e NENHUMA altimetria (caracteristico de ortoimagem)
        if any("delimitador_" in t or "centroide_" in t for t in self.tabelas_no_banco):
            return "edgv_300_orto_25"

        return "edgv_300_topo_14"

    def imprimir_diagnostico_banco(self):
        """Exibe de forma destacada no terminal a modelagem do banco para o usuario."""
        if self._diagnostico_exibido:
            return
        self._diagnostico_exibido = True
        desc = self.descricao_versao
        total_banco = len(self.tabelas_no_banco)
        print("\n" + "=" * 70)
        print("  MODELAGEM IDENTIFICADA NO BANCO DE DADOS (DSG):")
        print(f"   -> Versao da Norma : {desc}")
        print(f"   -> Schema ativo    : '{self.schema}' ({total_banco} tabelas fisicas no banco)")
        print("   -> Status          : Camadas amarradas com sucesso ao catalogo oficial!")
        print("=" * 70 + "\n")

    def obter_tabela(self, conceito_ou_padrao: str) -> Optional[str]:
        """
        Retorna o nome real da tabela no banco para qualquer conceito ou chave do generalizador.
        """
        alvo = conceito_ou_padrao.lower()

        # 1. Busca direta no catalogo da versao detectada
        if alvo in self.mapa_atual:
            candidato = self.mapa_atual[alvo]
            if candidato is not None:
                if self.tabelas_no_banco:
                    if candidato.lower() in self.tabelas_no_banco:
                        return candidato
                else:
                    return candidato
            elif self.tabelas_no_banco and alvo in self.tabelas_no_banco:
                return alvo

        # 2. Se a tabela com este nome exato ja existe fisicamente no banco
        if self.tabelas_no_banco and alvo in self.tabelas_no_banco:
            return alvo

        # 3. Fallback inteligente com sufixo e palavras-chave
        sufixo_esperado = alvo[-2:] if alvo[-2:] in ['_l', '_a', '_p'] else None
        palavras_chave = KEYWORDS_FALLBACK.get(alvo, [alvo])
        termos_proibidos = ['centroide', 'delimitador', 'edicao', '_50k', '_100k', '_250k']

        for tabela in self.tabelas_no_banco:
            t_lower = tabela.lower()
            if any(p in t_lower for p in termos_proibidos):
                continue
            if sufixo_esperado and not t_lower.endswith(sufixo_esperado):
                continue
            for kw in palavras_chave:
                if kw in t_lower:
                    return tabela

        return None

    def obter_coluna(self, gdf, conceito_coluna: str) -> Optional[str]:
        """Localiza dinamicamente a coluna no GeoDataFrame."""
        candidatos = ATRIBUTOS_CANONICOS.get(conceito_coluna.lower(), [conceito_coluna])
        for c in candidatos:
            for col in gdf.columns:
                if c.lower() == col.lower() or c.lower() in col.lower():
                    return col
        return None

    def carregar_gdf(self, conceito_ou_padrao: str, epsg_utm: Optional[int] = None):
        """
        Carrega o GeoDataFrame diretamente do PostGIS.
        Retorna: (gdf, tabela_encontrada, crs_original)
        """
        import geopandas as gpd

        if self.engine is None:
            raise ValueError("Engine de conexao nao fornecido ao inicializar o repositorio.")

        tabela_encontrada = self.obter_tabela(conceito_ou_padrao)
        sufixo_esperado = conceito_ou_padrao[-2:] if conceito_ou_padrao[-2:] in ['_l', '_a', '_p'] else ""

        if not tabela_encontrada:
            print(f"  [AVISO] Nenhuma tabela compativel com '{conceito_ou_padrao}' (sufixo {sufixo_esperado}) foi localizada no schema '{self.schema}'.")
            return None, None, None

        print(f"  [+] Camada carregada [{self.versao_detectada}]: {conceito_ou_padrao} -> {tabela_encontrada}")

        query = f'SELECT * FROM "{self.schema}"."{tabela_encontrada}"'
        gdf = gpd.read_postgis(query, con=self.engine)

        if gdf.geometry.name != 'geom':
            gdf = gdf.rename_geometry('geom')

        crs_original = gdf.crs
        if not gdf.empty and gdf.crs is not None and epsg_utm:
            gdf = gdf.to_crs(epsg=epsg_utm)

        return gdf, tabela_encontrada, crs_original


# -----------------------------------------------------------------------------
# FUNCAO DE COMPATIBILIDADE DIRETA COM O GENERALIZADOR
# -----------------------------------------------------------------------------
_INSTANCIA_GLOBAL: Optional[RepositorioModelagens] = None

def carregar_tabela_inteligente(engine, schema, tipo_padrao, epsg_utm):
    """
    Substituto direto de carregar_tabela_inteligente() do generalizador.py.
    Utiliza o RepositorioModelagens sob o capo, mantendo exatamente a mesma assinatura.
    """
    global _INSTANCIA_GLOBAL
    if _INSTANCIA_GLOBAL is None or _INSTANCIA_GLOBAL.engine != engine or _INSTANCIA_GLOBAL.schema != schema:
        _INSTANCIA_GLOBAL = RepositorioModelagens(engine=engine, schema=schema)
        _INSTANCIA_GLOBAL.imprimir_diagnostico_banco()

    return _INSTANCIA_GLOBAL.carregar_gdf(tipo_padrao, epsg_utm=epsg_utm)
