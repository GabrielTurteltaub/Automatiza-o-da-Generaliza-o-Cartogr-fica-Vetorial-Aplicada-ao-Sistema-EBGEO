# -*- coding: utf-8 -*-
"""
Exemplo de demonstracao e teste do Repositorio de Modelagens
totalmente adaptado para as chaves do novo generalizador.py.
"""
from catalogo import CATALOGO_MODELAGENS
from repositorio import RepositorioModelagens

def main():
    print("=" * 72)
    print(" DEMONSTRACAO: REPOSITORIO ADAPTADO AO NOVO GENERALIZADOR.PY")
    print("=" * 72)

    # Chaves exatas que o seu generalizador.py chama no código:
    chaves_generalizador = [
        "elemnat_trecho_drenagem_l",
        "cobter_corpo_dagua_a",
        "cobter_vegetacao_a",
        "cobter_area_edificada_a",
        "infra_via_deslocamento_l",
        "constr_edificacao_a",
        "elemnat_curva_nivel_l"
    ]

    versoes = ["edgv_300_topo_14", "edgv_300_topo_20", "edgv_213", "edgv_300_orto_25"]

    for versao in versoes:
        repo = RepositorioModelagens(versao_forcada=versao)
        print(f"\n[+] BANCO DETECTADO: {CATALOGO_MODELAGENS[versao]['descricao']}")
        print("-" * 72)
        
        for chave in chaves_generalizador:
            tab_real = repo.obter_tabela(chave)
            status = tab_real if tab_real else "(Nao aplicavel nesta modelagem)"
            print(f"  * Chama: '{chave:<26}' -> No PostGIS le: '{status}'")

    print("\n" + "=" * 72)
    print("INTEGRACAO EM 1 LINHA NO SEU GENERALIZADOR.PY:")
    print("=" * 72)
    print("""
    No topo do seu src/generalizador.py, basta adicionar:

        import sys
        sys.path.append(r"src/repositorio_modelagens")
        from repositorio_modelagens import carregar_tabela_inteligente

    Pronto! O resto do seu script de 1130 linhas continua EXATAMENTE IGUAL,
    mas agora ele roda de forma multi-modelagem em qualquer banco da DSG!
    """)

if __name__ == "__main__":
    main()
