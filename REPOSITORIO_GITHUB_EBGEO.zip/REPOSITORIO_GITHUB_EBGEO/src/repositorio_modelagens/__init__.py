# -*- coding: utf-8 -*-
"""
Pacote Repositorio de Modelagens EDGV / DSG.
Permite ao codigo de generalizacao consultar camadas por conceito
independente da versao da modelagem do banco de dados (2.1.3, Topo 1.4, Topo 2.0, Orto, etc.).
"""
from .repositorio import RepositorioModelagens, carregar_tabela_inteligente
from .catalogo import CATALOGO_MODELAGENS, ATRIBUTOS_CANONICOS

__all__ = ["RepositorioModelagens", "carregar_tabela_inteligente", "CATALOGO_MODELAGENS", "ATRIBUTOS_CANONICOS"]
