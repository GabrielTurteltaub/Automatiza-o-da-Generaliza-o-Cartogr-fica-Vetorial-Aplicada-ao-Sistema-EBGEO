# -*- coding: utf-8 -*-
import os
import sys
from pathlib import Path

# Tentar carregar python-dotenv se disponivel
try:
    from dotenv import load_dotenv
    # Carrega .env da raiz do projeto ou da pasta config
    raiz_projeto = Path(__file__).resolve().parent.parent
    caminho_env = raiz_projeto / ".env"
    if caminho_env.exists():
        load_dotenv(caminho_env)
    else:
        caminho_env_cfg = raiz_projeto / "config" / ".env"
        if caminho_env_cfg.exists():
            load_dotenv(caminho_env_cfg)
except ImportError:
    pass

# Configuracoes de Banco de Dados PostGIS
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "AMAN")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")
DB_SCHEMA = os.getenv("DB_SCHEMA", "edgv")

# Sistema de Coordenadas e Região Padrão (UTM)
DEFAULT_EPSG = int(os.getenv("DEFAULT_EPSG", "31983"))

# Diretorios Principais
DIR_RAIZ = Path(__file__).resolve().parent.parent
DIR_DATA_INPUT = DIR_RAIZ / "data" / "input"
DIR_DATA_OUTPUT = DIR_RAIZ / "data" / "output"
DIR_DOCS = DIR_RAIZ / "docs"

def obter_string_conexao():
    import urllib.parse
    senha_encoded = urllib.parse.quote_plus(DB_PASSWORD)
    return f"postgresql://{DB_USER}:{senha_encoded}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
