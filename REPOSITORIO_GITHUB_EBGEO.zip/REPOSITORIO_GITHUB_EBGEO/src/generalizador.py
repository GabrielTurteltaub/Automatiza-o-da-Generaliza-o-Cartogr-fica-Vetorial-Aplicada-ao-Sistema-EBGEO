# -*- coding: utf-8 -*-
import os
import sys
import uuid

# Carregar variaveis de ambiente (.env)
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# Garante localizacao do banco de dados do PROJ caso nao esteja no PATH
if "PROJ_DATA" not in os.environ:
    possiveis_proj = [
        os.path.expanduser(r"~\minicondaa3\Library\share\proj"),
        os.path.expanduser(r"~\miniconda3\Library\share\proj"),
        os.path.join(os.environ.get("CONDA_PREFIX", ""), "Library", "share", "proj"),
    ]
    for p in possiveis_proj:
        if os.path.isdir(p):
            os.environ["PROJ_DATA"] = p
            break

import geopandas as gpd
import pandas as pd
from sqlalchemy import create_engine, inspect, text
import networkx as nx
import math
from shapely.ops import unary_union, linemerge, snap, nearest_points, polygonize, split
from shapely import set_precision
from shapely.geometry import Point, LineString, MultiLineString, Polygon, MultiPolygon, MultiPoint, LinearRing, box
from shapely.validation import make_valid
import re
from collections import Counter
import warnings

warnings.filterwarnings("ignore")

# =====================================================================
# INTEGRACAO COM O REPOSITORIO DE MODELAGENS DSG (PORTABILIDADE TOTAL)
# =====================================================================
_dir_atual = os.path.dirname(os.path.abspath(__file__))
_dir_raiz = os.path.abspath(os.path.join(_dir_atual, ".."))
possiveis_caminhos_repo = [
    _dir_atual,
    os.path.join(_dir_atual, "repositorio_modelagens"),
    _dir_raiz,
    os.path.join(_dir_raiz, "repositorio_modelagens"),
    os.path.join(_dir_raiz, "src", "repositorio_modelagens")
]
for p in possiveis_caminhos_repo:
    if os.path.isdir(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    from repositorio_modelagens import RepositorioModelagens, carregar_tabela_inteligente as _carregar_tabela_repo
    TEM_REPOSITORIO = True
except Exception:
    TEM_REPOSITORIO = False

# =====================================================================
# CONFIGURACOES E DICIONARIOS
# =====================================================================

KEYWORDS_MAP = {
    "elemnat_trecho_drenagem_l": ["drenagem", "dren", "rio", "corrego", "correg"],
    "elemnat_sumidouro_vertedouro_p": ["sumidouro", "vertedouro", "sumid"],
    "cobter_corpo_dagua_a": ["massa", "dagua", "d_agua", "agua", "lago", "lagoa", "corpo_dagua", "represa"],
    "cobter_vegetacao_a": ["vegetacao", "veg", "floresta", "mata"],
    "infra_via_deslocamento_l": ["via_deslocamento", "rodovia", "trecho_rodov", "estrada", "arruamento", "rua"],
    "cobter_area_edificada_a": ["edificada", "mancha", "urbana", "aglomerado"],
    "constr_edificacao_a": ["edificacao", "edif", "construcao", "predio"],
    "constr_edificacao_p": ["edificacao", "edif", "construcao", "predio"],
    "elemnat_curva_nivel_l": ["curva", "nivel", "altimetria", "relevo", "isoipsa"],
    "elemnat_ponto_cotado_p": ["ponto_cotado", "cotado", "cota_ponto", "ponto_altimetrico"],
    "aux_moldura_a": ["moldura", "limite_folha", "articulacao"]
}

# =====================================================================
# FUNCOES UTILITARIAS
# =====================================================================

def achar_coluna(gdf, candidatos):
    for c in candidatos:
        for col in gdf.columns:
            if c.lower() in col.lower():
                return col
    return None

def obter_parametros(escala, tipo_camada):
    """
    Parametros normativos estritos da ET-ADGV 3.0 (EB80-N-72.005, Tabela 1):
    - Drenagem e Vias (Linha): D >= 10 mm na carta
        * 1:50.000:  10 mm = 500 m
        * 1:100.000: 10 mm = 1.000 m
        * 1:250.000: 10 mm = 2.500 m
    - Cobertura do Solo e Vegetacao (Area): s >= 25 mm2 na carta
        * 1:50.000:  25 * (50m)^2  = 62.500 m2 (6,25 ha)
        * 1:100.000: 25 * (100m)^2 = 250.000 m2 (25 ha)
        * 1:250.000: 25 * (250m)^2 = 1.562.500 m2 (156,25 ha)
    - Massa d'Agua / Corpos d'Agua (Area): s >= 4 mm2 na carta (2mm x 2mm)
        * 1:50.000:  4 * (50m)^2  = 10.000 m2 (1 ha)
        * 1:100.000: 4 * (100m)^2 = 40.000 m2 (4 ha)
        * 1:250.000: 4 * (250m)^2 = 250.000 m2 (25 ha)
    - Edificacao (Poligono): s >= 1 mm2 na carta (menor passa para ponto)
        * 1:50.000:  1 * (50m)^2  = 2.500 m2
        * 1:100.000: 1 * (100m)^2 = 10.000 m2
        * 1:250.000: 0.0 (edificacoes normais suprimidas, mantendo notaveis)
    - Curvas de Nivel (Equidistancia Altimetrica DSG):
        * 1:50.000:  20 m (Mestra: multiplo de 100 m, Perimetro Minimo Fechada = 600 m)
        * 1:100.000: 50 m (Mestra: multiplo de 250 m, Perimetro Minimo Fechada = 1.200 m)
        * 1:250.000: 100 m (Mestra: multiplo de 500 m, Perimetro Minimo Fechada = 3.000 m)
    - Pontos Cotados Altimetricos (Espacamento Grafico Minimo DSG 20 mm de carta):
        * 1:50.000:  1.000 m
        * 1:100.000: 2.000 m
        * 1:250.000: 5.000 m
    """
    p = {
        "tol": 5.0,
        "edif_min": 2500.0,
        "solo_min": 62500.0,
        "massa_min": 10000.0,
        "curva_eq": 20.0,
        "curva_mestra": 100.0,
        "curva_fechada_min": 600.0,
        "pto_cotado_dist": 1000.0,
        "rede_min": 500.0
    }
    
    if escala == "50":
        p.update({
            "tol": 5.0,
            "edif_min": 2500.0,
            "solo_min": 62500.0,
            "massa_min": 10000.0,
            "curva_eq": 20.0,
            "curva_mestra": 100.0,
            "curva_fechada_min": 600.0,
            "pto_cotado_dist": 1000.0,
            "rede_min": 500.0
        })
    elif escala == "100":
        p.update({
            "tol": 12.0,
            "edif_min": 10000.0,
            "solo_min": 250000.0,
            "massa_min": 40000.0,
            "curva_eq": 50.0,
            "curva_mestra": 250.0,
            "curva_fechada_min": 1200.0,
            "pto_cotado_dist": 2000.0,
            "rede_min": 1000.0
        })
    elif escala == "250":
        p.update({
            "tol": 20.0,
            "edif_min": 0.0,
            "solo_min": 1562500.0,
            "massa_min": 250000.0,
            "curva_eq": 100.0,
            "curva_mestra": 500.0,
            "curva_fechada_min": 3000.0,
            "pto_cotado_dist": 5000.0,
            "rede_min": 2500.0
        })
        
    return p

def garantir_multi(geom, tipo):
    if geom is None or geom.is_empty: 
        return geom
        
    if tipo == 'linha':
        if geom.geom_type == 'LineString': 
            return MultiLineString([geom])
        elif geom.geom_type == 'MultiLineString': 
            return geom
            
    elif tipo == 'poligono':
        if geom.geom_type == 'GeometryCollection':
            polys = [g for g in geom.geoms if g.geom_type in ['Polygon', 'MultiPolygon']]
            geom = unary_union(polys) if polys else None
            if geom is None or geom.is_empty:
                return None
                
        if geom.geom_type == 'Polygon': 
            return MultiPolygon([geom])
        elif geom.geom_type == 'MultiPolygon': 
            return geom
            
    elif tipo == 'ponto':
        if geom.geom_type == 'Point': 
            return MultiPoint([geom])
        elif geom.geom_type == 'MultiPoint': 
            return geom
            
    return geom

def _calcular_angulo_interno_graus(p_ant, p_atual, p_prox):
    """
    Calcula o angulo interno (0 a 180 graus) formado no vertice p_atual
    pelos vetores (p_atual -> p_ant) e (p_atual -> p_prox).
    Angulos < 10 graus sao classificados pelo DSGTools como espiculas (spikes).
    """
    ux, uy = p_ant[0] - p_atual[0], p_ant[1] - p_atual[1]
    vx, vy = p_prox[0] - p_atual[0], p_prox[1] - p_atual[1]
    nu = math.hypot(ux, uy)
    nv = math.hypot(vx, vy)
    if nu < 1e-12 or nv < 1e-12:
        return 0.0
    cos_ang = max(-1.0, min(1.0, (ux * vx + uy * vy) / (nu * nv)))
    return math.degrees(math.acos(cos_ang))


def limpar_espiculas_coords(coords, eh_anel=False, min_dist=1e-7, min_ang_graus=12.0, angulo_min_graus=None):
    if angulo_min_graus is not None:
        min_ang_graus = angulo_min_graus
    """
    Remove iterativamente vertices consecutivos duplicados (< min_dist) e
    espiculas / angulos agudos (< min_ang_graus, padrao DSG = 10 graus).
    Preserva estritamente os nos extremos de linhas abertas.
    """
    if not coords:
        return coords
    pts = [(float(c[0]), float(c[1])) for c in coords]

    if eh_anel:
        if len(pts) < 4:
            return coords
        if pts[0] == pts[-1]:
            pts = pts[:-1]
        mudou = True
        iter_count = 0
        while mudou and len(pts) >= 3 and iter_count < 25:
            mudou = False
            iter_count += 1
            novos = []
            n = len(pts)
            for i in range(n):
                p_ant = novos[-1] if novos else pts[(i - 1) % n]
                p_at = pts[i]
                p_pr = pts[(i + 1) % n]
                if math.hypot(p_at[0] - p_ant[0], p_at[1] - p_ant[1]) <= min_dist:
                    mudou = True
                    continue
                ang = _calcular_angulo_interno_graus(p_ant, p_at, p_pr)
                if ang < min_ang_graus and len(pts) > 3:
                    mudou = True
                    continue
                novos.append(p_at)
            pts = novos
        if len(pts) >= 3:
            if math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) <= min_dist and len(pts) > 3:
                pts = pts[:-1]
            if len(pts) > 3:
                ang0 = _calcular_angulo_interno_graus(pts[-1], pts[0], pts[1])
                if ang0 < min_ang_graus:
                    pts = pts[1:]
            if len(pts) >= 3:
                pts.append(pts[0])
                return pts
        return coords
    else:
        if len(pts) < 2:
            return coords
        if pts[0] == pts[-1] and len(pts) >= 4:
            return limpar_espiculas_coords(pts, eh_anel=True, min_dist=min_dist, min_ang_graus=min_ang_graus)

        mudou = True
        iter_count = 0
        while mudou and len(pts) >= 3 and iter_count < 25:
            mudou = False
            iter_count += 1
            novos = [pts[0]]
            for i in range(1, len(pts) - 1):
                p_ant = novos[-1]
                p_at = pts[i]
                p_pr = pts[i + 1]
                if math.hypot(p_at[0] - p_ant[0], p_at[1] - p_ant[1]) <= min_dist:
                    mudou = True
                    continue
                if math.hypot(p_at[0] - p_pr[0], p_at[1] - p_pr[1]) <= min_dist:
                    mudou = True
                    continue
                ang = _calcular_angulo_interno_graus(p_ant, p_at, p_pr)
                if ang < min_ang_graus:
                    mudou = True
                    continue
                novos.append(p_at)
            novos.append(pts[-1])
            pts = novos
        return pts


def _coletar_polys_lista(geom, destino):
    if geom is None or geom.is_empty:
        return
    if geom.geom_type == 'Polygon':
        if geom.area > 0.0:
            destino.append(geom)
    elif geom.geom_type in ['MultiPolygon', 'GeometryCollection']:
        for g in geom.geoms:
            _coletar_polys_lista(g, destino)


def _coletar_lines_lista(geom, destino):
    if geom is None or geom.is_empty:
        return
    if geom.geom_type in ['LineString', 'LinearRing']:
        if geom.length > 0.0:
            destino.append(LineString(geom.coords))
    elif geom.geom_type in ['MultiLineString', 'GeometryCollection']:
        for g in geom.geoms:
            _coletar_lines_lista(g, destino)


def desatar_aneis_tocantes_poligono(geom, min_dist=1e-7, min_ang_graus=0.5):
    """
    Garante conformidade estrita com QgsGeometryValidator (QgisInternal) e
    analyze_polygon_boundary_and_holes do DSGTools:
    1. Remove nos duplicados e espiculas (< min_ang_graus);
    2. Decompoe aneis exteriores em '8' (auto-tangentes) em poligonos simples separados;
    3. Se um anel interno (buraco) tocar o anel exterior ou outro buraco em um vertice,
       secciona o poligono passando pelo interior do buraco priorizando vertices existentes,
       eliminando 100% das flags 'Self intersection between hole and boundary' e
       'Ring self-intersection' com variacao ZERO de area (0 gaps e 0 overlaps).
    """
    if geom is None or geom.is_empty:
        return []

    if not geom.is_valid:
        geom = make_valid(geom)

    polys_iniciais = []
    _coletar_polys_lista(geom, polys_iniciais)

    fila = []
    for p in polys_iniciais:
        ext_c = limpar_espiculas_coords(list(p.exterior.coords), eh_anel=True, min_dist=min_dist, min_ang_graus=min_ang_graus)
        if len(ext_c) < 4:
            continue
        holes_c = []
        for h in p.interiors:
            hc = limpar_espiculas_coords(list(h.coords), eh_anel=True, min_dist=min_dist, min_ang_graus=min_ang_graus)
            if len(hc) >= 4:
                hp = Polygon(hc)
                if hp.is_valid and hp.area > 0.0:
                    holes_c.append(hc)
        try:
            p_limpo = Polygon(ext_c, holes_c)
            if not p_limpo.is_valid:
                p_limpo = make_valid(p_limpo)
            _coletar_polys_lista(p_limpo, fila)
        except Exception:
            fila.append(p)

    resultado = []
    max_splits = 40
    splits_feitos = 0

    while fila:
        poly = fila.pop(0)
        if poly is None or poly.is_empty or poly.area <= 0.0:
            continue
        if not poly.is_valid:
            v = make_valid(poly)
            _coletar_polys_lista(v, fila)
            continue

        # 1. Verifica se o anel exterior toca a si mesmo (figura em 8)
        ext_line = LineString(poly.exterior.coords)
        if not ext_line.is_simple:
            faces_ext = list(polygonize(unary_union(ext_line)))
            if len(faces_ext) > 1:
                holes_union = unary_union([Polygon(h) for h in poly.interiors]) if poly.interiors else None
                for f in faces_ext:
                    f_final = f.difference(holes_union) if (holes_union is not None and not holes_union.is_empty) else f
                    _coletar_polys_lista(f_final, fila)
                continue

        if len(poly.interiors) == 0 or splits_feitos >= max_splits:
            resultado.append(poly)
            continue

        # 2. Verifica se algum buraco toca o exterior ou toca outro buraco
        buraco_ofensor = None
        pt_toque = None
        holes_lines = [LineString(h.coords) for h in poly.interiors]
        for idx_h, hl in enumerate(holes_lines):
            if hl.intersects(ext_line) or not hl.is_simple:
                buraco_ofensor = idx_h
                inter_pt = hl.intersection(ext_line)
                if not inter_pt.is_empty:
                    if inter_pt.geom_type == 'Point':
                        pt_toque = (inter_pt.x, inter_pt.y)
                    elif hasattr(inter_pt, 'geoms') and len(inter_pt.geoms) > 0:
                        g0 = inter_pt.geoms[0]
                        if g0.geom_type == 'Point':
                            pt_toque = (g0.x, g0.y)
                break
            for idx_h2 in range(idx_h + 1, len(holes_lines)):
                if hl.intersects(holes_lines[idx_h2]):
                    buraco_ofensor = idx_h
                    break
            if buraco_ofensor is not None:
                break

        if buraco_ofensor is None:
            resultado.append(poly)
            continue

        # 3. Secciona o poligono atraves do buraco ofensor priorizando vertices existentes
        splits_feitos += 1
        h_ring = poly.interiors[buraco_ofensor]
        h_poly = Polygon(h_ring)
        pt_in = h_poly.representative_point()
        cortou = False

        if pt_toque is not None:
            pts_h = list(h_ring.coords)[:-1]
            pts_ext = list(poly.exterior.coords)[:-1]
            pts_h_ord = sorted(pts_h, key=lambda c: math.hypot(c[0] - pt_toque[0], c[1] - pt_toque[1]), reverse=True)
            for vh in pts_h_ord[:8]:
                if math.hypot(vh[0] - pt_toque[0], vh[1] - pt_toque[1]) <= min_dist * 10:
                    continue
                pts_ext_ord = sorted(pts_ext, key=lambda c: math.hypot(c[0] - vh[0], c[1] - vh[1]))
                for ve in pts_ext_ord[:15]:
                    if math.hypot(ve[0] - pt_toque[0], ve[1] - pt_toque[1]) <= min_dist * 10:
                        continue
                    seg_interno = LineString([vh, ve])
                    if poly.covers(seg_interno):
                        linha_corte = LineString([pt_toque, (pt_in.x, pt_in.y), vh, ve])
                        try:
                            partes = split(poly, linha_corte)
                            novas_partes = []
                            _coletar_polys_lista(partes, novas_partes)
                            if len(novas_partes) > 1:
                                fila.extend(novas_partes)
                                cortou = True
                                break
                        except Exception:
                            pass
                if cortou:
                    break

        if not cortou:
            minx, miny, maxx, maxy = poly.bounds
            span = max(maxx - minx, maxy - miny) + 10.0
            for ang_corte in [0.0, 90.0, 45.0, 135.0, 22.5, 67.5, 112.5, 157.5]:
                rad = math.radians(ang_corte)
                dx, dy = math.cos(rad) * span, math.sin(rad) * span
                linha_corte = LineString([(pt_in.x - dx, pt_in.y - dy), (pt_in.x + dx, pt_in.y + dy)])
                try:
                    partes = split(poly, linha_corte)
                    novas_partes = []
                    _coletar_polys_lista(partes, novas_partes)
                    if len(novas_partes) > 1:
                        fila.extend(novas_partes)
                        cortou = True
                        break
                except Exception:
                    pass

        if not cortou:
            novos_holes = [h for i, h in enumerate(poly.interiors) if i != buraco_ofensor]
            p_base = Polygon(poly.exterior, novos_holes).difference(h_poly.buffer(min_dist * 2.0))
            _coletar_polys_lista(p_base, resultado)

    return resultado


def _anel_valido_dsg(poly):
    """Verifica se um Polygon atende simultaneamente ao GEOS, QgisInternal e analyze_polygon_boundary_and_holes."""
    if poly is None or poly.is_empty or not poly.is_valid or poly.geom_type != 'Polygon':
        return False
    ext_line = LineString(poly.exterior.coords)
    if not ext_line.is_simple:
        return False
    holes_lines = [LineString(h.coords) for h in poly.interiors]
    for i, hl in enumerate(holes_lines):
        if not hl.is_simple or hl.intersects(ext_line):
            return False
        for j in range(i + 1, len(holes_lines)):
            if hl.intersects(holes_lines[j]):
                return False
    return True


def sanitizar_gdf_para_dsg(gdf, dim_esperada=None, tol_area_min=0.0, remover_duplicadas=True):
    """
    Sanitizacao final do GeoDataFrame no CRS de destino antes da gravacao no PostGIS:
    - Garante que cada feicao seja estritamente uniparte empacotada em Multi* (ST_NumGeometries = 1),
      zerando flags de 'Identificar Geometrias com Mais de Uma Parte' e de 'Ring self-intersection';
    - Remove vertices consecutivos duplicados e espiculas (< 11 graus);
    - Desata aneis internos que toquem a borda externa (0 flags no QGIS/DSGTools);
    - Remove geometrias duplicadas (IdentifyDuplicatedGeometries = 0 flags).
    """
    if gdf is None or gdf.empty:
        return gdf

    eh_geografico = (gdf.crs is not None and gdf.crs.is_geographic)
    min_dist = 1e-8 if eh_geografico else 0.01
    min_ang = 0.5
    vistos = set()

    linhas_limpas = []
    for _, row in gdf.iterrows():
        geom = row.get('geom', None)
        if geom is None or geom.is_empty:
            continue
        gtype = geom.geom_type

        if 'Polygon' in gtype or (gtype == 'GeometryCollection' and dim_esperada in (None, 3)):
            polys = desatar_aneis_tocantes_poligono(geom, min_dist=min_dist, min_ang_graus=min_ang)
            for p in polys:
                if p is not None and not p.is_empty and p.is_valid and p.area > tol_area_min:
                    ext_c = limpar_espiculas_coords(list(p.exterior.coords), eh_anel=True, min_dist=min_dist, min_ang_graus=min_ang)
                    if len(ext_c) < 4:
                        continue
                    holes_c = []
                    for h in p.interiors:
                        hc = limpar_espiculas_coords(list(h.coords), eh_anel=True, min_dist=min_dist, min_ang_graus=min_ang)
                        if len(hc) >= 4:
                            holes_c.append(hc)
                    p_clean = Polygon(ext_c, holes_c)
                    if not _anel_valido_dsg(p_clean):
                        sub_ps = desatar_aneis_tocantes_poligono(p_clean, min_dist=min_dist, min_ang_graus=min_ang)
                    else:
                        sub_ps = [p_clean]
                    for sp in sub_ps:
                        if sp is None or sp.is_empty or not sp.is_valid or sp.area <= tol_area_min:
                            continue
                        if remover_duplicadas:
                            k_wkb = sp.normalize().wkb
                            if k_wkb in vistos:
                                continue
                            vistos.add(k_wkb)
                        r_dict = row.to_dict()
                        r_dict['id'] = str(uuid.uuid4())
                        r_dict['geom'] = MultiPolygon([sp])
                        linhas_limpas.append(r_dict)

        elif 'Line' in gtype or (gtype == 'GeometryCollection' and dim_esperada == 2):
            partes_l = []
            _coletar_lines_lista(geom, partes_l)
            for l in partes_l:
                coords_l = limpar_espiculas_coords(list(l.coords), eh_anel=False, min_dist=min_dist, min_ang_graus=min_ang)
                if len(coords_l) < 2:
                    continue
                l_limpa = LineString(coords_l)
                if l_limpa.is_empty or l_limpa.length <= min_dist:
                    continue
                if not l_limpa.is_simple:
                    u_l = unary_union(l_limpa)
                    sub_l = []
                    _coletar_lines_lista(u_l, sub_l)
                    for sl in sub_l:
                        coords_sl = limpar_espiculas_coords(list(sl.coords), eh_anel=False, min_dist=min_dist, min_ang_graus=min_ang)
                        if len(coords_sl) >= 2:
                            sl_clean = LineString(coords_sl)
                            if sl_clean.length > min_dist and sl_clean.is_simple:
                                if remover_duplicadas:
                                    k_wkb = sl_clean.normalize().wkb
                                    if k_wkb in vistos:
                                        continue
                                    vistos.add(k_wkb)
                                r_dict = row.to_dict()
                                r_dict['id'] = str(uuid.uuid4())
                                r_dict['geom'] = MultiLineString([sl_clean])
                                linhas_limpas.append(r_dict)
                else:
                    if remover_duplicadas:
                        k_wkb = l_limpa.normalize().wkb
                        if k_wkb in vistos:
                            continue
                        vistos.add(k_wkb)
                    r_dict = row.to_dict()
                    r_dict['id'] = str(uuid.uuid4())
                    r_dict['geom'] = MultiLineString([l_limpa])
                    linhas_limpas.append(r_dict)

        elif 'Point' in gtype or (gtype == 'GeometryCollection' and dim_esperada == 1):
            pts = list(geom.geoms) if hasattr(geom, 'geoms') else [geom]
            for pt in pts:
                if pt is not None and not pt.is_empty and pt.geom_type == 'Point':
                    if remover_duplicadas:
                        k_pt = (round(pt.x, 7), round(pt.y, 7))
                        if k_pt in vistos:
                            continue
                        vistos.add(k_pt)
                    r_dict = row.to_dict()
                    r_dict['id'] = str(uuid.uuid4())
                    r_dict['geom'] = MultiPoint([pt])
                    linhas_limpas.append(r_dict)

    if not linhas_limpas:
        return gdf.iloc[0:0].copy()
    return gpd.GeoDataFrame(linhas_limpas, crs=gdf.crs, geometry='geom')


def salvar_no_banco(gdf, tabela, engine, schema):
    """Wrapper compativel com o ValidadorDSG para gravacao sanitizada no PostGIS."""
    return salvar_e_habilitar_edicao_postgis(gdf, engine, schema, tabela, gdf.crs if gdf is not None else None)


def salvar_e_habilitar_edicao_postgis(gdf, engine, schema, tabela, crs_orig):
    """
    Grava o GeoDataFrame no PostGIS e cria automaticamente uma chave primaria (SERIAL PRIMARY KEY)
    permitindo que a camada seja imediatamente editavel no QGIS (habilita o lapis de edicao).
    """
    if gdf is None or gdf.empty:
        return
        
    gdf_salvar = gdf.copy()
    if crs_orig is not None and gdf_salvar.crs != crs_orig:
        gdf_salvar = gdf_salvar.to_crs(crs_orig)

    gdf_salvar = sanitizar_gdf_para_dsg(gdf_salvar)
        
    # Remove 'gid' existente no dataframe para evitar conflito com a sequence PK
    if 'gid' in gdf_salvar.columns:
        gdf_salvar.drop(columns=['gid'], inplace=True)

    # Remove colunas temporarias e garante que nenhum campo tecnico vaze
    cols_drop = [c for c in gdf_salvar.columns if c.startswith('_') or c.endswith('_temp')]
    if cols_drop:
        gdf_salvar.drop(columns=cols_drop, inplace=True, errors='ignore')

    # Garantir que toda feicao tenha um UUID valido no campo 'id' (norma EDGV 3.0)
    if 'id' in gdf_salvar.columns:
        gdf_salvar['id'] = gdf_salvar['id'].apply(
            lambda x: str(uuid.uuid4()) if pd.isna(x) or str(x).strip() in ['', 'None', 'nan', 'NULL'] else str(x)
        )

    # Suprime qualquer feicao residual espuria
    if 'nome' in gdf_salvar.columns:
        gdf_salvar = gdf_salvar[gdf_salvar['nome'].astype(str) != 'Conexao_Topologica'].copy()
        
    gdf_salvar.to_postgis(name=tabela, con=engine, schema=schema, if_exists='replace', index=False)
    
    try:
        with engine.begin() as conn:
            conn.execute(text(f'ALTER TABLE "{schema}"."{tabela}" ADD COLUMN IF NOT EXISTS gid SERIAL PRIMARY KEY;'))
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS sidx_{tabela}_geom ON "{schema}"."{tabela}" USING GIST(geom);'))
            conn.execute(text(f'ANALYZE "{schema}"."{tabela}";'))
    except Exception:
        try:
            with engine.begin() as conn:
                conn.execute(text(f'ALTER TABLE "{schema}"."{tabela}" ADD PRIMARY KEY (gid);'))
                conn.execute(text(f'CREATE INDEX IF NOT EXISTS sidx_{tabela}_geom ON "{schema}"."{tabela}" USING GIST(geom);'))
                conn.execute(text(f'ANALYZE "{schema}"."{tabela}";'))
        except Exception:
            pass

def preservar_atributos_dissolve(gdf, colunas_agrupar):
    cols_existentes = [c for c in colunas_agrupar if c in gdf.columns]
    if not cols_existentes:
        cols_existentes = ['_dummy_id']
        gdf['_dummy_id'] = 1

    outras_cols = [c for c in gdf.columns if c not in cols_existentes and c != 'geom']
    agg_dict = {c: 'first' for c in outras_cols}

    df_temp = gdf.copy()
    for c in cols_existentes:
        df_temp[c] = df_temp[c].fillna("<<NULL>>")

    gdf_dissolvido = df_temp.dissolve(by=cols_existentes, aggfunc=agg_dict, as_index=False)

    for c in cols_existentes:
        gdf_dissolvido[c] = gdf_dissolvido[c].replace("<<NULL>>", None)

    if '_dummy_id' in gdf_dissolvido.columns:
        gdf_dissolvido.drop(columns=['_dummy_id'], inplace=True)
        cols_existentes = []

    return gdf_dissolvido, cols_existentes

def aplicar_linemerge(gdf):
    linhas_soldadas = []
    for _, row in gdf.iterrows():
        geom = row['geom']
        if geom is None or geom.is_empty: continue
        try:
            geom_merge = linemerge(geom)
        except Exception:
            geom_merge = geom

        if geom_merge.geom_type == 'MultiLineString':
            for g in geom_merge.geoms:
                nova_linha = row.to_dict()
                nova_linha['geom'] = g
                linhas_soldadas.append(nova_linha)
        elif geom_merge.geom_type == 'LineString':
            nova_linha = row.to_dict()
            nova_linha['geom'] = geom_merge
            linhas_soldadas.append(nova_linha)
            
    return gpd.GeoDataFrame(linhas_soldadas, crs=gdf.crs, geometry='geom')

def fundir_apenas_pseudonos(gdf, cols_agrupar):
    """
    Funde segmentos contiguos que possuem os mesmos atributos APENAS em pseudonos
    (nos com grau == 2 em toda a malha planar). Preserva 100% dos entroncamentos
    e confluencias (grau >= 3) quebrados nos nos exatos (regra topologica ET-CQDG).
    """
    if gdf is None or gdf.empty:
        return gdf
    gdf_exp = gdf.explode(index_parts=False).reset_index(drop=True)
    gdf_exp = gdf_exp[gdf_exp['geom'].notna() & ~gdf_exp['geom'].is_empty & (gdf_exp['geom'].geom_type == 'LineString')].copy().reset_index(drop=True)
    if gdf_exp.empty:
        return gdf_exp

    grau_global = Counter()
    for geom in gdf_exp['geom']:
        coords = list(geom.coords)
        p1 = (round(coords[0][0], 3), round(coords[0][1], 3))
        p2 = (round(coords[-1][0], 3), round(coords[-1][1], 3))
        grau_global[p1] += 1
        grau_global[p2] += 1

    cols_existentes = [c for c in cols_agrupar if c in gdf_exp.columns]
    def chave_atrib(row):
        if not cols_existentes:
            return ()
        return tuple(None if pd.isna(row[c]) else str(row[c]).strip() for c in cols_existentes)

    gdf_exp['_attr_key'] = gdf_exp.apply(chave_atrib, axis=1)

    linhas_finais = []
    for _, group in gdf_exp.groupby('_attr_key', dropna=False):
        G_grp = nx.MultiGraph()
        dummy_counter = 0
        for idx, row in group.iterrows():
            geom = row['geom']
            coords = list(geom.coords)
            p1 = (round(coords[0][0], 3), round(coords[0][1], 3))
            p2 = (round(coords[-1][0], 3), round(coords[-1][1], 3))
            n1 = p1 if grau_global[p1] == 2 else ("FIXED", dummy_counter, p1)
            if grau_global[p1] != 2:
                dummy_counter += 1
            n2 = p2 if grau_global[p2] == 2 else ("FIXED", dummy_counter, p2)
            if grau_global[p2] != 2:
                dummy_counter += 1
            G_grp.add_edge(n1, n2, key=idx, geom=geom, row=row)

        for comp in nx.connected_components(G_grp):
            sub = G_grp.subgraph(comp)
            edges_geoms = [d['geom'] for _, _, d in sub.edges(data=True)]
            first_row = next(iter(sub.edges(data=True)))[2]['row'].to_dict()
            first_row.pop('_attr_key', None)

            # Preservar atributos completos da feicao ao longo de todos os segmentos fundidos
            for _, _, d_edge in sub.edges(data=True):
                r_dict = d_edge['row'].to_dict()
                for col_k, val_k in r_dict.items():
                    if col_k != 'geom' and (first_row.get(col_k) is None or pd.isna(first_row.get(col_k))):
                        if val_k is not None and pd.notna(val_k):
                            first_row[col_k] = val_k

            if 'id' in first_row and (pd.isna(first_row['id']) or str(first_row['id']).strip() in ['', 'None', 'nan', 'NULL']):
                first_row['id'] = str(uuid.uuid4())

            if len(edges_geoms) == 1:
                first_row['geom'] = edges_geoms[0]
                linhas_finais.append(first_row)
            else:
                merged = linemerge(edges_geoms)
                if merged.geom_type == 'LineString':
                    first_row['geom'] = merged
                    linhas_finais.append(first_row)
                elif merged.geom_type == 'MultiLineString':
                    for g in merged.geoms:
                        r_copy = dict(first_row)
                        r_copy['geom'] = g
                        linhas_finais.append(r_copy)

    return gpd.GeoDataFrame(linhas_finais, crs=gdf.crs, geometry='geom')

def quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0):
    """
    Nodificacao Planar Real (Shapely).
    Garante que toda bifurcacao em 'T' ou cruzamento gere um no topologico real,
    eliminando falsos graus 1. Extrai estritamente linhas.
    Se snap_tol > 0, fecha micro-gaps de projecao em entroncamentos em 'T'.
    """
    if gdf.empty:
        return gdf
        
    gdf_exploded = gdf.explode(index_parts=False).reset_index(drop=True)
    linhas = gdf_exploded['geom'].tolist()
    
    u_raw = unary_union(linhas)
    if snap_tol > 0.0:
        snapped = snap(u_raw, u_raw, snap_tol)
        noded_geom = unary_union(set_precision(snapped, 0.1))
    else:
        noded_geom = u_raw
    
    if noded_geom.geom_type == 'MultiLineString':
        segmentos = list(noded_geom.geoms)
    elif noded_geom.geom_type == 'LineString':
        segmentos = [noded_geom]
    elif noded_geom.geom_type == 'GeometryCollection':
        segmentos = []
        for g in noded_geom.geoms:
            if g.geom_type == 'LineString':
                segmentos.append(g)
            elif g.geom_type == 'MultiLineString':
                segmentos.extend(list(g.geoms))
    else:
        return gdf.copy()
        
    if snap_tol > 0.0:
        segmentos = [s for s in segmentos if s is not None and not s.is_empty and s.length > 0.05]
        
    gdf_noded = gpd.GeoDataFrame({'geom': segmentos}, geometry='geom', crs=gdf.crs)
    gdf_noded['pt_mid'] = gdf_noded['geom'].interpolate(0.5, normalized=True)
    gdf_pts = gdf_noded.copy()
    buf_join = 0.2 if snap_tol > 0.0 else 0.01
    gdf_pts['geom'] = gdf_pts['pt_mid'].buffer(buf_join) 
    
    joined = gpd.sjoin(gdf_pts, gdf_exploded, how='inner', predicate='intersects')
    joined = joined.loc[~joined.index.duplicated(keep='first')]
    
    cols_to_drop = ['geom', 'pt_mid', 'index_right']
    joined = joined.drop(columns=[c for c in cols_to_drop if c in joined.columns])
    
    gdf_final = gdf_noded[['geom']].join(joined, how='inner')
    return gdf_final.reset_index(drop=True)

def extrair_nos_topologicos(gdf):
    todas_coords = []
    for geom in gdf['geom']:
        if geom is None or geom.is_empty: continue
        if geom.geom_type == 'LineString':
            coords = [(round(c[0], 2), round(c[1], 2)) for c in geom.coords]
            todas_coords.extend(list(set(coords))) 
            todas_coords.append(coords[0]) 
            todas_coords.append(coords[-1])
        elif geom.geom_type == 'MultiLineString':
            for g in geom.geoms:
                coords = [(round(c[0], 2), round(c[1], 2)) for c in g.coords]
                todas_coords.extend(list(set(coords)))
                todas_coords.append(coords[0])
                todas_coords.append(coords[-1])
                
    contagem = Counter(todas_coords)
    return {coord for coord, count in contagem.items() if count > 1}

def suavizar_linha_chaikin(geom, iteracoes=1):
    if geom is None or geom.is_empty:
        return geom
    if geom.geom_type == 'MultiLineString':
        partes = [suavizar_linha_chaikin(part, iteracoes) for part in geom.geoms]
        partes = [p for p in partes if p is not None and not p.is_empty]
        return MultiLineString(partes) if partes else geom
    if geom.geom_type != 'LineString':
        return geom
    coords = list(geom.coords)
    # Se for linha fechada (ex: curva de nivel fechada), suaviza como anel continuo sem criar bico no ponto 0
    if len(coords) >= 4 and coords[0] == coords[-1]:
        try:
            anel = suavizar_anel_chaikin(LinearRing(coords), iteracoes=iteracoes)
            coords_limpas = limpar_espiculas_coords(list(anel.coords), eh_anel=True, min_dist=0.2, min_ang_graus=12.0)
            if len(coords_limpas) >= 4:
                l_fechada = LineString(coords_limpas)
                if l_fechada.is_simple and l_fechada.is_valid:
                    return l_fechada
        except Exception:
            pass
        return geom

    p_ini_fixo = coords[0]
    p_fim_fixo = coords[-1]
    for _ in range(iteracoes):
        if len(coords) < 3:
            break
        novas_coords = [coords[0]]
        for i in range(len(coords) - 1):
            p0, p1 = coords[i], coords[i + 1]
            q = (0.75 * p0[0] + 0.25 * p1[0], 0.75 * p0[1] + 0.25 * p1[1])
            r = (0.25 * p0[0] + 0.75 * p1[0], 0.25 * p0[1] + 0.75 * p1[1])
            novas_coords.extend([q, r])
        novas_coords.append(coords[-1])
        coords = novas_coords

    # Protege vizinhanca imediata dos nos de confluencia (evita micro-ganchos < 2.5m nas juncoes)
    if len(coords) > 3:
        filtradas = [p_ini_fixo]
        for c in coords[1:-1]:
            if math.hypot(c[0] - p_ini_fixo[0], c[1] - p_ini_fixo[1]) >= 2.5 and math.hypot(c[0] - p_fim_fixo[0], c[1] - p_fim_fixo[1]) >= 2.5:
                filtradas.append(c)
        filtradas.append(p_fim_fixo)
        coords = filtradas

    coords = limpar_espiculas_coords(coords, eh_anel=False, min_dist=0.25, min_ang_graus=12.0)
    if len(coords) >= 2:
        l_nova = LineString(coords)
        if l_nova.is_simple and l_nova.is_valid:
            return l_nova
    return geom

def suavizar_anel_chaikin(ring, iteracoes=1):
    coords = list(ring.coords)
    if len(coords) < 4:
        return ring
    if coords[0] != coords[-1]:
        coords.append(coords[0])
    pts = coords[:-1]
    n = len(pts)
    for _ in range(iteracoes):
        novos = []
        for i in range(n):
            p0 = pts[i]
            p1 = pts[(i + 1) % n]
            q = (0.75 * p0[0] + 0.25 * p1[0], 0.75 * p0[1] + 0.25 * p1[1])
            r = (0.25 * p0[0] + 0.75 * p1[0], 0.25 * p0[1] + 0.75 * p1[1])
            novos.extend([q, r])
        pts = novos
        n = len(pts)
    pts.append(pts[0])
    return LinearRing(pts)

def suavizar_poligono_chaikin(geom, iteracoes=1):
    """
    Suaviza contornos poligonais (exterior e buracos) mantendo curvatura organica e formato
    semelhante a feicao original, sem angulos pontiagudos de Douglas-Peucker.
    """
    if geom is None or geom.is_empty:
        return geom
    def _suavizar_poly(poly):
        try:
            ext_suave = suavizar_anel_chaikin(poly.exterior, iteracoes)
            holes_suaves = []
            for h in poly.interiors:
                if len(h.coords) >= 4:
                    holes_suaves.append(suavizar_anel_chaikin(h, iteracoes))
                else:
                    holes_suaves.append(h)
            p_novo = Polygon(ext_suave, holes_suaves)
            if not p_novo.is_valid:
                p_novo = make_valid(p_novo)
                if p_novo.geom_type in ['Polygon', 'MultiPolygon']:
                    p_novo = p_novo.buffer(0)
                else:
                    return poly
            return p_novo if not p_novo.is_empty else poly
        except Exception:
            return poly

    if geom.geom_type == 'Polygon':
        return _suavizar_poly(geom)
    elif geom.geom_type == 'MultiPolygon':
        res = [_suavizar_poly(p) for p in geom.geoms]
        polys = [p for p in res if p is not None and not p.is_empty and p.geom_type == 'Polygon']
        return MultiPolygon(polys) if polys else geom
    return geom

def preencher_buracos_pequenos(geom, area_minima):
    """
    Remove aneis internos (donut holes) de poligonos 
    se a area do vazio for inferior a tolerancia minima de escala.
    """
    if geom is None or geom.is_empty:
        return geom
        
    def _preencher_poligono(poly, area_min):
        exterior = poly.exterior
        interiors_mantidos = []
        for interior in poly.interiors:
            hole_poly = Polygon(interior)
            if hole_poly.area >= area_min:
                interiors_mantidos.append(interior)
        return Polygon(exterior, interiors_mantidos)

    if geom.geom_type == 'Polygon':
        return _preencher_poligono(geom, area_minima)
    elif geom.geom_type == 'MultiPolygon':
        polys = []
        for poly in geom.geoms:
            polys.append(_preencher_poligono(poly, area_minima))
        return MultiPolygon(polys)
        
    return geom

# =====================================================================
# NUCLEO TOPOLOGICO DE GENERALIZACAO
# =====================================================================

def costurar_topologia_inter_camadas(gdf_massa, gdf_drenagem, gdf_veg, gdf_edif, p):
    """
    Resolve vazios de mapeamento doando poligonos de massas d'agua suprimidas 
    para a vegetacao ou area edificada adjacente e costurando drenagens orfas
    apenas para os lagos extintos. 
    Aplica imunidade absoluta contra supressao para corpos d'agua nomeados,
    conectados a rede hidrografica ou que interceptam a moldura da carta (15m).
    """
    print("\n    --> [Sincronizacao Topologica] Sincronizando Massa d'Agua, Drenagem, Vegetacao e Area Edificada...")
    
    if gdf_massa is None or gdf_massa.empty:
        return gdf_massa, gdf_drenagem, gdf_veg, gdf_edif

    gdf_massa['area_calc'] = gdf_massa['geom'].area
    
    # Identificacao de toponimia (ET-ADGV 3.0)
    col_nome_massa = achar_coluna(gdf_massa, ['nome', 'nm_corpo', 'denominacao', 'toponimo', 'nome_abrev', 'identificador'])
    
    def verifica_protecao(row):
        geom = row['geom']
        if geom is None or geom.is_empty: return False
        
        # Imunidade por Toponimia Oficial (exceto micro-fragmentos de rio < 500 m2)
        if col_nome_massa and geom.area >= 500.0:
            nome = row.get(col_nome_massa, None)
            if pd.notna(nome) and str(nome).strip().upper() not in ["", "NULL", "NONE", "NAN", "DESCONHECIDO"]:
                return True
                
        return False

    gdf_massa['protegido'] = gdf_massa.apply(verifica_protecao, axis=1)
    
    # Limiar especifico para Corpos d'Agua (ET-ADGV 3.0: 4 mm2 na carta)
    limiar_massa = p.get("massa_min", 40000.0)
    
    massas_removidas = gdf_massa[(gdf_massa['area_calc'] < limiar_massa) & (~gdf_massa['protegido'])].copy()
    gdf_massa_mantida = gdf_massa[(gdf_massa['area_calc'] >= limiar_massa) | (gdf_massa['protegido'])].copy()
    
    gdf_massa_mantida.drop(columns=['area_calc', 'protegido'], inplace=True, errors='ignore')
    massas_removidas.drop(columns=['protegido'], inplace=True, errors='ignore')
    
    if massas_removidas.empty:
        return gdf_massa_mantida, gdf_drenagem, gdf_veg, gdf_edif

    print(f"    --> {len(massas_removidas)} massas d'agua menores que a norma doadas para camadas adjacentes.")
    
    novas_drenagens = []
    sindex_dren = gdf_drenagem.sindex if gdf_drenagem is not None and not gdf_drenagem.empty else None
    sindex_veg = gdf_veg.sindex if gdf_veg is not None and not gdf_veg.empty else None
    sindex_edif = gdf_edif.sindex if gdf_edif is not None and not gdf_edif.empty else None
    
    colunas_drenagem = gdf_drenagem.columns if gdf_drenagem is not None else []
    col_nome = achar_coluna(gdf_drenagem, ['nome', 'nm_trecho', 'denominacao']) if gdf_drenagem is not None else None
    col_regime = achar_coluna(gdf_drenagem, ['regime', 'regime_hidrico']) if gdf_drenagem is not None else None

    for idx, row in massas_removidas.iterrows():
        geom_massa = row['geom']
        absorvido = False
        
        # 1. Doacao Hibrida de Poligonos Extintos
        def tentar_doar_poligono(gdf_alvo, sindex_alvo):
            possiveis = list(sindex_alvo.intersection(geom_massa.bounds))
            alvo_vizinho = gdf_alvo.iloc[possiveis]
            alvo_vizinho = alvo_vizinho[alvo_vizinho.intersects(geom_massa) | alvo_vizinho.touches(geom_massa)]
            
            if not alvo_vizinho.empty:
                maior_fronteira = -1
                melhor_vizinho = alvo_vizinho.index[0]
                
                for v_idx, v_row in alvo_vizinho.iterrows():
                    inter_borda = geom_massa.intersection(v_row['geom'])
                    if inter_borda.length > maior_fronteira:
                        maior_fronteira = inter_borda.length
                        melhor_vizinho = v_idx
                        
                gdf_alvo.at[melhor_vizinho, 'geom'] = unary_union([gdf_alvo.at[melhor_vizinho, 'geom'], geom_massa])
                return True
                
            geom_massa_buf = geom_massa.buffer(10.0)
            possiveis_buf = list(sindex_alvo.intersection(geom_massa_buf.bounds))
            alvo_vizinho_buf = gdf_alvo.iloc[possiveis_buf]
            alvo_vizinho_buf = alvo_vizinho_buf[alvo_vizinho_buf.intersects(geom_massa_buf)]
            
            if not alvo_vizinho_buf.empty:
                distancias = alvo_vizinho_buf['geom'].distance(geom_massa)
                melhor_vizinho = distancias.idxmin()
                
                gdf_alvo.at[melhor_vizinho, 'geom'] = unary_union([gdf_alvo.at[melhor_vizinho, 'geom'], geom_massa])
                return True
                
            return False

        if sindex_veg is not None:
            absorvido = tentar_doar_poligono(gdf_veg, sindex_veg)
            
        if not absorvido and sindex_edif is not None:
            absorvido = tentar_doar_poligono(gdf_edif, sindex_edif)

    return gdf_massa_mantida, gdf_drenagem, gdf_veg, gdf_edif

def podar_dangles_com_grafos(gdf, p, tipo_camada, escala_alvo, gdf_massa_mantida=None, gdf_edif_ref=None, moldura_folha=None, gdf_sumidouro=None):
    """
    Poda topologica normativa (ET-ADGV 3.0 / DSG / Regras EDGV 3.0 P110, P113, P114).
    - Para vias (infra_via_deslocamento_l):
      * Preserva integralmente rodovias oficiais (BR/Estaduais/Auto-estradas), garantindo a continuidade
        dos eixos rodoviarios (ex: pontes/viadutos onde a sigla nao foi preenchida).
      * Identifica arruamentos urbanos pela sobreposicao com cobter_area_edificada_a (Regra P110) e
        por quarteiroes fechados (< 1.000m de perimetro).
      * Nas escalas 1:100.000 e 1:250.000 (Regras P113/P114), suprime a malha de arruamentos locais,
        mantendo todos os caminhos arteriais minimos que conectam estradas rurais entre si e as rodovias.
      * Poda ramos mortos < rede_min (Shortest-Leaf-First) e preserva 100% das vias que tocam a moldura.
    - Para drenagem (elemnat_trecho_drenagem_l):
      * Poda iterativa Shortest-Leaf-First (Horton-Strahler) evitando desfiamento de bifurcacoes em Y;
      * Protege estritamente nos que tocam a moldura oficial (aux_moldura_a), sumidouros/vertedouros
        (elemnat_sumidouro_vertedouro_p), foz em massas d'agua mantidas na escala e rios nomeados.
    """
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    
    col_juris = achar_coluna(gdf, ['jurisdicao', 'jur', 'jurisd'])
    col_sigla = achar_coluna(gdf, ['sigla', 'codigo', 'cod'])
    col_tipo = achar_coluna(gdf, ['tipo', 'tipovia', 'tipo_via', 'cod_tipo'])
    col_nome = achar_coluna(gdf, ['nome', 'nm_trecho', 'denominacao', 'toponimo'])
    
    minx, miny, maxx, maxy = gdf.total_bounds
    
    def toca_borda(pt):
        if moldura_folha is not None and not moldura_folha.is_empty:
            return Point(pt).distance(moldura_folha) <= 5.0
        x, y = pt
        return (abs(x - minx) <= 15.0 or abs(x - maxx) <= 15.0 or
                abs(y - miny) <= 15.0 or abs(y - maxy) <= 15.0)

    # =========================================================================
    # RAMO 1: GENERALIZACAO TOPOLOGICA DE VIAS DE DESLOCAMENTO (ET-ADGV 3.0)
    # =========================================================================
    if tipo_camada == "infra_via_deslocamento_l":
        G = nx.MultiGraph()
        rede_min = p['rede_min']
        u_edif_buffer = None
        if gdf_edif_ref is not None and not gdf_edif_ref.empty:
            try:
                u_edif_buffer = unary_union(gdf_edif_ref['geom'].tolist()).buffer(50.0)
            except Exception:
                u_edif_buffer = None

        u_rodovias_noded = None
        if 'eh_rodovia_temp' in gdf.columns:
            u_rodovias_noded = unary_union(gdf[gdf['eh_rodovia_temp'] == True]['geom'].tolist()) if any(gdf['eh_rodovia_temp'] == True) else None
        buf_rodovia = u_rodovias_noded.buffer(50.0) if u_rodovias_noded is not None and not u_rodovias_noded.is_empty else None

        for idx, row in gdf.iterrows():
            geom = row['geom']
            if geom is None or geom.geom_type != 'LineString':
                continue
            coords = list(geom.coords)
            p1 = (round(coords[0][0], 1), round(coords[0][1], 1))
            p2 = (round(coords[-1][0], 1), round(coords[-1][1], 1))
            if p1 == p2:
                continue

            eh_rodovia = bool(row.get('eh_rodovia_temp', False))
            eh_conector = bool(row.get('eh_conector_temp', False))
            sigla_norm = None
            if col_sigla:
                v_sigla = row.get(col_sigla, None)
                if pd.notna(v_sigla) and str(v_sigla).strip().upper() not in ["", "NULL", "NONE", "NAN"]:
                    eh_rodovia = True
                    sigla_norm = re.sub(r'[^A-Z0-9]', '', str(v_sigla).strip().upper())
            if col_nome:
                v_nome = row.get(col_nome, None)
                if pd.notna(v_nome) and str(v_nome).strip().upper() not in ["", "NULL", "NONE", "NAN", "DESCONHECIDO"]:
                    eh_rodovia = True
                    if not sigla_norm:
                        sigla_norm = re.sub(r'[^A-Z0-9]', '', str(v_nome).strip().upper())
            if col_juris:
                v_juris = str(row.get(col_juris, '')).strip().lower()
                if v_juris in ['1', '2', 'federal', 'estadual']:
                    eh_rodovia = True
            v_tipo = str(row.get(col_tipo, '')).strip().lower() if col_tipo else ''
            if v_tipo in ['2', 'auto-estrada', 'autoestrada', 'rodovia']:
                eh_rodovia = True

            toca_borda_flag = toca_borda(p1) or toca_borda(p2)

            eh_urbana = False
            if not eh_rodovia and not eh_conector:
                if v_tipo in ['1', 'arruamento', 'beco', 'logradouro']:
                    eh_urbana = True
                elif u_edif_buffer is not None and not u_edif_buffer.is_empty:
                    len_in = geom.intersection(u_edif_buffer).length
                    if geom.length > 0 and (len_in / geom.length) >= 0.4:
                        eh_urbana = True
                # Vias marginais paralelas a rodovia dentro de 50m
                if not eh_urbana and buf_rodovia is not None and not buf_rodovia.is_empty:
                    len_par = geom.intersection(buf_rodovia).length
                    if geom.length > 0 and (len_par / geom.length) >= 0.7:
                        eh_urbana = True

            G.add_edge(p1, p2, key=idx, idx=idx, length=geom.length, geom=geom,
                       eh_rodovia=eh_rodovia, eh_conector=eh_conector, sigla_norm=sigla_norm,
                       eh_urbana=eh_urbana, toca_borda=toca_borda_flag, conector_urbano=False)

        # Grafo simples auxiliar para deteccao de quarteiroes e caminhos minimos
        G_simple = nx.Graph()
        for u, v, k, d in G.edges(keys=True, data=True):
            if not G_simple.has_edge(u, v) or d['length'] < G_simple[u][v]['length']:
                G_simple.add_edge(u, v, key=k, **d)

        # Detectar quarteiroes/loteamentos fechados (< 1000m de perimetro)
        for ciclo in nx.cycle_basis(G_simple):
            perim = sum(G_simple[ciclo[i]][ciclo[(i+1)%len(ciclo)]]['length'] for i in range(len(ciclo)))
            if perim < 1000.0:
                for i in range(len(ciclo)):
                    u_c, v_c = ciclo[i], ciclo[(i+1)%len(ciclo)]
                    for k in G[u_c][v_c]:
                        if not G[u_c][v_c][k]['eh_rodovia'] and not G[u_c][v_c][k]['eh_conector']:
                            G[u_c][v_c][k]['eh_urbana'] = True
                    if not G_simple[u_c][v_c]['eh_rodovia'] and not G_simple[u_c][v_c]['eh_conector']:
                        G_simple[u_c][v_c]['eh_urbana'] = True

        # Pesos para roteamento: rodovias e conectores diretos custam quase zero, rurais 0.2*len, urbanas 1.0*len
        for u, v, d in G_simple.edges(data=True):
            d['weight'] = d['length'] * (0.001 if (d['eh_rodovia'] or d['eh_conector']) else (0.2 if not d['eh_urbana'] else 1.0))

        # 1a. Garantir continuidade interna de cada rodovia oficial (ex: ponte da BR-116 sem atributo sigla)
        siglas_unicas = {d['sigla_norm'] for _, _, d in G_simple.edges(data=True) if d.get('sigla_norm')}
        for s_norm in siglas_unicas:
            G_sig = nx.Graph()
            for u, v, d in G_simple.edges(data=True):
                if d.get('sigla_norm') == s_norm:
                    G_sig.add_edge(u, v)
            comps_sig = list(nx.connected_components(G_sig))
            if len(comps_sig) > 1:
                comp_s_princ = max(comps_sig, key=len)
                G_path_s = G_simple.copy()
                SUPER_S = ("SUPER_SIGLA", s_norm)
                for n in comp_s_princ:
                    G_path_s.add_edge(SUPER_S, n, weight=0.0)
                for c_s in comps_sig:
                    if c_s == comp_s_princ:
                        continue
                    melhor_cam = None
                    melhor_dist = float('inf')
                    for n_cand in c_s:
                        if nx.has_path(G_path_s, n_cand, SUPER_S):
                            dist = nx.shortest_path_length(G_path_s, n_cand, SUPER_S, weight='length')
                            if dist < melhor_dist:
                                melhor_dist = dist
                                melhor_cam = nx.shortest_path(G_path_s, n_cand, SUPER_S, weight='length')
                    if melhor_cam:
                        for i in range(len(melhor_cam) - 2):
                            u_c, v_c = melhor_cam[i], melhor_cam[i+1]
                            if G.has_edge(u_c, v_c):
                                for k in G[u_c][v_c]:
                                    G[u_c][v_c][k]['eh_rodovia'] = True
                                    G[u_c][v_c][k]['eh_urbana'] = False
                            if G_simple.has_edge(u_c, v_c):
                                G_simple[u_c][v_c]['eh_rodovia'] = True
                                G_simple[u_c][v_c]['eh_urbana'] = False
                                G_simple[u_c][v_c]['weight'] = G_simple[u_c][v_c]['length'] * 0.001
                            G_path_s.add_edge(SUPER_S, u_c, weight=0.0)
                            G_path_s.add_edge(SUPER_S, v_c, weight=0.0)

        # 1b. Garantir continuidade global entre diferentes rodovias oficiais (ex: RJ-161 ate BR-116)
        G_rod = nx.Graph()
        for u, v, d in G_simple.edges(data=True):
            if d['eh_rodovia']:
                G_rod.add_edge(u, v)
        comps_rod = list(nx.connected_components(G_rod))
        if len(comps_rod) > 1:
            comp_rod_princ = max(comps_rod, key=len)
            G_path_rod = G_simple.copy()
            SUPER_ROD = ("SUPER_ROD_MAIN", 0)
            for n in comp_rod_princ:
                G_path_rod.add_edge(SUPER_ROD, n, weight=0.0)
            for c_rod in comps_rod:
                if c_rod == comp_rod_princ:
                    continue
                melhor_cam = None
                melhor_custo = float('inf')
                for n_cand in c_rod:
                    if nx.has_path(G_path_rod, n_cand, SUPER_ROD):
                        custo = nx.shortest_path_length(G_path_rod, n_cand, SUPER_ROD, weight='weight')
                        if custo < melhor_custo:
                            melhor_custo = custo
                            melhor_cam = nx.shortest_path(G_path_rod, n_cand, SUPER_ROD, weight='weight')
                if melhor_cam:
                    for i in range(len(melhor_cam) - 2):
                        u_c, v_c = melhor_cam[i], melhor_cam[i+1]
                        if G.has_edge(u_c, v_c):
                            for k in G[u_c][v_c]:
                                G[u_c][v_c][k]['eh_rodovia'] = True
                                G[u_c][v_c][k]['eh_urbana'] = False
                        if G_simple.has_edge(u_c, v_c):
                            G_simple[u_c][v_c]['eh_rodovia'] = True
                            G_simple[u_c][v_c]['eh_urbana'] = False
                            G_simple[u_c][v_c]['weight'] = G_simple[u_c][v_c]['length'] * 0.001
                        G_path_rod.add_edge(SUPER_ROD, u_c, weight=0.0)
                        G_path_rod.add_edge(SUPER_ROD, v_c, weight=0.0)

        # 2. Nas escalas 100k e 250k, omitir arruamentos locais preservando TODOS os conectores arteriais (P113/P114)
        if escala_alvo in ["100", "250"]:
            nos_rodovia = {n for u, v, k, d in G.edges(keys=True, data=True) if d['eh_rodovia'] for n in (u, v)}
            nos_urbanos = {n for u, v, k, d in G.edges(keys=True, data=True) if d['eh_urbana'] for n in (u, v)}

            G_rural = nx.Graph()
            for u, v, k, d in G.edges(keys=True, data=True):
                if not d['eh_urbana'] or d['eh_rodovia'] or d['eh_conector']:
                    G_rural.add_edge(u, v, length=d['length'], eh_rodovia=d['eh_rodovia'], eh_conector=d['eh_conector'], toca_borda=d['toca_borda'])

            # Poda Shortest-Leaf-First de pontas rurais genuinas (protegendo nos de transicao urbana, rodovia e moldura)
            while True:
                cands_r = []
                for ponta in [n for n, deg in dict(G_rural.degree()).items() if deg == 1]:
                    if ponta in nos_urbanos or toca_borda(ponta) or ponta in nos_rodovia:
                        continue
                    curr = ponta
                    b_len = 0.0
                    b_edges = []
                    prot = False
                    visited = set()
                    while True:
                        if curr != ponta and G_rural.degree(curr) != 2:
                            break
                        ed = [e for e in G_rural.edges(curr, data=True) if (min(e[0], e[1]), max(e[0], e[1])) not in visited]
                        if not ed:
                            break
                        u, v, d = ed[0]
                        visited.add((min(u, v), max(u, v)))
                        b_edges.append((u, v))
                        b_len += d['length']
                        if d['eh_rodovia'] or d['toca_borda']:
                            prot = True
                        curr = v if u == curr else u
                    if G_rural.degree(curr) == 1 and (toca_borda(curr) or curr in nos_rodovia):
                        prot = True
                    if not prot and b_len < rede_min:
                        cands_r.append((b_len, b_edges))
                if not cands_r:
                    break
                cands_r.sort(key=lambda x: x[0])
                for u, v in cands_r[0][1]:
                    if G_rural.has_edge(u, v):
                        G_rural.remove_edge(u, v)
                for n in [n for n in list(G_rural.nodes()) if G_rural.degree(n) == 0]:
                    G_rural.remove_node(n)

            # Identificar portais de transicao (onde componentes rurais tocam a malha urbana)
            nos_transicao = set()
            for comp in nx.connected_components(G_rural):
                sub_r = G_rural.subgraph(comp)
                tot_r = sum(d['length'] for u, v, d in sub_r.edges(data=True))
                tem_rod = any(d['eh_rodovia'] for u, v, d in sub_r.edges(data=True))
                tem_borda = any(toca_borda(n) for n in comp)
                tocam = [n for n in comp if n in nos_urbanos]
                if tocam and (tot_r >= rede_min * 0.3 or tem_rod or tem_borda or len(tocam) >= 2):
                    nos_transicao.update(tocam)

            # 2a. Conectar portais de transicao que convergem para um mesmo cluster urbano local (ex: entroncamentos em triangulo)
            G_urb_only = nx.Graph()
            for u, v, d in G_simple.edges(data=True):
                if d['eh_urbana'] or d['eh_conector'] or d['eh_rodovia']:
                    G_urb_only.add_edge(u, v, weight=d['weight'], length=d['length'])

            for u_comp in nx.connected_components(G_urb_only):
                portais_cluster = [n for n in u_comp if n in nos_transicao]
                if len(portais_cluster) >= 2:
                    sub_u = G_urb_only.subgraph(u_comp).copy()
                    ancora = portais_cluster[0]
                    SUPER_U = ("SUPER_CLUSTER_U", ancora)
                    sub_u.add_edge(SUPER_U, ancora, weight=0.0)
                    for p_alvo in portais_cluster[1:]:
                        if nx.has_path(sub_u, p_alvo, SUPER_U):
                            cam = nx.shortest_path(sub_u, p_alvo, SUPER_U, weight='weight')
                            for i in range(len(cam) - 2):
                                u_c, v_c = cam[i], cam[i+1]
                                if G.has_edge(u_c, v_c):
                                    for k in G[u_c][v_c]:
                                        G[u_c][v_c][k]['conector_urbano'] = True
                                if G_simple.has_edge(u_c, v_c):
                                    G_simple[u_c][v_c]['weight'] = 0.0
                                sub_u.add_edge(SUPER_U, u_c, weight=0.0)
                                sub_u.add_edge(SUPER_U, v_c, weight=0.0)

            # 2b. Conectar TODOS os portais de transicao ate a malha de rodovias principais (SUPER_RODOVIA)
            if nos_rodovia and nos_transicao:
                G_path = G_simple.copy()
                SUPER = ("SUPER_RODOVIA", 0)
                for nr in nos_rodovia:
                    if nr in G_path:
                        G_path.add_edge(SUPER, nr, weight=0.0)
                for nt in sorted(nos_transicao):
                    if nt in G_path and nx.has_path(G_path, nt, SUPER):
                        caminho = nx.shortest_path(G_path, nt, SUPER, weight='weight')
                        for i in range(len(caminho) - 2):
                            u_c, v_c = caminho[i], caminho[i+1]
                            if G.has_edge(u_c, v_c):
                                for k in G[u_c][v_c]:
                                    G[u_c][v_c][k]['conector_urbano'] = True
                            if G_path.has_edge(u_c, v_c):
                                G_path[u_c][v_c]['weight'] = 0.0

            # Remover arruamentos locais nao conectores
            for u, v, k, d in list(G.edges(keys=True, data=True)):
                if d['eh_urbana'] and not d['eh_rodovia'] and not d['conector_urbano']:
                    G.remove_edge(u, v, key=k)
            for n in [n for n in list(G.nodes()) if G.degree(n) == 0]:
                G.remove_node(n)

            # Quebrar arestas paralelas duplicadas (dupla digitalizacao / micro-retornos < 100m)
            for u, v in list(G.edges()):
                if G.number_of_edges(u, v) > 1:
                    chaves = list(G[u][v].keys())
                    edges_uv = sorted([(k, G[u][v][k]) for k in chaves], key=lambda x: (x[1]['eh_rodovia'], x[1]['length']), reverse=True)
                    for k_rem, d_rem in edges_uv[1:]:
                        if not d_rem['eh_rodovia'] and d_rem['length'] < 100.0:
                            G.remove_edge(u, v, key=k_rem)
            # Quebrar apenas micro-loops/rotatorias/quarteiroes minusculos (< 400m)
            # Circuitos e aneis viarios rurais >= 400m sao preservados para manter a conectividade regional!
            lim_micro_loop = 300.0 if escala_alvo == "50" else 400.0
            G_simp = nx.Graph()
            for u, v, k, d in G.edges(keys=True, data=True):
                G_simp.add_edge(u, v, key=k, **d)
            for ciclo in nx.cycle_basis(G_simp):
                arestas_c = []
                perim = 0.0
                for i in range(len(ciclo)):
                    u_c, v_c = ciclo[i], ciclo[(i+1)%len(ciclo)]
                    if G_simp.has_edge(u_c, v_c):
                        d_c = G_simp[u_c][v_c]
                        perim += d_c['length']
                        arestas_c.append((u_c, v_c, d_c['key'], d_c))
                if perim < lim_micro_loop:
                    cands = [a for a in arestas_c if not a[3]['eh_rodovia'] and not a[3]['toca_borda']]
                    if cands:
                        cands.sort(key=lambda a: a[3]['length'], reverse=True)
                        u_r, v_r, k_r, _ = cands[0]
                        if G.has_edge(u_r, v_r, key=k_r):
                            G.remove_edge(u_r, v_r, key=k_r)

        # 3. Poda de ramos mortos (dangles) Shortest-Leaf-First < rede_min (em 50k, preserva quarteiroes fechados e poda becos < 300m)
        limiar_dangle = 300.0 if escala_alvo == "50" else rede_min
        while True:
            pontas = [n for n, deg in dict(G.degree()).items() if deg == 1]
            cands_poda = []
            for ponta in pontas:
                if toca_borda(ponta):
                    continue
                curr = ponta
                branch_len = 0.0
                branch_edges = []
                ramo_protegido = False
                visited_keys = set()
                while True:
                    if curr != ponta and G.degree(curr) != 2:
                        break
                    edges = [e for e in G.edges(curr, keys=True, data=True) if e[2] not in visited_keys]
                    if not edges:
                        break
                    u, v, k, d = edges[0]
                    visited_keys.add(k)
                    branch_edges.append((u, v, k, d['eh_urbana']))
                    branch_len += d['length']
                    if d['eh_rodovia'] or d['toca_borda']:
                        ramo_protegido = True
                    curr = v if u == curr else u
                if G.degree(curr) == 1 and toca_borda(curr):
                    ramo_protegido = True
                lim_ramo = limiar_dangle if any(e[3] for e in branch_edges) else rede_min
                if (branch_len < 15.0 and not toca_borda(ponta)) or (not ramo_protegido and branch_len < lim_ramo):
                    cands_poda.append((branch_len, branch_edges))
            if not cands_poda:
                break
            cands_poda.sort(key=lambda x: x[0])
            for u, v, k, _ in cands_poda[0][1]:
                if G.has_edge(u, v, key=k):
                    G.remove_edge(u, v, key=k)
            for n in [n for n in list(G.nodes()) if G.degree(n) == 0]:
                G.remove_node(n)

        # 4. Eliminacao de componentes flutuantes/desconectados preservando 100% dos que tocam a moldura ou tem rodovia (ET-CQDG)
        comps = list(nx.connected_components(G))
        if comps:
            comp_principal = max(comps, key=lambda c: sum(d['length'] for u, v, k, d in G.subgraph(c).edges(keys=True, data=True)))
            for c in comps:
                if c == comp_principal:
                    continue
                sub = G.subgraph(c)
                tot_comp_len = sum(d['length'] for u, v, k, d in sub.edges(keys=True, data=True))
                tem_rodovia = any(d['eh_rodovia'] for u, v, k, d in sub.edges(keys=True, data=True))
                toca_borda_c = any(toca_borda(n) for n in c)
                if not tem_rodovia and not toca_borda_c and tot_comp_len < rede_min:
                    for n in list(c):
                        G.remove_node(n)

        indices_mantidos = [d['idx'] for u, v, k, d in G.edges(keys=True, data=True)]
        return gdf.loc[indices_mantidos].copy().reset_index(drop=True)

    # =========================================================================
    # RAMO 2: GENERALIZACAO TOPOLOGICA DE DRENAGEM (HORTON-STRAHLER / ET-ADGV 3.0)
    # =========================================================================
    G = nx.MultiGraph()
    u_massa_mantida = unary_union(gdf_massa_mantida['geom'].tolist()) if (gdf_massa_mantida is not None and not gdf_massa_mantida.empty) else None
    u_sumidouro = unary_union(gdf_sumidouro['geom'].tolist()) if (gdf_sumidouro is not None and not gdf_sumidouro.empty) else None

    def foz_na_represa(pt):
        if u_massa_mantida is None or u_massa_mantida.is_empty:
            return False
        return Point(pt).distance(u_massa_mantida) <= 5.0

    def toca_sumidouro(pt):
        if u_sumidouro is None or u_sumidouro.is_empty:
            return False
        return Point(pt).distance(u_sumidouro) <= 15.0

    for idx, row in gdf.iterrows():
        geom = row['geom']
        if geom is None or geom.geom_type != 'LineString':
            continue

        coords = list(geom.coords)
        p1 = (round(coords[0][0], 2), round(coords[0][1], 2))
        p2 = (round(coords[-1][0], 2), round(coords[-1][1], 2))
        if p1 == p2:
            continue

        tem_nome_flag = False
        if col_nome:
            nome = row.get(col_nome, None)
            if pd.notna(nome) and str(nome).strip().upper() not in ["", "NULL", "NONE", "NAN", "DESCONHECIDO", "CONEXAO_TOPOLOGICA"]:
                tem_nome_flag = True

        G.add_edge(p1, p2, key=idx, idx=idx, length=geom.length, tem_nome=tem_nome_flag)

    no_borda = {n: toca_borda(n) for n in G.nodes()}
    no_sumid = {n: toca_sumidouro(n) for n in G.nodes()}
    no_represa = {n: foz_na_represa(n) for n in G.nodes()}

    indices_remover = set()

    # Poda iterativa Shortest-Leaf-First (remove apenas 1 folha mais curta por iteracao, impedindo desfiamento em Y)
    while True:
        pontas = [node for node, degree in dict(G.degree()).items() if degree == 1]
        candidatos_poda = []

        for ponta in pontas:
            # Protege a ponta (grau 1) se ela propria tocar a moldura, um sumidouro/vertedouro ou foz em massa d'agua mantida
            if no_borda.get(ponta, False) or no_sumid.get(ponta, False) or no_represa.get(ponta, False):
                continue

            curr = ponta
            branch_length = 0.0
            ramo_tem_nome = False
            branch_edges = []
            visited_keys = set()

            while True:
                if curr != ponta and G.degree(curr) != 2:
                    break
                edges = [e for e in G.edges(curr, keys=True, data=True) if e[2] not in visited_keys]
                if not edges:
                    break
                u, v, k, d = edges[0]
                next_node = v if u == curr else u
                visited_keys.add(k)
                branch_edges.append((u, v, k, d['idx']))
                branch_length += d['length']
                if d['tem_nome']:
                    ramo_tem_nome = True
                curr = next_node

            # Se a outra extremidade de um trecho isolado (grau 1) tocar a moldura ou sumidouro, preserva!
            if G.degree(curr) == 1 and (no_borda.get(curr, False) or no_sumid.get(curr, False)):
                continue

            if not ramo_tem_nome and branch_length < p['rede_min']:
                candidatos_poda.append((branch_length, ponta, branch_edges))

        if not candidatos_poda:
            break

        candidatos_poda.sort(key=lambda x: x[0])
        _, _, edges_to_rem = candidatos_poda[0]
        for u, v, k, idx_edge in edges_to_rem:
            if G.has_edge(u, v, key=k):
                indices_remover.add(idx_edge)
                G.remove_edge(u, v, key=k)

        for n in [n for n in list(G.nodes()) if G.degree(n) == 0]:
            G.remove_node(n)

    # Expurgar sub-redes orfas isoladas < rede_min (preservando as que tocam moldura, sumidouro ou possuem nome)
    for componente in list(nx.connected_components(G)):
        subgrafo = G.subgraph(componente)
        comprimento_total = sum(d['length'] for _, _, d in subgrafo.edges(data=True))
        comp_tem_nome = any(d['tem_nome'] for _, _, d in subgrafo.edges(data=True))
        comp_toca_borda = any(no_borda.get(n, False) for n in componente)
        comp_toca_sumid = any(no_sumid.get(n, False) for n in componente)
        if not (comp_tem_nome or comp_toca_borda or comp_toca_sumid) and comprimento_total < p['rede_min']:
            for _, _, d in subgrafo.edges(data=True):
                indices_remover.add(d['idx'])

    if indices_remover:
        gdf = gdf.drop(list(indices_remover))

    return gdf.copy()

def generalizar_linhas_com_topologia(gdf, escala_alvo, tipo_camada, gdf_massa_mantida=None, gdf_edif_ref=None, moldura_folha=None, gdf_sumidouro=None):
    """
    Executa a generalizacao de redes assegurando a integridade topologica.
    Mantem a conectividade da malha viaria urbana e rodoviaria sem colapso destrutivo
    e sem deslocar os eixos originais das vias sobre rios/pontes.
    """
    p = obter_parametros(escala_alvo, tipo_camada)
    geom_col = gdf.geometry.name
    
    if tipo_camada == "infra_via_deslocamento_l":
        cols_chave = ['tipo', 'revestimento', 'jurisdicao', 'administracao', 'sigla', 'nome']
        snap_tol = 0.5

        # Gerar conexoes perpendiculares diretas para rodovias principais (100k e 250k)
        # para que vias secundarias conectem diretamente ao eixo principal sem detours pelas marginais
        if escala_alvo in ["100", "250"]:
            col_sigla = achar_coluna(gdf, ['sigla'])
            col_nome = achar_coluna(gdf, ['nome'])
            col_juris = achar_coluna(gdf, ['jurisdicao'])
            col_tipo = achar_coluna(gdf, ['tipo'])
            
            eh_rod_flags = []
            for idx, row in gdf.iterrows():
                eh_rod = False
                if col_sigla:
                    v_s = row.get(col_sigla, None)
                    if pd.notna(v_s) and str(v_s).strip().upper() not in ["", "NULL", "NONE", "NAN"]:
                        eh_rod = True
                if col_nome:
                    v_n = row.get(col_nome, None)
                    if pd.notna(v_n) and str(v_n).strip().upper() not in ["", "NULL", "NONE", "NAN", "DESCONHECIDO"]:
                        eh_rod = True
                if col_juris:
                    v_j = str(row.get(col_juris, '')).strip().lower()
                    if v_j in ['1', '2', 'federal', 'estadual']:
                        eh_rod = True
                if col_tipo:
                    v_t = str(row.get(col_tipo, '')).strip().lower()
                    if v_t in ['2', 'auto-estrada', 'autoestrada', 'rodovia']:
                        eh_rod = True
                eh_rod_flags.append(eh_rod)
                
            gdf['eh_rodovia_temp'] = eh_rod_flags
            gdf['eh_conector_temp'] = False
            u_rodovias = unary_union(gdf[gdf['eh_rodovia_temp']][geom_col].tolist()) if any(eh_rod_flags) else None
            
            if u_rodovias is not None and not u_rodovias.is_empty:
                links_diretos = []
                seen_pts = set()
                for idx, row in gdf.iterrows():
                    if row['eh_rodovia_temp']:
                        continue
                    geom = row[geom_col]
                    lines = list(geom.geoms) if hasattr(geom, 'geoms') else [geom]
                    for l in lines:
                        if len(l.coords) >= 2:
                            for pt_c in [l.coords[0], l.coords[-1]]:
                                pt_round = (round(pt_c[0], 1), round(pt_c[1], 1))
                                if pt_round in seen_pts:
                                    continue
                                seen_pts.add(pt_round)
                                pt = Point(pt_c)
                                d = u_rodovias.distance(pt)
                                if 1.0 < d <= 50.0:
                                    p_proj = nearest_points(u_rodovias, pt)[0]
                                    link = LineString([pt, p_proj])
                                    if link.length > 0.5:
                                        links_diretos.append((row, link))
                if links_diretos:
                    links_rows = []
                    for orig_row, link_geom in links_diretos:
                        r_dict = orig_row.to_dict()
                        r_dict[geom_col] = link_geom
                        r_dict['eh_rodovia_temp'] = False
                        r_dict['eh_conector_temp'] = True
                        links_rows.append(r_dict)
                    gdf_links = gpd.GeoDataFrame(links_rows, geometry=geom_col, crs=gdf.crs)
                    gdf = gpd.GeoDataFrame(pd.concat([gdf, gdf_links], ignore_index=True), geometry=geom_col, crs=gdf.crs)
    else: 
        cols_chave = ['nome', 'tipo', 'regime', 'navegabilidade']
        snap_tol = 0.0
    
    cols_chave_dinamicas = [c for c in cols_chave if achar_coluna(gdf, [c]) is not None]
    
    print(f"    --> Executando Nodificacao Planar Real ({tipo_camada})...")
    gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=snap_tol)

    print(f"    --> Poda via Teoria de Grafos ({tipo_camada})...")
    gdf = podar_dangles_com_grafos(
        gdf, p, tipo_camada, escala_alvo,
        gdf_massa_mantida=gdf_massa_mantida,
        gdf_edif_ref=gdf_edif_ref,
        moldura_folha=moldura_folha,
        gdf_sumidouro=gdf_sumidouro
    )
    
    for c_temp in ['eh_rodovia_temp', 'eh_conector_temp']:
        if c_temp in gdf.columns:
            gdf = gdf.drop(columns=[c_temp])

    print(f"    --> Fundindo apenas pseudonos (grau 2) e preservando todas as confluencias/entroncamentos (grau >= 3)...")
    gdf = fundir_apenas_pseudonos(gdf, cols_chave_dinamicas)

    if tipo_camada == "elemnat_trecho_drenagem_l":
        print(f"    --> Simplificando geometria e suavizando tracos lineares ({tipo_camada})...")
        gdf['geom'] = gdf['geom'].simplify(tolerance=p["tol"], preserve_topology=True)
        gdf['geom'] = gdf['geom'].apply(lambda x: suavizar_linha_chaikin(x, iteracoes=1))
    elif tipo_camada == "infra_via_deslocamento_l":
        print(f"    --> Suavizando tracado dos eixos viarios ({tipo_camada})...")
        tol_via = max(1.0, p["tol"] * 0.4)
        gdf['geom'] = gdf['geom'].simplify(tolerance=tol_via, preserve_topology=True)
        gdf['geom'] = gdf['geom'].apply(lambda x: suavizar_linha_chaikin(x, iteracoes=1))
    else:
        print(f"    --> Preservando geometria exata ({tipo_camada})...")

    # =========================================================================
    # TRAVAMENTO TOPOLOGICO POS-SUAVIZACAO (ZERO DANGLES E ZERO VERTICES NAO COMPARTILHADOS)
    # =========================================================================
    if tipo_camada == "elemnat_trecho_drenagem_l":
        print(f"    --> Executando travamento topologico pos-suavizacao ({tipo_camada})...")
        gdf = travar_topologia_rede_pos_suavizacao(
            gdf, p, tipo_camada, escala_alvo, cols_chave_dinamicas,
            gdf_massa_mantida=gdf_massa_mantida,
            gdf_edif_ref=gdf_edif_ref,
            moldura_folha=moldura_folha,
            gdf_sumidouro=gdf_sumidouro
        )

    gdf['geom'] = gdf['geom'].apply(lambda x: garantir_multi(x, 'linha'))
    return gdf.copy()


def _inserir_ponto_em_linestring(line, pt_coord, tol=1e-4):
    """Insere exatamente a coordenada pt_coord no segmento mais proximo da LineString."""
    coords = list(line.coords)
    px, py = float(pt_coord[0]), float(pt_coord[1])
    for c in coords:
        if math.hypot(c[0] - px, c[1] - py) <= tol:
            return line
    pt_geom = Point(px, py)
    melhor_i = None
    menor_d = float('inf')
    for i in range(len(coords) - 1):
        seg = LineString([coords[i], coords[i + 1]])
        d = seg.distance(pt_geom)
        if d < menor_d:
            menor_d = d
            melhor_i = i
    if melhor_i is not None:
        novas = coords[:melhor_i + 1] + [(px, py)] + coords[melhor_i + 1:]
        return LineString(novas)
    return line


def travar_topologia_rede_pos_suavizacao(
    gdf, p=None, tipo_camada="elemnat_trecho_drenagem_l", escala_alvo="100", cols_chave_dinamicas=None,
    gdf_massa_mantida=None, gdf_edif_ref=None, moldura_folha=None, gdf_sumidouro=None,
    comp_min_1a_ordem=None, gdf_moldura=None, raio_snap_ponta=15.0
):
    if p is None:
        comp_m = float(comp_min_1a_ordem) if comp_min_1a_ordem is not None else 1000.0
        p = {"rede_min": comp_m, "via_min": comp_m, "tol": 5.0}
    if cols_chave_dinamicas is None:
        cols_padrao = ['nome', 'situacaofisica', 'revestimento', 'nrfaixas', 'jurisdicao', 'administracao', 'regime', 'navegabilidade']
        cols_chave_dinamicas = [c for c in cols_padrao if gdf is not None and c in gdf.columns]
    if moldura_folha is None and gdf_moldura is not None and not gdf_moldura.empty:
        moldura_folha = unary_union(gdf_moldura.geom.tolist()).boundary
    """
    Garante que apos a simplificacao e suavizacao:
    1. Toda ponta de grau 1 situada a menos de 15m (searchRadius do DSGTools) de outra linha
       seja conectada exatamente a linha vizinha com vertice compartilhado;
    2. Todas as intersecoes e confluencias em 'T' sejam quebradas nos nos exatos;
    3. Quaisquer tocos residuais (< 30m) ou afluentes de 1a ordem que tenham encolhido abaixo
       de rede_min apos a simplificacao sejam podados ou fundidos;
    4. Pseudonos de grau 2 com mesmos atributos sejam fundidos.
    """
    if gdf is None or gdf.empty:
        return gdf

    # 1. Quebra planar inicial pos-suavizacao
    gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0)
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    gdf = gdf[gdf['geom'].notna() & ~gdf['geom'].is_empty & (gdf['geom'].geom_type == 'LineString')].copy().reset_index(drop=True)
    if gdf.empty:
        return gdf

    # 2. Conectar pontas soltas (grau 1) que estao dentro do raio de busca do DSGTools (15m) de outra linha
    raio_busca_dangle = float(raio_snap_ponta)
    for _rodada in range(2):
        grau = Counter()
        for geom in gdf['geom']:
            cs = list(geom.coords)
            grau[(round(cs[0][0], 3), round(cs[0][1], 3))] += 1
            grau[(round(cs[-1][0], 3), round(cs[-1][1], 3))] += 1

        sidx = gdf.sindex
        alterou = False
        for idx in list(gdf.index):
            geom = gdf.at[idx, 'geom']
            cs = list(geom.coords)
            mudou_geom = False
            for pos_idx in [0, -1]:
                pt_c = cs[pos_idx]
                chave_pt = (round(pt_c[0], 3), round(pt_c[1], 3))
                if grau[chave_pt] != 1:
                    continue
                pt_obj = Point(pt_c)
                cand_idxs = list(sidx.intersection(pt_obj.buffer(raio_busca_dangle).bounds))
                melhor_dist = raio_busca_dangle
                melhor_alvo_idx = None
                melhor_pt_proj = None
                for c_idx in cand_idxs:
                    if c_idx == idx:
                        continue
                    g_alvo = gdf.at[c_idx, 'geom']
                    d = g_alvo.distance(pt_obj)
                    if d < melhor_dist:
                        melhor_dist = d
                        melhor_alvo_idx = c_idx
                        melhor_pt_proj = nearest_points(g_alvo, pt_obj)[0]
                if melhor_alvo_idx is not None and melhor_pt_proj is not None:
                    novo_xy = (melhor_pt_proj.x, melhor_pt_proj.y)
                    adj_xy = cs[1 if pos_idx == 0 else -2]
                    if math.hypot(novo_xy[0] - adj_xy[0], novo_xy[1] - adj_xy[1]) > 1e-3:
                        cs[pos_idx] = novo_xy
                        mudou_geom = True
                        alterou = True
                        gdf.at[melhor_alvo_idx, 'geom'] = _inserir_ponto_em_linestring(
                            gdf.at[melhor_alvo_idx, 'geom'], novo_xy
                        )
                    elif len(cs) >= 3:
                        # O penultimo vertice ja esta exatamente sobre a linha alvo: remove o micro-rebite terminal
                        if pos_idx == 0:
                            cs = cs[1:]
                        else:
                            cs = cs[:-1]
                        mudou_geom = True
                        alterou = True
                        gdf.at[melhor_alvo_idx, 'geom'] = _inserir_ponto_em_linestring(
                            gdf.at[melhor_alvo_idx, 'geom'], adj_xy
                        )
            if mudou_geom:
                gdf.at[idx, 'geom'] = LineString(cs)

        if alterou:
            gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0)
            gdf = gdf.explode(index_parts=False).reset_index(drop=True)
            gdf = gdf[gdf['geom'].notna() & ~gdf['geom'].is_empty & (gdf['geom'].geom_type == 'LineString')].copy().reset_index(drop=True)
        else:
            break

    # 3. Remover micro-overshoots (< 35m) em entroncamentos e rodar poda de 1a ordem pos-simplificacao
    minx, miny, maxx, maxy = gdf.total_bounds
    def _toca_moldura_local(pt_xy):
        if moldura_folha is not None and not moldura_folha.is_empty:
            return Point(pt_xy).distance(moldura_folha) <= 5.0
        return (abs(pt_xy[0] - minx) <= 15.0 or abs(pt_xy[0] - maxx) <= 15.0 or
                abs(pt_xy[1] - miny) <= 15.0 or abs(pt_xy[1] - maxy) <= 15.0)

    grau_atual = Counter()
    for geom in gdf['geom']:
        cs = list(geom.coords)
        grau_atual[(round(cs[0][0], 3), round(cs[0][1], 3))] += 1
        grau_atual[(round(cs[-1][0], 3), round(cs[-1][1], 3))] += 1

    idxs_overshoot = []
    for idx, row in gdf.iterrows():
        geom = row['geom']
        if geom.length < 35.0:
            cs = list(geom.coords)
            k1 = (round(cs[0][0], 3), round(cs[0][1], 3))
            k2 = (round(cs[-1][0], 3), round(cs[-1][1], 3))
            if (grau_atual[k1] == 1 and not _toca_moldura_local(cs[0])) or (grau_atual[k2] == 1 and not _toca_moldura_local(cs[-1])):
                idxs_overshoot.append(idx)
    if idxs_overshoot:
        gdf = gdf.drop(idxs_overshoot).reset_index(drop=True)

    # Re-executa a poda com grafos para garantir que nenhum ramo de 1a ordem ficou < rede_min apos simplificar
    gdf = podar_dangles_com_grafos(
        gdf, p, tipo_camada, escala_alvo,
        gdf_massa_mantida=gdf_massa_mantida,
        gdf_edif_ref=gdf_edif_ref,
        moldura_folha=moldura_folha,
        gdf_sumidouro=gdf_sumidouro
    )

    # 4. Fundir pseudonos de grau 2 com atributos iguais
    gdf = fundir_apenas_pseudonos(gdf, cols_chave_dinamicas)

    # 5. Garantir que nenhuma feicao individual de 1a ordem (grau 1) tenha comprimento < rede_min
    # por causa de mudanca de atributo em pseudono de grau 2 (regra IdentifySmallFirstOrderDangles do DSGTools)
    if tipo_camada == "elemnat_trecho_drenagem_l" and not gdf.empty:
        gdf = _consolidar_pontas_primeira_ordem_curtas(gdf, p['rede_min'], moldura_folha, gdf_sumidouro, gdf_massa_mantida)
        gdf = fundir_apenas_pseudonos(gdf, cols_chave_dinamicas)

    # 6. Limpeza final de espiculas em cada arco mantendo extremos intocados e garantindo quebramento planar
    gdf['geom'] = gdf['geom'].apply(
        lambda g: LineString(limpar_espiculas_coords(list(g.coords), eh_anel=False, min_dist=0.2, min_ang_graus=12.0))
        if (g is not None and g.geom_type == 'LineString' and len(g.coords) >= 2) else g
    )
    gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0)
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    gdf = gdf[gdf['geom'].notna() & ~gdf['geom'].is_empty & (gdf['geom'].geom_type == 'LineString') & (gdf['geom'].length > 0.5)].copy().reset_index(drop=True)
    # Remove qualquer micro-rabicho (< 20m) que tenha surgido no quebramento final
    grau_f = Counter()
    for geom in gdf['geom']:
        cs = list(geom.coords)
        grau_f[(round(cs[0][0], 3), round(cs[0][1], 3))] += 1
        grau_f[(round(cs[-1][0], 3), round(cs[-1][1], 3))] += 1
    drop_f = []
    for idx, row in gdf.iterrows():
        geom = row['geom']
        cs = list(geom.coords)
        k1 = (round(cs[0][0], 3), round(cs[0][1], 3))
        k2 = (round(cs[-1][0], 3), round(cs[-1][1], 3))
        if geom.length < 20.0 and ((grau_f[k1] == 1 and not _toca_moldura_local(cs[0])) or (grau_f[k2] == 1 and not _toca_moldura_local(cs[-1]))):
            drop_f.append(idx)
    if drop_f:
        gdf = gdf.drop(drop_f).reset_index(drop=True)
        gdf = fundir_apenas_pseudonos(gdf, cols_chave_dinamicas)
        gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0)
        gdf = gdf.explode(index_parts=False).reset_index(drop=True)
        gdf = gdf[gdf['geom'].notna() & ~gdf['geom'].is_empty & (gdf['geom'].geom_type == 'LineString') & (gdf['geom'].length > 0.5)].copy().reset_index(drop=True)

    # 7. Verificacao estrita final do criterio IdentifyDangles do DsgTools (raio 5.5m):
    #    Qualquer ponta de grau 1 que tenha outra linha dentro de 5.5m e conectada ou podada (se for rebite curto < 50m)
    for _iter_d in range(3):
        if gdf.empty:
            break
        end_map = {}
        for idx, g in gdf['geom'].items():
            cs = list(g.coords)
            for pos_i, pt in ((0, cs[0]), (-1, cs[-1])):
                k = (round(pt[0], 3), round(pt[1], 3))
                end_map.setdefault(k, []).append((idx, pos_i))
        sidx_d = gdf.sindex
        drop_d = set()
        mod_d = False
        for k, lst in end_map.items():
            if len(lst) != 1:
                continue
            idx_l, pos_i = lst[0]
            if idx_l in drop_d:
                continue
            g_l = gdf.at[idx_l, 'geom']
            pt_g = Point(k)
            buf_g = pt_g.buffer(5.5)
            viz_idxs = [c for c in sidx_d.intersection(buf_g.bounds) if c != idx_l and c not in drop_d and gdf.at[c, 'geom'].intersects(buf_g)]
            if viz_idxs:
                if g_l.length < 50.0:
                    drop_d.add(idx_l)
                    mod_d = True
                else:
                    # Conecta na linha vizinha mais proxima
                    c_alvo = min(viz_idxs, key=lambda c: gdf.at[c, 'geom'].distance(pt_g))
                    pt_proj = nearest_points(gdf.at[c_alvo, 'geom'], pt_g)[0]
                    novo_xy = (pt_proj.x, pt_proj.y)
                    cs_l = list(g_l.coords)
                    adj_xy = cs_l[1 if pos_i == 0 else -2]
                    if math.hypot(novo_xy[0] - adj_xy[0], novo_xy[1] - adj_xy[1]) > 1e-3:
                        cs_l[pos_i] = novo_xy
                    elif len(cs_l) >= 3:
                        cs_l = cs_l[1:] if pos_i == 0 else cs_l[:-1]
                        novo_xy = adj_xy
                    gdf.at[idx_l, 'geom'] = LineString(cs_l)
                    gdf.at[c_alvo, 'geom'] = _inserir_ponto_em_linestring(gdf.at[c_alvo, 'geom'], novo_xy)
                    mod_d = True
        if drop_d:
            gdf = gdf.drop(list(drop_d)).reset_index(drop=True)
        if mod_d:
            gdf = quebrar_linhas_nos_entroncamentos(gdf, snap_tol=0.0)
            gdf = gdf.explode(index_parts=False).reset_index(drop=True)
            gdf = gdf[gdf['geom'].notna() & ~gdf['geom'].is_empty & (gdf['geom'].geom_type == 'LineString') & (gdf['geom'].length > 0.5)].copy().reset_index(drop=True)
        else:
            break

    return gdf.reset_index(drop=True)


def _consolidar_pontas_primeira_ordem_curtas(gdf, rede_min, moldura_folha=None, gdf_sumidouro=None, gdf_massa_mantida=None):
    """
    Se um trecho extremo de 1a ordem (grau 1) tiver comprimento individual < rede_min porque
    encontrou um pseudono de grau 2 onde algum atributo secundario mudou, unifica-o com o trecho
    seguinte de grau 2 (ou poda se o ramo inteiro for < rede_min).
    """
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    u_sumid = unary_union(gdf_sumidouro['geom'].tolist()) if (gdf_sumidouro is not None and not gdf_sumidouro.empty) else None
    u_massa = unary_union(gdf_massa_mantida['geom'].tolist()) if (gdf_massa_mantida is not None and not gdf_massa_mantida.empty) else None
    minx, miny, maxx, maxy = gdf.total_bounds

    def _protegido(pt_xy):
        pt = Point(pt_xy)
        if moldura_folha is not None and not moldura_folha.is_empty and pt.distance(moldura_folha) <= 5.0:
            return True
        if u_sumid is not None and not u_sumid.is_empty and pt.distance(u_sumid) <= 15.0:
            return True
        if u_massa is not None and not u_massa.is_empty and pt.distance(u_massa) <= 5.0:
            return True
        return (abs(pt_xy[0] - minx) <= 15.0 or abs(pt_xy[0] - maxx) <= 15.0 or
                abs(pt_xy[1] - miny) <= 15.0 or abs(pt_xy[1] - maxy) <= 15.0)

    for _ in range(5):
        mapa_no = {}
        for idx, row in gdf.iterrows():
            geom = row['geom']
            if geom is None or geom.geom_type != 'LineString':
                continue
            cs = list(geom.coords)
            k1 = (round(cs[0][0], 3), round(cs[0][1], 3))
            k2 = (round(cs[-1][0], 3), round(cs[-1][1], 3))
            mapa_no.setdefault(k1, []).append((idx, 0))
            mapa_no.setdefault(k2, []).append((idx, -1))

        mudou = False
        remover = set()
        for idx, row in gdf.iterrows():
            if idx in remover:
                continue
            geom = row['geom']
            if geom is None or geom.geom_type != 'LineString' or geom.length >= rede_min:
                continue
            cs = list(geom.coords)
            k1 = (round(cs[0][0], 3), round(cs[0][1], 3))
            k2 = (round(cs[-1][0], 3), round(cs[-1][1], 3))
            deg1 = len(mapa_no.get(k1, []))
            deg2 = len(mapa_no.get(k2, []))

            ponta_k = None
            interno_k = None
            pt_ponta = None
            if deg1 == 1 and not _protegido(cs[0]):
                ponta_k, interno_k, pt_ponta = k1, k2, cs[0]
            elif deg2 == 1 and not _protegido(cs[-1]):
                ponta_k, interno_k, pt_ponta = k2, k1, cs[-1]

            if ponta_k is None:
                continue

            vizinhos = [v_idx for v_idx, _ in mapa_no.get(interno_k, []) if v_idx != idx and v_idx not in remover]
            if len(vizinhos) == 1:
                # Pseudono de grau 2: funde geometria na feicao vizinha para eliminar falso dangle curto
                v_idx = vizinhos[0]
                g_viz = gdf.at[v_idx, 'geom']
                merged = linemerge([geom, g_viz])
                if merged.geom_type == 'LineString':
                    gdf.at[v_idx, 'geom'] = merged
                    remover.add(idx)
                    mudou = True
            else:
                # Confluencia de grau >= 3 ou isolado com comprimento < rede_min: poda o toco curto
                remover.add(idx)
                mudou = True

        if remover:
            gdf = gdf.drop(list(remover)).reset_index(drop=True)
        if not mudou:
            break

    return gdf

def fechar_fissuras_projecao(geom, delta=0.5):
    """
    Remove micro-fissuras internas e limpa espiculas sem usar buffer MITRE (join_style=2),
    impedindo a criacao de bicos agudos (< 10 graus) e aneis auto-tangentes.
    """
    if geom is None or geom.is_empty:
        return geom
    try:
        if not geom.is_valid:
            geom = make_valid(geom)
        polys = []
        _coletar_polys_lista(geom, polys)
        limpos = []
        for p in polys:
            ext_c = limpar_espiculas_coords(list(p.exterior.coords), eh_anel=True, min_dist=0.1, min_ang_graus=11.0)
            if len(ext_c) < 4:
                continue
            holes_c = []
            for h in p.interiors:
                hp = Polygon(h)
                if hp.area >= 25.0:
                    hc = limpar_espiculas_coords(list(h.coords), eh_anel=True, min_dist=0.1, min_ang_graus=11.0)
                    if len(hc) >= 4:
                        holes_c.append(hc)
            p_novo = Polygon(ext_c, holes_c)
            if not p_novo.is_valid:
                p_novo = make_valid(p_novo)
            _coletar_polys_lista(p_novo, limpos)
        if not limpos:
            return geom
        return unary_union(limpos) if len(limpos) > 1 else limpos[0]
    except Exception:
        return geom


def dissolver_e_explodir_cobertura(gdf, cols_agrupar, fechar_fissuras=True):
    """
    Dissolve poligonos contiguos da mesma subclasse/tipo preservando atributos,
    limpa espiculas e explode em poligonos simples para avaliacao de area.
    """
    if gdf is None or gdf.empty:
        return gdf
    cols = [c for c in cols_agrupar if c in gdf.columns]
    df_temp = gdf.copy()
    if not cols:
        df_temp['_dummy'] = 1
        cols = ['_dummy']
    for c in cols:
        df_temp[c] = df_temp[c].fillna("<<NULL>>")
    outras = [c for c in df_temp.columns if c not in cols and c != 'geom']
    agg = {c: 'first' for c in outras}
    diss = df_temp.dissolve(by=cols, aggfunc=agg, as_index=False)
    for c in cols:
        diss[c] = diss[c].replace("<<NULL>>", None)
    if '_dummy' in diss.columns:
        diss.drop(columns=['_dummy'], inplace=True)
    if fechar_fissuras:
        diss['geom'] = diss['geom'].apply(lambda g: fechar_fissuras_projecao(g, 0.5))
    diss['geom'] = diss['geom'].apply(lambda g: make_valid(g) if g is not None and not g.is_valid else g)
    diss = diss.explode(index_parts=False).reset_index(drop=True)
    diss = diss[diss['geom'].notna() & ~diss['geom'].is_empty & diss['geom'].geom_type.isin(['Polygon', 'MultiPolygon'])].copy()
    return diss.reset_index(drop=True)


def doar_poligono_para_vizinho(geom_peq, candidatos_gdfs):
    """
    Doa um poligono menor que a area minima normativa (ET-ADGV 3.0) para o poligono
    adjacente (dentre os GeoDataFrames candidatos) com a maior fronteira compartilhada,
    impedindo a abertura de buracos na cobertura terrestre.
    """
    melhor_gdf = None
    melhor_idx = None
    maior_inter = -1.0
    geom_buf = geom_peq.buffer(2.0)
    for gdf_cand in candidatos_gdfs:
        if gdf_cand is None or gdf_cand.empty:
            continue
        sidx = gdf_cand.sindex
        pos = list(sidx.intersection(geom_buf.bounds))
        for idx in pos:
            g_cand = gdf_cand.at[idx, 'geom']
            if g_cand is not None and not g_cand.is_empty and g_cand.intersects(geom_buf):
                tam = g_cand.boundary.intersection(geom_buf).length
                if tam > maior_inter:
                    maior_inter = tam
                    melhor_gdf = gdf_cand
                    melhor_idx = idx
    if melhor_gdf is not None and melhor_idx is not None:
        nova = unary_union([melhor_gdf.at[melhor_idx, 'geom'], geom_peq])
        if not nova.is_valid:
            nova = make_valid(nova)
        melhor_gdf.at[melhor_idx, 'geom'] = nova
        return True
    return False


def _garantir_disjuncao_interna_gdf(gdf, area_min_sliver=50.0):
    """Garante que nenhum poligono dentro do mesmo GeoDataFrame tenha sobreposicao com outro."""
    if gdf is None or gdf.empty:
        return gdf
    gdf = gdf.explode(index_parts=False).reset_index(drop=True)
    gdf['_area_sort'] = gdf['geom'].area
    gdf = gdf.sort_values(by='_area_sort', ascending=False).reset_index(drop=True)
    ocupado = None
    linhas_ok = []
    for _, row in gdf.iterrows():
        g = row['geom']
        if g is None or g.is_empty:
            continue
        if not g.is_valid:
            g = make_valid(g)
        if ocupado is not None and not ocupado.is_empty and g.intersects(ocupado):
            g = g.difference(ocupado)
        polys = []
        _coletar_polys_lista(g, polys)
        for p_part in polys:
            if p_part.area >= area_min_sliver:
                r_d = row.to_dict()
                r_d.pop('_area_sort', None)
                r_d['geom'] = p_part
                linhas_ok.append(r_d)
                ocupado = p_part if ocupado is None else unary_union([ocupado, p_part])
    if not linhas_ok:
        return gdf.drop(columns=['_area_sort'], errors='ignore')
    return gpd.GeoDataFrame(linhas_ok, crs=gdf.crs, geometry='geom')


def generalizar_cobertura_terrestre_integrada(gdf_massa, gdf_veg, gdf_edif, p, moldura_oficial_poly=None):
    """
    Generaliza de forma integrada e topologicamente estanque as camadas de Cobertura Terrestre
    (Massa d'Agua, Area Edificada e Vegetacao) conforme ET-ADGV 3.0 e ET-CQDG:
    - Construcao por Particao Plana Booleana e Poligonizacao Topologica:
      Garante matematicamente ZERO buracos (gaps = 0) e ZERO sobreposicoes (overlaps = 0)
      no teste 'Identificar Buracos e Sobreposicoes na Camada de Cobertura da Terra' do DSGTools;
    - Todos os vertices em juncoes triplas ('T') sao compartilhados entre as classes adjacentes;
    - Todos os aneis tocantes sao desatados (0 flags em 'Identificar e Consertar Geometrias Invalidas').
    """
    print("\n    --> [Cobertura Terrestre Integrada] Processando particao plana estanque (0 buracos / 0 sobreposicoes)...")
    todas_orig = []
    crs_ref = None
    for gdf in [gdf_massa, gdf_veg, gdf_edif]:
        if gdf is not None and not gdf.empty:
            if crs_ref is None:
                crs_ref = gdf.crs
            todas_orig.extend(gdf['geom'].tolist())
    if not todas_orig:
        return gdf_massa, gdf_veg, gdf_edif, None

    # Determina o dominio exato da folha (sem buracos internos)
    if moldura_oficial_poly is not None and not moldura_oficial_poly.is_empty:
        polys_dom = []
        _coletar_polys_lista(moldura_oficial_poly, polys_dom)
        dominio_folha = unary_union([Polygon(pd_i.exterior) for pd_i in polys_dom])
    else:
        uniao_bruta = unary_union(todas_orig)
        if not uniao_bruta.is_valid:
            uniao_bruta = make_valid(uniao_bruta)
        polys_dom = []
        _coletar_polys_lista(uniao_bruta, polys_dom)
        # Mantem apenas os contornos externos da folha (preenchendo qualquer fresta interna)
        dominio_folha = unary_union([Polygon(pd_i.exterior) for pd_i in polys_dom if pd_i.area > 1000.0])

    moldura_folha = dominio_folha.boundary
    massa_min = p.get("massa_min", 40000.0)
    solo_min = p.get("solo_min", 250000.0)
    sliver_min = 100.0 if solo_min <= 62500.0 else (250.0 if solo_min <= 250000.0 else 500.0)

    # 1. Dissolver poligonos contiguos da mesma classe/tipo
    if gdf_massa is not None and not gdf_massa.empty:
        cols_m = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_massa.columns]
        gdf_massa = dissolver_e_explodir_cobertura(gdf_massa, cols_m, fechar_fissuras=True)
    if gdf_veg is not None and not gdf_veg.empty:
        cols_v = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_veg.columns]
        gdf_veg = dissolver_e_explodir_cobertura(gdf_veg, cols_v, fechar_fissuras=True)
    if gdf_edif is not None and not gdf_edif.empty:
        cols_e = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_edif.columns]
        gdf_edif = dissolver_e_explodir_cobertura(gdf_edif, cols_e, fechar_fissuras=True)

    # 2. Filtrar Massa d'Agua: manter >= massa_min OU com nome valido (exceto micro-slivers < 500 m2)
    if gdf_massa is not None and not gdf_massa.empty:
        col_nome_m = achar_coluna(gdf_massa, ['nome', 'nm_corpo', 'denominacao', 'toponimo', 'identificador'])
        def massa_valida(row):
            area = row['geom'].area
            if area >= massa_min:
                return True
            if area < 500.0:
                return False
            if col_nome_m:
                v_nome = row.get(col_nome_m, None)
                if pd.notna(v_nome) and str(v_nome).strip().upper() not in ["", "NULL", "NONE", "NAN", "DESCONHECIDO"]:
                    return True
            return False

        mask_m = gdf_massa.apply(massa_valida, axis=1)
        massas_rem = gdf_massa[~mask_m].copy()
        gdf_massa = gdf_massa[mask_m].copy().reset_index(drop=True)
        for _, row in massas_rem.iterrows():
            doar_poligono_para_vizinho(row['geom'], [gdf_veg, gdf_edif])

    # 3. Filtrar Area Edificada: manter >= solo_min; menores sao absorvidas por edif ou veg adjacente
    if gdf_edif is not None and not gdf_edif.empty:
        cols_e = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_edif.columns]
        gdf_edif = dissolver_e_explodir_cobertura(gdf_edif, cols_e, fechar_fissuras=True)
        edif_grandes = gdf_edif[gdf_edif['geom'].area >= solo_min].copy().reset_index(drop=True)
        edif_peq = gdf_edif[gdf_edif['geom'].area < solo_min].copy()
        for _, row in edif_peq.iterrows():
            doar_poligono_para_vizinho(row['geom'], [edif_grandes, gdf_veg])
        gdf_edif = edif_grandes

    # 4. Filtrar Vegetacao: manter >= solo_min; fragmentos menores sao absorvidos na vizinhanca
    if gdf_veg is not None and not gdf_veg.empty:
        cols_v = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_veg.columns]
        gdf_veg = dissolver_e_explodir_cobertura(gdf_veg, cols_v, fechar_fissuras=True)
        veg_grandes = gdf_veg[gdf_veg['geom'].area >= solo_min].copy().reset_index(drop=True)
        veg_peq = gdf_veg[gdf_veg['geom'].area < solo_min].copy()

        u_veg_grandes = unary_union(veg_grandes['geom'].tolist()) if not veg_grandes.empty else Polygon()
        u_edif = unary_union(gdf_edif['geom'].tolist()) if (gdf_edif is not None and not gdf_edif.empty) else Polygon()
        u_terra = unary_union([g for g in [u_veg_grandes, u_edif] if g is not None and not g.is_empty])

        veg_resgatada = []
        for _, row in veg_peq.iterrows():
            geom_p = row['geom']
            toca_moldura = geom_p.distance(moldura_folha) < 10.0
            borda_terra = geom_p.boundary.intersection(u_terra.buffer(2.0)).length if (u_terra is not None and not u_terra.is_empty) else 0.0
            if toca_moldura and borda_terra < 5.0:
                veg_resgatada.append(row)
            else:
                if not doar_poligono_para_vizinho(geom_p, [veg_grandes, gdf_edif]):
                    doar_poligono_para_vizinho(geom_p, [gdf_massa])

        if veg_resgatada:
            gdf_resg = gpd.GeoDataFrame(veg_resgatada, crs=gdf_veg.crs, geometry='geom')
            veg_grandes = pd.concat([veg_grandes, gdf_resg], ignore_index=True)

        gdf_veg = dissolver_e_explodir_cobertura(veg_grandes, cols_v, fechar_fissuras=True)

    # 5. Particao Plana Hierarquica Estrita (Massa d'Agua > Area Edificada > Vegetacao)
    # 5.1 Massa d'Agua: recortada pelo dominio da folha e disjunta internamente
    u_massa_final = Polygon()
    if gdf_massa is not None and not gdf_massa.empty:
        gdf_massa['geom'] = gdf_massa['geom'].apply(lambda g: g.intersection(dominio_folha) if g is not None else g)
        cols_m = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_massa.columns]
        gdf_massa = dissolver_e_explodir_cobertura(gdf_massa, cols_m, fechar_fissuras=True)
        gdf_massa = _garantir_disjuncao_interna_gdf(gdf_massa, area_min_sliver=500.0)
        if not gdf_massa.empty:
            u_massa_final = unary_union(gdf_massa['geom'].tolist())

    # 5.2 Area Edificada: recortada por (dominio_folha - Massa d'Agua) e disjunta internamente
    u_edif_final = Polygon()
    if gdf_edif is not None and not gdf_edif.empty:
        zona_edif = dominio_folha.difference(u_massa_final) if not u_massa_final.is_empty else dominio_folha
        gdf_edif['geom'] = gdf_edif['geom'].apply(lambda g: g.intersection(zona_edif) if g is not None else g)
        cols_e = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_edif.columns]
        gdf_edif = dissolver_e_explodir_cobertura(gdf_edif, cols_e, fechar_fissuras=True)
        gdf_edif = _garantir_disjuncao_interna_gdf(gdf_edif, area_min_sliver=sliver_min)
        if not gdf_edif.empty:
            u_edif_final = unary_union(gdf_edif['geom'].tolist())

    # 5.3 Vegetacao: recortada por (dominio_folha - Massa d'Agua - Area Edificada) e disjunta internamente
    u_ocupado_prioritario = unary_union([g for g in [u_massa_final, u_edif_final] if g is not None and not g.is_empty])
    zona_veg = dominio_folha.difference(u_ocupado_prioritario) if (u_ocupado_prioritario is not None and not u_ocupado_prioritario.is_empty) else dominio_folha

    if gdf_veg is not None and not gdf_veg.empty:
        gdf_veg['geom'] = gdf_veg['geom'].apply(lambda g: g.intersection(zona_veg) if g is not None else g)
        cols_v = [c for c in ['classe', 'tipo', 'nome'] if c in gdf_veg.columns]
        gdf_veg = dissolver_e_explodir_cobertura(gdf_veg, cols_v, fechar_fissuras=True)
        gdf_veg = _garantir_disjuncao_interna_gdf(gdf_veg, area_min_sliver=sliver_min)

    # 5.4 Fechamento Matematico de 100% dos Buracos Restantes dentro de dominio_folha
    geoms_cobertas = []
    for gdf_c in [gdf_massa, gdf_edif, gdf_veg]:
        if gdf_c is not None and not gdf_c.empty:
            geoms_cobertas.extend(gdf_c['geom'].tolist())
    u_coberto_total = unary_union(geoms_cobertas) if geoms_cobertas else Polygon()
    vazios_restantes = dominio_folha.difference(u_coberto_total)

    gaps_list = []
    _coletar_polys_lista(vazios_restantes, gaps_list)
    if gaps_list:
        print(f"    --> [Cobertura Estanque] Absorvendo {len(gaps_list)} vazios residuais para garantir 0 buracos...")
        for gap_poly in gaps_list:
            if gap_poly.area <= 1e-6:
                continue
            if not doar_poligono_para_vizinho(gap_poly, [gdf_veg, gdf_edif, gdf_massa]):
                # Se ainda nao tocou por distancia > 2m, atribui ao poligono mais proximo de vegetacao
                if gdf_veg is not None and not gdf_veg.empty:
                    dists = gdf_veg['geom'].distance(gap_poly)
                    idx_min = dists.idxmin()
                    gdf_veg.at[idx_min, 'geom'] = unary_union([gdf_veg.at[idx_min, 'geom'], gap_poly])

        # Re-garantir disjuncao estrita apos doacao dos vazios
        if gdf_veg is not None and not gdf_veg.empty:
            gdf_veg['geom'] = gdf_veg['geom'].apply(lambda g: g.intersection(zona_veg) if g is not None else g)
            gdf_veg = _garantir_disjuncao_interna_gdf(gdf_veg, area_min_sliver=1e-4)

    # 6. Insercao de vertices compartilhados nas fronteiras entre Massa, Edif e Veg (evita fissuras ao reprojetar p/ 4674)
    todas_bordas = [dominio_folha.boundary]
    for gdf_c in [gdf_massa, gdf_edif, gdf_veg]:
        if gdf_c is not None and not gdf_c.empty:
            todas_bordas.extend([g.boundary for g in gdf_c['geom'] if g is not None and not g.is_empty])
    malha_nodada = unary_union(todas_bordas)

    for gdf_c in [gdf_massa, gdf_edif, gdf_veg]:
        if gdf_c is not None and not gdf_c.empty:
            gdf_c['geom'] = gdf_c['geom'].apply(lambda g: snap(g, malha_nodada, 1e-3) if g is not None else g)
            gdf_c['geom'] = gdf_c['geom'].apply(lambda x: garantir_multi(x, 'poligono'))

    return gdf_massa, gdf_veg, gdf_edif, moldura_folha

def carregar_tabela_inteligente(engine, schema, tipo_padrao, epsg_utm):
    """
    Busca a tabela no banco usando o Repositorio Oficial de Modelagens da DSG (PI),
    com identificacao automatica da modelagem (EDGV 3.0 Topo, 2.1.3, Orto, etc.).
    """
    if TEM_REPOSITORIO:
        return _carregar_tabela_repo(engine, schema, tipo_padrao, epsg_utm)

    inspector = inspect(engine)
    tabelas_db = inspector.get_table_names(schema=schema)
    
    palavras_chave = KEYWORDS_MAP.get(tipo_padrao, [tipo_padrao])
    tabela_encontrada = None
    sufixo_esperado = tipo_padrao[-2:].lower() if tipo_padrao[-2:] in ['_l', '_a', '_p'] else None
    termos_proibidos = ['centroide', 'delimitador', 'edicao', '_50k', '_100k', '_250k']
    
    if tipo_padrao in tabelas_db:
        tabela_encontrada = tipo_padrao
    else:
        for tabela in tabelas_db:
            tabela_lower = tabela.lower()
            if any(proibido in tabela_lower for proibido in termos_proibidos):
                continue
            if sufixo_esperado and not tabela_lower.endswith(sufixo_esperado):
                continue
            for kw in palavras_chave:
                if kw in tabela_lower:
                    tabela_encontrada = tabela
                    break
            if tabela_encontrada: 
                break
                
    if not tabela_encontrada:
        print(f"[AVISO] Atencao: Nenhuma tabela compativel com '{tipo_padrao}' (sufixo {sufixo_esperado}) foi localizada no schema '{schema}'.")
        return None, None, None
        
    print(f"    [+] Tabela identificada autonomamente no PostGIS para '{tipo_padrao}': {tabela_encontrada}")
    
    query = f"SELECT * FROM {schema}.{tabela_encontrada}"
    gdf = gpd.read_postgis(query, con=engine)
    
    geom_col_name = gdf.geometry.name
    if geom_col_name != 'geom':
        gdf = gdf.rename_geometry('geom')
    
    crs_original = gdf.crs
    if not gdf.empty and gdf.crs is not None:
        gdf = gdf.to_crs(epsg=epsg_utm)
        
    return gdf, tabela_encontrada, crs_original

def fechar_gaps_inter_camadas(gdf_massa, gdf_veg, gdf_edif, p):
    """
    Identifica "vazios brancos" (gaps intersticiais e frestas de borda/moldura) 
    calculando a diferenca geometrica entre o Bounding Box da folha e a 
    uniao das camadas de cobertura, doando-os para o poligono vizinho dominante.
    """
    print("\n    --> [Fechamento de Gaps] Mapeando e preenchendo vazios brancos inter-camadas...")
    
    gdfs = []
    if gdf_massa is not None and not gdf_massa.empty: gdfs.append(gdf_massa)
    if gdf_veg is not None and not gdf_veg.empty: gdfs.append(gdf_veg)
    if gdf_edif is not None and not gdf_edif.empty: gdfs.append(gdf_edif)
    
    if not gdfs:
        return gdf_massa, gdf_veg, gdf_edif

    # 1. Obter Bounding Box Total da Folha
    minx = min([gdf.total_bounds[0] for gdf in gdfs])
    miny = min([gdf.total_bounds[1] for gdf in gdfs])
    maxx = max([gdf.total_bounds[2] for gdf in gdfs])
    maxy = max([gdf.total_bounds[3] for gdf in gdfs])
    bbox = box(minx, miny, maxx, maxy)
    
    # 2. Uniao de toda a Cobertura Existente
    todas_geometrias = []
    for gdf in gdfs:
        todas_geometrias.extend(gdf['geom'].tolist())
    cobertura_existente = unary_union(todas_geometrias)
    
    # 3. Extracao dos Vazios Brancos (Diferenca)
    vazios_brutos = bbox.difference(cobertura_existente)
    
    vazios = []
    if vazios_brutos.geom_type == 'Polygon':
        vazios.append(vazios_brutos)
    elif vazios_brutos.geom_type == 'MultiPolygon':
        vazios.extend(list(vazios_brutos.geoms))
    elif vazios_brutos.geom_type == 'GeometryCollection':
        for g in vazios_brutos.geoms:
            if g.geom_type == 'Polygon':
                vazios.append(g)
            elif g.geom_type == 'MultiPolygon':
                vazios.extend(list(g.geoms))
        
    vazios_pequenos = [v for v in vazios if v.area < p["solo_min"] * 1.5]
    
    if not vazios_pequenos:
        print("    --> Nenhum vazio intersticial detectado.")
        return gdf_massa, gdf_veg, gdf_edif
        
    print(f"    --> Encontrados {len(vazios_pequenos)} vazios (gaps). Absorvendo na camada dominante...")
    
    sindex_massa = gdf_massa.sindex if gdf_massa is not None and not gdf_massa.empty else None
    sindex_veg = gdf_veg.sindex if gdf_veg is not None and not gdf_veg.empty else None
    sindex_edif = gdf_edif.sindex if gdf_edif is not None and not gdf_edif.empty else None
    
    for gap in vazios_pequenos:
        maior_borda = -1
        gdf_vencedor = None
        idx_vencedor = None
        
        # Avaliar contato com Massas d'Agua
        if sindex_massa is not None:
            possiveis = list(sindex_massa.intersection(gap.bounds))
            vizinhos = gdf_massa.iloc[possiveis]
            for v_idx, v_row in vizinhos.iterrows():
                if v_row['geom'].touches(gap) or v_row['geom'].intersects(gap):
                    borda = v_row['geom'].intersection(gap).length
                    if borda > maior_borda:
                        maior_borda = borda
                        gdf_vencedor = gdf_massa
                        idx_vencedor = v_idx
                        
        # Avaliar contato com Vegetacao
        if sindex_veg is not None:
            possiveis = list(sindex_veg.intersection(gap.bounds))
            vizinhos = gdf_veg.iloc[possiveis]
            for v_idx, v_row in vizinhos.iterrows():
                if v_row['geom'].touches(gap) or v_row['geom'].intersects(gap):
                    borda = v_row['geom'].intersection(gap).length
                    if borda > maior_borda:
                        maior_borda = borda
                        gdf_vencedor = gdf_veg
                        idx_vencedor = v_idx
                        
        # Avaliar contato com Area Edificada
        if sindex_edif is not None:
            possiveis = list(sindex_edif.intersection(gap.bounds))
            vizinhos = gdf_edif.iloc[possiveis]
            for v_idx, v_row in vizinhos.iterrows():
                if v_row['geom'].touches(gap) or v_row['geom'].intersects(gap):
                    borda = v_row['geom'].intersection(gap).length
                    if borda > maior_borda:
                        maior_borda = borda
                        gdf_vencedor = gdf_edif
                        idx_vencedor = v_idx
                        
        # Se nao tocou diretamente com borda 0m, busca vizinho mais proximo em raio de 30m
        if gdf_vencedor is None and sindex_veg is not None and not gdf_veg.empty:
            gap_buf = gap.buffer(30.0)
            possiveis_buf = list(sindex_veg.intersection(gap_buf.bounds))
            if possiveis_buf:
                viz_buf = gdf_veg.iloc[possiveis_buf]
                distancias = viz_buf['geom'].distance(gap)
                melhor = distancias.idxmin()
                gdf_vencedor = gdf_veg
                idx_vencedor = melhor
                
        if gdf_vencedor is not None and idx_vencedor is not None:
            gdf_vencedor.at[idx_vencedor, 'geom'] = unary_union([gdf_vencedor.at[idx_vencedor, 'geom'], gap])

    if gdf_massa is not None and not gdf_massa.empty:
        gdf_massa['geom'] = gdf_massa['geom'].apply(lambda x: garantir_multi(x, 'poligono'))
    if gdf_veg is not None and not gdf_veg.empty:
        gdf_veg['geom'] = gdf_veg['geom'].apply(lambda x: garantir_multi(x, 'poligono'))
    if gdf_edif is not None and not gdf_edif.empty:
        gdf_edif['geom'] = gdf_edif['geom'].apply(lambda x: garantir_multi(x, 'poligono'))

    return gdf_massa, gdf_veg, gdf_edif

# =====================================================================
# LOOP PRINCIPAL DE PROCESSAMENTO
# =====================================================================

def main():
    os.system("color 0F")
    print("===============================================================")
    print(" [SGC] GENERALIZADOR POSTGIS: TOTALMENTE AUTONOMO E VERSATIL")
    print("===============================================================\n")
    
    def_host = os.getenv("DB_HOST", "localhost")
    def_banco = os.getenv("DB_NAME", "")
    def_usuario = os.getenv("DB_USER", "postgres")
    def_senha = os.getenv("DB_PASSWORD", "postgres")
    def_port = os.getenv("DB_PORT", "5432")
    def_schema = os.getenv("DB_SCHEMA", "edgv")
    def_epsg = os.getenv("DEFAULT_EPSG", "31983")
    
    host = input(f"Host [Enter = {def_host}]: ").strip() or def_host
    banco = (input(f"Banco de Dados [Enter = {def_banco}]: ").strip() or def_banco) if def_banco else input("Banco de Dados: ").strip()
    usuario = input(f"Usuario [Enter = {def_usuario}]: ").strip() or def_usuario
    senha = input(f"Senha [Enter = {def_senha}]: ").strip() or def_senha
    schema_input = input(f"Schema [Enter = {def_schema}]: ").strip() or def_schema
    
    epsg_input = input(f"Codigo EPSG UTM da regiao [Enter = {def_epsg}]: ").strip() or def_epsg
    epsg_utm = int(epsg_input)
    
    print("\n[OPCAO] Escala alvo:")
    print("1 - 1:50.000")
    print("2 - 1:100.000")
    print("3 - 1:250.000")
    opcao = input("> Opcao: ").strip()
    
    opcoes_escala = {"1": "50", "2": "100", "3": "250"}
    if opcao not in opcoes_escala:
        print("[ERRO] Opcao invalida.")
        return
        
    escala_alvo = opcoes_escala[opcao]
    p_geral = obter_parametros(escala_alvo, "elemnat_trecho_drenagem_l")
    
    import urllib.parse
    senha_encoded = urllib.parse.quote_plus(senha)
    str_conexao = f"postgresql://{usuario}:{senha_encoded}@{host}:{def_port}/{banco}"
    engine = create_engine(str_conexao)
    
    # Auto-ativacao da extensao espacial PostGIS caso o banco seja recem-criado
    try:
        with engine.connect() as conn:
            conn.execution_options(isolation_level="AUTOCOMMIT").execute(text("CREATE EXTENSION IF NOT EXISTS postgis;"))
    except Exception:
        pass

    # Verificacao de Schema Inteligente
    insp = inspect(engine)
    schemas_banco = insp.get_schema_names()
    schema = schema_input
    
    if schema not in schemas_banco or len(insp.get_table_names(schema=schema)) <= 3:
        if 'edgv' in schemas_banco and len(insp.get_table_names(schema='edgv')) > 5:
            schema = 'edgv'
            print(f"    [+] Schema alternativo selecionado automaticamente: '{schema}' ({len(insp.get_table_names(schema='edgv'))} tabelas)")
        elif 'public' in schemas_banco and len(insp.get_table_names(schema='public')) > 5:
            schema = 'public'
            print(f"    [+] Schema alternativo selecionado automaticamente: '{schema}'")
            
    # Identificacao automatica e exibicao da modelagem no terminal e no titulo da janela
    if TEM_REPOSITORIO:
        try:
            from repositorio_modelagens import repositorio
            repositorio._INSTANCIA_GLOBAL = RepositorioModelagens(engine=engine, schema=schema)
            repositorio._INSTANCIA_GLOBAL.imprimir_diagnostico_banco()
            os.system(f'title SISTEMA DE GENERALIZACAO CARTOGRAFICA - DSG [Banco: {banco} ^| Modelagem: {repositorio._INSTANCIA_GLOBAL.descricao_versao}]')
        except Exception:
            pass
    
    sufixo = f"_50k" if escala_alvo == "50" else (f"_100k" if escala_alvo == "100" else f"_250k")
    
    print("\n[*] Varrendo o PostGIS com reconhecimento autonomo de tabelas...")
    try:
        gdf_dren, tab_dren, crs_orig_dren = carregar_tabela_inteligente(engine, schema, "elemnat_trecho_drenagem_l", epsg_utm)
        gdf_massa, tab_massa, crs_orig_massa = carregar_tabela_inteligente(engine, schema, "cobter_corpo_dagua_a", epsg_utm)
        gdf_veg, tab_veg, crs_orig_veg = carregar_tabela_inteligente(engine, schema, "cobter_vegetacao_a", epsg_utm)
        gdf_edif, tab_edif, crs_orig_edif = carregar_tabela_inteligente(engine, schema, "cobter_area_edificada_a", epsg_utm)
        gdf_moldura, _, _ = carregar_tabela_inteligente(engine, schema, "aux_moldura_a", epsg_utm)
        gdf_sumidouro, _, _ = carregar_tabela_inteligente(engine, schema, "elemnat_sumidouro_vertedouro_p", epsg_utm)

        moldura_folha_oficial = None
        moldura_oficial_poly = None
        if gdf_moldura is not None and not gdf_moldura.empty:
            moldura_oficial_poly = unary_union(gdf_moldura['geom'].tolist())
            moldura_folha_oficial = moldura_oficial_poly.boundary

        # Preserva copia original da Area Edificada para identificar arruamentos urbanos (Regra P110)
        gdf_edif_orig_ref = gdf_edif.copy() if (gdf_edif is not None and not gdf_edif.empty) else None
        
        if gdf_massa is not None and not gdf_massa.empty:
            gdf_massa, gdf_dren, gdf_veg, gdf_edif = costurar_topologia_inter_camadas(gdf_massa, gdf_dren, gdf_veg, gdf_edif, p_geral)

        # =========================================================
        # GENERALIZACAO INTEGRADA DE COBERTURA TERRESTRE (SEM BURACOS E SEM DISTORCOES)
        # =========================================================
        gdf_massa, gdf_veg, gdf_edif, moldura_folha_cob = generalizar_cobertura_terrestre_integrada(
            gdf_massa, gdf_veg, gdf_edif, p_geral, moldura_oficial_poly=moldura_oficial_poly
        )
        moldura_folha = moldura_folha_oficial if (moldura_folha_oficial is not None and not moldura_folha_oficial.is_empty) else moldura_folha_cob

        # Generalizacao da Drenagem (com protecao de moldura consolidada e sumidouros/vertedouros)
        if gdf_dren is not None and not gdf_dren.empty:
            print("\n[*] Generalizando drenagem...")
            gdf_dren = generalizar_linhas_com_topologia(
                gdf_dren,
                escala_alvo,
                "elemnat_trecho_drenagem_l",
                gdf_massa_mantida=gdf_massa,
                moldura_folha=moldura_folha,
                gdf_sumidouro=gdf_sumidouro
            )
            salvar_e_habilitar_edicao_postgis(gdf_dren, engine, schema, f"{tab_dren}{sufixo}", crs_orig_dren)
            print(f"[OK] Drenagem salva com sucesso e habilitada para edicao no QGIS: {tab_dren}{sufixo}")

        # =========================================================
        # GRAVACAO UNIFICADA NO POSTGIS (COM PK PARA O QGIS)
        # =========================================================
        if gdf_massa is not None and not gdf_massa.empty:
            salvar_e_habilitar_edicao_postgis(gdf_massa, engine, schema, f"{tab_massa}{sufixo}", crs_orig_massa)
            print(f"[OK] Corpos d'agua salvos e habilitados para edicao: {tab_massa}{sufixo}")
            
        if gdf_veg is not None and not gdf_veg.empty:
            salvar_e_habilitar_edicao_postgis(gdf_veg, engine, schema, f"{tab_veg}{sufixo}", crs_orig_veg)
            print(f"[OK] Vegetacao salva e habilitada para edicao: {tab_veg}{sufixo}")

        if gdf_edif is not None and not gdf_edif.empty:
            salvar_e_habilitar_edicao_postgis(gdf_edif, engine, schema, f"{tab_edif}{sufixo}", crs_orig_edif)
            print(f"[OK] Area edificada salva e habilitada para edicao: {tab_edif}{sufixo}")
        
        demais_camadas = [
            "infra_via_deslocamento_l",
            "constr_edificacao_a",
            "elemnat_curva_nivel_l",
            "elemnat_ponto_cotado_p"
        ]
        
        for padrao in demais_camadas:
            gdf_iso, tab_encontrada, crs_orig_iso = carregar_tabela_inteligente(engine, schema, padrao, epsg_utm)
            if (gdf_iso is None or gdf_iso.empty) and padrao != "constr_edificacao_a":
                continue
            
            p_iso = obter_parametros(escala_alvo, padrao)
            
            # 1. Transportes (infra_via_deslocamento_l)
            if padrao == "infra_via_deslocamento_l":
                tabela_out = f"{tab_encontrada}{sufixo}"
                print(f"\n[*] Processando camada isolada: {tab_encontrada} ...")
                gdf_iso = generalizar_linhas_com_topologia(
                    gdf_iso,
                    escala_alvo,
                    padrao,
                    gdf_edif_ref=gdf_edif_orig_ref,
                    moldura_folha=moldura_folha
                )
                salvar_e_habilitar_edicao_postgis(gdf_iso, engine, schema, tabela_out, crs_orig_iso)
                print(f"[OK] Sucesso: {tabela_out} gravada e habilitada para edicao no QGIS.")
                
            # 2. Edificacoes (constr_edificacao_a + constr_edificacao_p)
            elif padrao == "constr_edificacao_a":
                gdf_pts_orig, tab_pts_orig, crs_pts_orig = carregar_tabela_inteligente(engine, schema, "constr_edificacao_p", epsg_utm)
                if (gdf_iso is None or gdf_iso.empty) and (gdf_pts_orig is None or gdf_pts_orig.empty):
                    continue
                crs_edif_out = crs_orig_iso if crs_orig_iso is not None else crs_pts_orig
                tab_base_a = tab_encontrada if tab_encontrada else "constr_edificacao_a"
                tab_base_p = tab_pts_orig if tab_pts_orig else (tab_base_a[:-2] + '_p' if tab_base_a.endswith('_a') else tab_base_a + '_p')
                tabela_out = f"{tab_base_a}{sufixo}"
                tabela_pts_out = f"{tab_base_p}{sufixo}"
                print(f"\n[*] Processando edificacoes integradas: {tab_base_a} + {tab_base_p} ...")

                gdf_grandes = gpd.GeoDataFrame()
                gdf_colapsadas = gpd.GeoDataFrame()

                if gdf_iso is not None and not gdf_iso.empty:
                    gdf_iso['area_orig'] = gdf_iso['geom'].area
                    gdf_iso['geom'] = gdf_iso['geom'].simplify(tolerance=p_iso["tol"]/2, preserve_topology=True)
                    if p_iso["edif_min"] > 0:
                        gdf_grandes = gdf_iso[gdf_iso['area_orig'] >= p_iso["edif_min"]].copy()
                        gdf_colapsadas = gdf_iso[gdf_iso['area_orig'] < p_iso["edif_min"]].copy()
                    else:
                        gdf_colapsadas = gdf_iso.copy()

                if not gdf_grandes.empty:
                    gdf_grandes_save = gdf_grandes.drop(columns=['area_orig'], errors='ignore').copy()
                    gdf_grandes_save = _garantir_disjuncao_interna_gdf(gdf_grandes_save, area_min_sliver=10.0)
                    gdf_grandes_save['geom'] = gdf_grandes_save['geom'].apply(lambda x: garantir_multi(x, 'poligono'))
                    salvar_e_habilitar_edicao_postgis(gdf_grandes_save, engine, schema, tabela_out, crs_edif_out)
                    print(f"[OK] Sucesso: {tabela_out} ({len(gdf_grandes_save)} poligonos >= {p_iso['edif_min']} m2) gravada no QGIS.")
                elif escala_alvo == "250":
                    try:
                        with engine.begin() as conn:
                            conn.execute(text(f'DROP TABLE IF EXISTS "{schema}"."{tabela_out}" CASCADE;'))
                    except Exception:
                        pass

                # Combinar poligonos colapsados para ponto + edificacoes originalmente do tipo ponto (constr_edificacao_p)
                partes_pts = []
                if not gdf_colapsadas.empty:
                    gdf_col_p = gdf_colapsadas.copy()
                    gdf_col_p['geom'] = gdf_col_p['geom'].centroid
                    partes_pts.append(gdf_col_p)
                if gdf_pts_orig is not None and not gdf_pts_orig.empty:
                    gdf_p_copy = gdf_pts_orig.copy()
                    gdf_p_copy['area_orig'] = 0.0
                    partes_pts.append(gdf_p_copy)

                if partes_pts:
                    gdf_todos_pts = gpd.GeoDataFrame(pd.concat(partes_pts, ignore_index=True), geometry='geom', crs=epsg_utm)
                    col_nome_e = achar_coluna(gdf_todos_pts, ['nome', 'nm_edif', 'denominacao', 'toponimo'])
                    col_tipo_e = achar_coluna(gdf_todos_pts, ['tipo', 'classe', 'funcao'])

                    if col_nome_e:
                        gdf_todos_pts['_tem_nome'] = (
                            gdf_todos_pts[col_nome_e].notna() &
                            ~gdf_todos_pts[col_nome_e].astype(str).str.strip().str.upper().isin(["", "NULL", "NONE", "NAN", "DESCONHECIDO"])
                        )
                    else:
                        gdf_todos_pts['_tem_nome'] = False

                    if col_tipo_e:
                        gdf_todos_pts['_tem_tipo'] = ~gdf_todos_pts[col_tipo_e].astype(str).str.strip().isin(["0", "9999", "None", "nan", ""])
                    else:
                        gdf_todos_pts['_tem_tipo'] = False

                    # Ordenar por prioridade cartografica: Nomeadas -> Tipo especifico -> Maior area colapsada -> Demais pontos
                    gdf_todos_pts = gdf_todos_pts.sort_values(
                        by=['_tem_nome', '_tem_tipo', 'area_orig'],
                        ascending=[False, False, False]
                    ).reset_index(drop=True)

                    u_grandes_buf = unary_union(gdf_grandes['geom'].tolist()).buffer(2.0) if not gdf_grandes.empty else None
                    # Espacamento minimo de representacao cartografica (1.0 mm na escala: 50m em 50k, 100m em 100k, 250m em 250k)
                    raio_simbolo = 50.0 if escala_alvo == "50" else (100.0 if escala_alvo == "100" else 250.0)

                    indices_pts_mantidos = []
                    pts_aceitos = []
                    for idx_p, row_p in gdf_todos_pts.iterrows():
                        geom_p = row_p['geom']
                        if geom_p is None or geom_p.is_empty:
                            continue
                        pt_s = geom_p.geoms[0] if hasattr(geom_p, 'geoms') else geom_p
                        if u_grandes_buf is not None and u_grandes_buf.intersects(pt_s):
                            continue
                        if not row_p['_tem_nome'] and any(pt_s.distance(p_ok) < raio_simbolo for p_ok in pts_aceitos):
                            continue
                        pts_aceitos.append(pt_s)
                        indices_pts_mantidos.append(idx_p)

                    gdf_pts_final = gdf_todos_pts.loc[indices_pts_mantidos].copy().reset_index(drop=True)
                    gdf_pts_final.drop(columns=['area_orig', '_tem_nome', '_tem_tipo'], inplace=True, errors='ignore')
                    gdf_pts_final['geom'] = gdf_pts_final['geom'].apply(lambda x: garantir_multi(x, 'ponto'))
                    salvar_e_habilitar_edicao_postgis(gdf_pts_final, engine, schema, tabela_pts_out, crs_edif_out)
                    print(f"[OK] Edificacoes tipo ponto concluidas: {tabela_pts_out} ({len(gdf_pts_final)} pontos) gravada e habilitada no QGIS.")
                    
            # 3. Curvas de Nivel (elemnat_curva_nivel_l) e Ponto Cotado Altimetrico (elemnat_ponto_cotado_p) integrados
            elif padrao == "elemnat_curva_nivel_l":
                tabela_out = f"{tab_encontrada}{sufixo}"
                print(f"\n[*] Processando curvas de nivel integradas com pontos cotados: {tab_encontrada} ...")
                
                # Carregar pontos cotados para sincronizacao 1:1 rigorosa na mesma escala alvo
                gdf_ptos_cot, tab_ptos_cot, crs_ptos_cot = carregar_tabela_inteligente(engine, schema, "elemnat_ponto_cotado_p", epsg_utm)
                tabela_ptos_out = f"{tab_ptos_cot}{sufixo}" if tab_ptos_cot else f"elemnat_ponto_cotado_p{sufixo}"

                col_cota = achar_coluna(gdf_iso, ['cota', 'altitude', 'elevacao', 'valor_cota'])
                if col_cota:
                    gdf_iso[col_cota] = pd.to_numeric(gdf_iso[col_cota], errors='coerce')
                    gdf_iso = gdf_iso[gdf_iso[col_cota] % p_iso["curva_eq"] == 0].copy()
                    
                    # Classificacao de Curva Mestra vs Normal conforme ET-ADGV 3.0
                    col_indice = achar_coluna(gdf_iso, ['indice', 'tipo', 'tipocurvanivel'])
                    if col_indice:
                        eh_mestra = (gdf_iso[col_cota] % p_iso["curva_mestra"] == 0)
                        tipo_col = gdf_iso[col_indice].dtype
                        if pd.api.types.is_numeric_dtype(tipo_col):
                            gdf_iso[col_indice] = eh_mestra.map({True: 1, False: 2})
                        elif pd.api.types.is_bool_dtype(tipo_col):
                            gdf_iso[col_indice] = eh_mestra
                        else:
                            gdf_iso[col_indice] = eh_mestra.map({True: 'Mestra', False: 'Normal'})

                # Simplificacao geometrica preservando altimetria estrita e suavizacao Chaikin
                gdf_iso['geom'] = gdf_iso['geom'].simplify(tolerance=p_iso["tol"], preserve_topology=True)
                gdf_iso['geom'] = gdf_iso['geom'].apply(lambda x: suavizar_linha_chaikin(x, iteracoes=1))
                gdf_iso = aplicar_linemerge(gdf_iso)

                # Separar curvas em: Abertas, Fechadas Grandes (>= perim_min) e Fechadas Pequenas (< perim_min)
                perim_min_fechada = p_iso.get("curva_fechada_min", 600.0)
                curvas_abertas = []
                fechadas_grandes = []
                fechadas_pequenas = []

                for _, r_curva in gdf_iso.iterrows():
                    geom_c = r_curva['geom']
                    if geom_c is None or geom_c.is_empty:
                        continue
                    eh_fechada = False
                    if geom_c.geom_type == 'LineString':
                        coords_c = list(geom_c.coords)
                        if len(coords_c) >= 4 and coords_c[0] == coords_c[-1]:
                            eh_fechada = True
                    
                    if eh_fechada:
                        if geom_c.length >= perim_min_fechada:
                            fechadas_grandes.append(r_curva.to_dict())
                        else:
                            try:
                                poly_c = Polygon(geom_c)
                                if poly_c.is_valid:
                                    fechadas_pequenas.append((r_curva.to_dict(), geom_c, poly_c))
                            except Exception:
                                pass
                    else:
                        curvas_abertas.append(r_curva.to_dict())

                # Generalizacao e Eleicao dos Pontos Cotados Priorizando Cumes Reais
                dist_min_pto = p_iso.get("pto_cotado_dist", 1000.0)
                cumes_com_ponto_mantido = set()

                if gdf_ptos_cot is not None and not gdf_ptos_cot.empty:
                    col_cota_p = achar_coluna(gdf_ptos_cot, ['cota', 'altitude', 'elevacao'])
                    col_alta = achar_coluna(gdf_ptos_cot, ['cota_mais_alta', 'mais_alta', 'maior_cota'])

                    if col_cota_p:
                        gdf_ptos_cot['_cota_num'] = pd.to_numeric(gdf_ptos_cot[col_cota_p], errors='coerce')
                    else:
                        gdf_ptos_cot['_cota_num'] = 0.0

                    if col_alta:
                        gdf_ptos_cot['_eh_mais_alta'] = gdf_ptos_cot[col_alta].astype(str).str.strip().str.lower().isin(['1', 'true', 'sim'])
                    else:
                        gdf_ptos_cot['_eh_mais_alta'] = False

                    gdf_ptos_cot['_eh_cume'] = False
                    gdf_ptos_cot['_cume_id'] = None

                    # Identificar pontos cotados que estao no interior dos cumes fechados pequenos
                    sindex_ptos = gdf_ptos_cot.sindex
                    for c_idx, (r_dict, geom_l, poly_c) in enumerate(fechadas_pequenas):
                        possiveis_p = list(sindex_ptos.intersection(poly_c.bounds))
                        if possiveis_p:
                            sub_ptos = gdf_ptos_cot.iloc[possiveis_p]
                            dentro = sub_ptos[sub_ptos.intersects(poly_c)]
                            if not dentro.empty:
                                melhor_idx = dentro.sort_values(by='_cota_num', ascending=False).index[0]
                                gdf_ptos_cot.at[melhor_idx, '_eh_cume'] = True
                                gdf_ptos_cot.at[melhor_idx, '_cume_id'] = c_idx

                    # Ordenacao de Prioridade Cartografica Estrita:
                    # 1. Cota mais alta (ponto culminante da folha)
                    # 2. Ponto situado em Cume/Pico de morro fechado (_eh_cume)
                    # 3. Maior altitude (_cota_num)
                    gdf_ptos_cot = gdf_ptos_cot.sort_values(
                        by=['_eh_mais_alta', '_eh_cume', '_cota_num'],
                        ascending=[False, False, False]
                    ).reset_index(drop=True)

                    coords_ptos_aceitas = []
                    indices_ptos_aceitos = []

                    for idx_p, row_p in gdf_ptos_cot.iterrows():
                        geom_p = row_p['geom']
                        if geom_p is None or geom_p.is_empty:
                            continue
                        pt_s = geom_p.geoms[0] if hasattr(geom_p, 'geoms') else geom_p

                        if row_p['_eh_mais_alta']:
                            indices_ptos_aceitos.append(idx_p)
                            coords_ptos_aceitas.append(pt_s)
                            if row_p['_eh_cume'] and row_p['_cume_id'] is not None:
                                cumes_com_ponto_mantido.add(row_p['_cume_id'])
                        elif row_p['_eh_cume']:
                            # Ponto de cume: aceito se respeitar espacamento cartografico entre picos
                            if not any(pt_s.distance(p_ok) < dist_min_pto * 0.75 for p_ok in coords_ptos_aceitas):
                                indices_ptos_aceitos.append(idx_p)
                                coords_ptos_aceitas.append(pt_s)
                                if row_p['_cume_id'] is not None:
                                    cumes_com_ponto_mantido.add(row_p['_cume_id'])
                        else:
                            # Ponto em terreno aberto/vale: apenas se respeitar espacamento pleno e nao houver cume
                            if not any(pt_s.distance(p_ok) < dist_min_pto for p_ok in coords_ptos_aceitas):
                                indices_ptos_aceitos.append(idx_p)
                                coords_ptos_aceitas.append(pt_s)

                    gdf_ptos_final = gdf_ptos_cot.loc[indices_ptos_aceitos].copy().reset_index(drop=True)
                    gdf_ptos_final.drop(columns=['_cota_num', '_eh_mais_alta', '_eh_cume', '_cume_id'], inplace=True, errors='ignore')
                    gdf_ptos_final['geom'] = gdf_ptos_final['geom'].apply(lambda x: garantir_multi(x, 'ponto'))
                    salvar_e_habilitar_edicao_postgis(gdf_ptos_final, engine, schema, tabela_ptos_out, crs_ptos_cot)
                    print(f"[OK] Pontos cotados sincronizados: {tabela_ptos_out} ({len(gdf_ptos_final)} pontos, {len(cumes_com_ponto_mantido)} em cumes) gravada no QGIS.")

                # Amarracao 1:1 com as Curvas Fechadas Pequenas:
                # Regra Absoluta: Curva fechada pequena SO permanece se contiver o ponto cotado oficial mantido nessa escala!
                curvas_finais_lista = list(curvas_abertas) + list(fechadas_grandes)
                pequenas_mantidas = 0
                pequenas_suprimidas = 0

                for c_idx, (r_dict, geom_l, poly_c) in enumerate(fechadas_pequenas):
                    if c_idx in cumes_com_ponto_mantido:
                        curvas_finais_lista.append(r_dict)
                        pequenas_mantidas += 1
                    else:
                        pequenas_suprimidas += 1

                gdf_curvas_final = gpd.GeoDataFrame(curvas_finais_lista, crs=gdf_iso.crs, geometry='geom')
                gdf_curvas_final['geom'] = gdf_curvas_final['geom'].apply(lambda x: garantir_multi(x, 'linha'))
                salvar_e_habilitar_edicao_postgis(gdf_curvas_final, engine, schema, tabela_out, crs_orig_iso)
                print(f"[OK] Sucesso: {tabela_out} ({len(gdf_curvas_final)} curvas mantidas: {pequenas_mantidas} cumes com ponto cotado, {pequenas_suprimidas} fechadas pequenas sem ponto suprimidas).")

            # 4. Pontos Cotados Altimetricos (elemnat_ponto_cotado_p)
            elif padrao == "elemnat_ponto_cotado_p":
                # Processamento ja realizado de forma sincronizada com as curvas de nivel
                pass
                
            print("-" * 50)
            
        print("\n[CONCLUIDO] Generalizacao Autonoma, Multi-Escalas e Habilitada no QGIS concluida com sucesso!")

        # =====================================================================
        # CONTROLE DE QUALIDADE E AUTO-REPARO TOPOLOGICO (DSG SELF-HEALING)
        # =====================================================================
        try:
            from validador_dsg import executar_validacao_e_correcao_automatica
            print("\n" + "=" * 70)
            print(" [SGC] ATIVANDO MODULO DE VALIDACAO E AUTO-REPARO TOPOLOGICO (DSG)")
            print("=" * 70)
            executar_validacao_e_correcao_automatica(
                engine=engine,
                schema=schema,
                escala=escala_alvo,
                epsg=epsg_utm,
                max_iter=3
            )
        except Exception as e_val:
            print(f"[ALERTA] Falha na execucao do modulo validador_dsg: {e_val}")
        
    except Exception as e:
        print(f"[ERRO] Erro critico no processamento: {e}")

if __name__ == "__main__":
    main()
